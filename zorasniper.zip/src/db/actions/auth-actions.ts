"use server";

import { db } from "@/neynar-db-sdk/db";
import { emailSessions, otpCodes } from "@/db/schema";
import { eq, and, gt } from "drizzle-orm";

// ─── Email Sessions ───────────────────────────────────────────────────────────

export async function getEmailSession(email: string) {
  const rows = await db
    .select()
    .from(emailSessions)
    .where(eq(emailSessions.email, email.toLowerCase()))
    .limit(1);
  return rows[0] ?? null;
}

export async function upsertEmailSession(email: string, fid: number) {
  const existing = await getEmailSession(email);
  if (existing) {
    await db
      .update(emailSessions)
      .set({ fid })
      .where(eq(emailSessions.email, email.toLowerCase()));
    return { ...existing, fid };
  }
  const rows = await db
    .insert(emailSessions)
    .values({ email: email.toLowerCase(), fid })
    .returning();
  return rows[0];
}

// ─── OTP Codes ────────────────────────────────────────────────────────────────

export async function createOtp(email: string): Promise<string> {
  // Generate 6 digit code
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 menit

  // Invalidate old codes untuk email ini
  await db
    .update(otpCodes)
    .set({ used: true })
    .where(eq(otpCodes.email, email.toLowerCase()));

  await db.insert(otpCodes).values({
    email: email.toLowerCase(),
    code,
    expiresAt,
    used: false,
  });

  return code;
}

export async function verifyOtp(email: string, code: string): Promise<boolean> {
  const now = new Date();
  const rows = await db
    .select()
    .from(otpCodes)
    .where(
      and(
        eq(otpCodes.email, email.toLowerCase()),
        eq(otpCodes.code, code),
        eq(otpCodes.used, false),
        gt(otpCodes.expiresAt, now)
      )
    )
    .limit(1);

  if (rows.length === 0) return false;

  // Mark as used
  await db
    .update(otpCodes)
    .set({ used: true })
    .where(eq(otpCodes.id, rows[0].id));

  return true;
}
