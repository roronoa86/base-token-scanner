import { db } from "@/neynar-db-sdk/db";
import { clankerSniperSettings, clankerSnipeLog, clankerWatchList } from "@/db/schema";
import { eq, and, gte, lte, sql, desc } from "drizzle-orm";

// ─── Settings ─────────────────────────────────────────────────────────────────

export async function getClankerSettings(fid: number) {
  const result = await db
    .select()
    .from(clankerSniperSettings)
    .where(eq(clankerSniperSettings.fid, fid))
    .limit(1);
  return result[0] ?? null;
}

export async function upsertClankerSettings(
  fid: number,
  settings: {
    isEnabled?: boolean;
    buyAmountEth?: string;
    slippageBps?: number;
    maxBuysPerDay?: number;
    minLiquidityUsd?: number;
    maxTokenAgeMin?: number;
  },
) {
  // Validasi
  if (settings.buyAmountEth !== undefined) {
    const amt = parseFloat(settings.buyAmountEth);
    if (isNaN(amt) || amt <= 0 || amt > 1)
      return { error: "Buy amount harus antara 0 dan 1 ETH" };
  }
  if (settings.slippageBps !== undefined && (settings.slippageBps < 10 || settings.slippageBps > 5000))
    return { error: "Slippage harus antara 0.1% (10 bps) dan 50% (5000 bps)" };
  if (settings.maxBuysPerDay !== undefined && (settings.maxBuysPerDay < 1 || settings.maxBuysPerDay > 50))
    return { error: "Max buy per hari harus antara 1 dan 50" };
  if (settings.minLiquidityUsd !== undefined && (settings.minLiquidityUsd < 0 || settings.minLiquidityUsd > 1_000_000))
    return { error: "Min liquidity harus antara $0 dan $1,000,000" };
  if (settings.maxTokenAgeMin !== undefined && ![5, 15, 30, 60].includes(settings.maxTokenAgeMin))
    return { error: "Usia token harus 5, 15, 30, atau 60 menit" };

  await db
    .insert(clankerSniperSettings)
    .values({
      fid,
      isEnabled: settings.isEnabled ?? false,
      buyAmountEth: settings.buyAmountEth ?? "0.001",
      slippageBps: settings.slippageBps ?? 500,
      maxBuysPerDay: settings.maxBuysPerDay ?? 5,
      minLiquidityUsd: settings.minLiquidityUsd ?? 1000,
      maxTokenAgeMin: settings.maxTokenAgeMin ?? 15,
    })
    .onConflictDoUpdate({
      target: clankerSniperSettings.fid,
      set: {
        ...(settings.isEnabled !== undefined && { isEnabled: settings.isEnabled }),
        ...(settings.buyAmountEth !== undefined && { buyAmountEth: settings.buyAmountEth }),
        ...(settings.slippageBps !== undefined && { slippageBps: settings.slippageBps }),
        ...(settings.maxBuysPerDay !== undefined && { maxBuysPerDay: settings.maxBuysPerDay }),
        ...(settings.minLiquidityUsd !== undefined && { minLiquidityUsd: settings.minLiquidityUsd }),
        ...(settings.maxTokenAgeMin !== undefined && { maxTokenAgeMin: settings.maxTokenAgeMin }),
        updatedAt: new Date(),
      },
    });

  return { success: true };
}

// ─── Snipe Log ────────────────────────────────────────────────────────────────

/**
 * Cek apakah token sudah pernah berhasil di-snipe (status=success).
 * Hanya block kalau success — failed/pending/skipped boleh dicoba lagi.
 */
export async function hasAlreadySniped(fid: number, tokenAddress: string): Promise<boolean> {
  const result = await db
    .select({ id: clankerSnipeLog.id })
    .from(clankerSnipeLog)
    .where(
      and(
        eq(clankerSnipeLog.fid, fid),
        eq(clankerSnipeLog.tokenAddress, tokenAddress.toLowerCase()),
        eq(clankerSnipeLog.status, "success"),
      ),
    )
    .limit(1);
  return result.length > 0;
}

/** Hitung berapa kali user sudah snipe berhasil hari ini (UTC) — hanya status=success */
export async function countTodaySnipes(fid: number): Promise<number> {
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(clankerSnipeLog)
    .where(
      and(
        eq(clankerSnipeLog.fid, fid),
        eq(clankerSnipeLog.status, "success"),
        gte(clankerSnipeLog.createdAt, startOfDay),
      ),
    );
  return Number(result[0]?.count ?? 0);
}

export async function createSnipeLog(data: {
  fid: number;
  tokenAddress: string;
  tokenName?: string;
  tokenSymbol?: string;
  clankerTokenId?: number;
  volumeUsdAtSnipe?: number;
  buyAmountEth: string;
}) {
  const result = await db
    .insert(clankerSnipeLog)
    .values({
      fid: data.fid,
      tokenAddress: data.tokenAddress.toLowerCase(),
      tokenName: data.tokenName ?? null,
      tokenSymbol: data.tokenSymbol ?? null,
      clankerTokenId: data.clankerTokenId ?? null,
      volumeUsdAtSnipe: data.volumeUsdAtSnipe ?? null,
      buyAmountEth: data.buyAmountEth,
      status: "pending",
    })
    .returning();
  return result[0];
}

export async function updateSnipeLog(
  id: string,
  update: { status: "success" | "failed" | "skipped"; txHash?: string; errorMessage?: string },
) {
  await db
    .update(clankerSnipeLog)
    .set({
      status: update.status,
      ...(update.txHash && { txHash: update.txHash }),
      ...(update.errorMessage && { errorMessage: update.errorMessage }),
    })
    .where(eq(clankerSnipeLog.id, id));
}

export async function getClankerSnipeHistory(fid: number, limit = 50) {
  return db
    .select()
    .from(clankerSnipeLog)
    .where(eq(clankerSnipeLog.fid, fid))
    .orderBy(desc(clankerSnipeLog.createdAt))
    .limit(limit);
}

// Ambil semua FID yang punya clanker sniper aktif (untuk cron)
export async function getAllActiveClankerSnipers() {
  return db
    .select()
    .from(clankerSniperSettings)
    .where(eq(clankerSniperSettings.isEnabled, true));
}

// ─── Watch List ────────────────────────────────────────────────────────────────

/** Tambah token baru ke watch list (ignore kalau sudah ada) */
export async function upsertWatchList(tokens: {
  tokenAddress: string;
  tokenName?: string;
  tokenSymbol?: string;
  clankerTokenId?: number;
  deployedAt: Date;
  expiresAt: Date;
}[]) {
  if (!tokens.length) return;
  await db
    .insert(clankerWatchList)
    .values(tokens.map((t) => ({
      tokenAddress: t.tokenAddress.toLowerCase(),
      tokenName: t.tokenName ?? null,
      tokenSymbol: t.tokenSymbol ?? null,
      clankerTokenId: t.clankerTokenId ?? null,
      deployedAt: t.deployedAt,
      expiresAt: t.expiresAt,
    })))
    .onConflictDoNothing(); // kalau sudah ada, skip
}

/** Ambil semua token yang masih aktif di watch list (belum expired) */
export async function getActiveWatchList() {
  const now = new Date();
  return db
    .select()
    .from(clankerWatchList)
    .where(gte(clankerWatchList.expiresAt, now))
    .orderBy(desc(clankerWatchList.deployedAt));
}

/** Hapus token yang sudah expired dari watch list */
export async function purgeExpiredWatchList() {
  const now = new Date();
  await db
    .delete(clankerWatchList)
    .where(lte(clankerWatchList.expiresAt, now));
}
