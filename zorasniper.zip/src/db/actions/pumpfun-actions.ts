import { db } from "@/neynar-db-sdk/db";
import { pumpfunSniperSettings, pumpfunSnipeLog, pumpfunWatchList } from "@/db/schema";
import { eq, and, gte, lte, sql, desc } from "drizzle-orm";

// ─── Settings ─────────────────────────────────────────────────────────────────

export async function getPumpfunSettings(fid: number) {
  const result = await db
    .select()
    .from(pumpfunSniperSettings)
    .where(eq(pumpfunSniperSettings.fid, fid))
    .limit(1);
  return result[0] ?? null;
}

export async function upsertPumpfunSettings(
  fid: number,
  settings: {
    isEnabled?: boolean;
    buyAmountSol?: string;
    slippageBps?: number;
    maxBuysPerDay?: number;
    minVolumeUsd?: number;
    maxTokenAgeMin?: number;
    solanaPrivateKey?: string;
    solanaWalletAddress?: string;
  },
) {
  if (settings.buyAmountSol !== undefined) {
    const amt = parseFloat(settings.buyAmountSol);
    if (isNaN(amt) || amt <= 0 || amt > 10)
      return { error: "Buy amount harus antara 0 dan 10 SOL" };
  }
  if (settings.slippageBps !== undefined && (settings.slippageBps < 10 || settings.slippageBps > 5000))
    return { error: "Slippage harus antara 0.1% dan 50%" };
  if (settings.maxBuysPerDay !== undefined && (settings.maxBuysPerDay < 1 || settings.maxBuysPerDay > 50))
    return { error: "Max buy per hari harus antara 1 dan 50" };
  if (settings.minVolumeUsd !== undefined && (settings.minVolumeUsd < 0 || settings.minVolumeUsd > 10_000_000))
    return { error: "Min volume harus antara $0 dan $10,000,000" };
  if (settings.maxTokenAgeMin !== undefined && ![5, 10, 20, 40, 60].includes(settings.maxTokenAgeMin))
    return { error: "Usia token harus 5, 10, 20, 40, atau 60 menit" };

  await db
    .insert(pumpfunSniperSettings)
    .values({
      fid,
      isEnabled: settings.isEnabled ?? false,
      buyAmountSol: settings.buyAmountSol ?? "0.01",
      slippageBps: settings.slippageBps ?? 1000,
      maxBuysPerDay: settings.maxBuysPerDay ?? 5,
      minVolumeUsd: settings.minVolumeUsd ?? 1000,
      maxTokenAgeMin: settings.maxTokenAgeMin ?? 15,
      ...(settings.solanaPrivateKey !== undefined && { solanaPrivateKey: settings.solanaPrivateKey }),
      ...(settings.solanaWalletAddress !== undefined && { solanaWalletAddress: settings.solanaWalletAddress }),
    })
    .onConflictDoUpdate({
      target: pumpfunSniperSettings.fid,
      set: {
        ...(settings.isEnabled !== undefined && { isEnabled: settings.isEnabled }),
        ...(settings.buyAmountSol !== undefined && { buyAmountSol: settings.buyAmountSol }),
        ...(settings.slippageBps !== undefined && { slippageBps: settings.slippageBps }),
        ...(settings.maxBuysPerDay !== undefined && { maxBuysPerDay: settings.maxBuysPerDay }),
        ...(settings.minVolumeUsd !== undefined && { minVolumeUsd: settings.minVolumeUsd }),
        ...(settings.maxTokenAgeMin !== undefined && { maxTokenAgeMin: settings.maxTokenAgeMin }),
        ...(settings.solanaPrivateKey !== undefined && { solanaPrivateKey: settings.solanaPrivateKey }),
        ...(settings.solanaWalletAddress !== undefined && { solanaWalletAddress: settings.solanaWalletAddress }),
        updatedAt: new Date(),
      },
    });

  return { success: true };
}

export async function getAllActivePumpfunSnipers() {
  return db
    .select()
    .from(pumpfunSniperSettings)
    .where(eq(pumpfunSniperSettings.isEnabled, true));
}

// ─── Snipe Log ────────────────────────────────────────────────────────────────

/**
 * Cek apakah token sudah pernah berhasil di-snipe (status=success).
 * failed/pending boleh dicoba lagi.
 */
export async function hasAlreadySnipedPumpfun(fid: number, mintAddress: string): Promise<boolean> {
  const result = await db
    .select({ id: pumpfunSnipeLog.id })
    .from(pumpfunSnipeLog)
    .where(
      and(
        eq(pumpfunSnipeLog.fid, fid),
        eq(pumpfunSnipeLog.mintAddress, mintAddress),
        eq(pumpfunSnipeLog.status, "success"),
      ),
    )
    .limit(1);
  return result.length > 0;
}

/** Hitung snipe sukses hari ini (UTC) — hanya status=success */
export async function countTodayPumpfunSnipes(fid: number): Promise<number> {
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(pumpfunSnipeLog)
    .where(
      and(
        eq(pumpfunSnipeLog.fid, fid),
        eq(pumpfunSnipeLog.status, "success"),
        gte(pumpfunSnipeLog.createdAt, startOfDay),
      ),
    );
  return Number(result[0]?.count ?? 0);
}

export async function createPumpfunSnipeLog(data: {
  fid: number;
  mintAddress: string;
  tokenName?: string;
  tokenSymbol?: string;
  volumeUsdAtSnipe?: number;
  buyAmountSol: string;
}) {
  const result = await db
    .insert(pumpfunSnipeLog)
    .values({
      fid: data.fid,
      mintAddress: data.mintAddress,
      tokenName: data.tokenName ?? null,
      tokenSymbol: data.tokenSymbol ?? null,
      volumeUsdAtSnipe: data.volumeUsdAtSnipe ?? null,
      buyAmountSol: data.buyAmountSol,
      status: "pending",
    })
    .returning();
  return result[0];
}

export async function updatePumpfunSnipeLog(
  id: string,
  update: { status: "success" | "failed" | "skipped"; txSignature?: string; errorMessage?: string },
) {
  await db
    .update(pumpfunSnipeLog)
    .set({
      status: update.status,
      ...(update.txSignature && { txSignature: update.txSignature }),
      ...(update.errorMessage && { errorMessage: update.errorMessage }),
    })
    .where(eq(pumpfunSnipeLog.id, id));
}

export async function getPumpfunSnipeHistory(fid: number, limit = 100) {
  return db
    .select()
    .from(pumpfunSnipeLog)
    .where(eq(pumpfunSnipeLog.fid, fid))
    .orderBy(desc(pumpfunSnipeLog.createdAt))
    .limit(limit);
}

export async function clearPumpfunSnipeHistory(fid: number) {
  await db
    .delete(pumpfunSnipeLog)
    .where(eq(pumpfunSnipeLog.fid, fid));
}

// ─── Watch List ───────────────────────────────────────────────────────────────

export async function upsertPumpfunWatchList(tokens: {
  mintAddress: string;
  tokenName?: string;
  tokenSymbol?: string;
  imageUri?: string;
  marketCapUsd?: number;
  createdTimestamp: Date;
  expiresAt: Date;
}[]) {
  if (!tokens.length) return;
  await db
    .insert(pumpfunWatchList)
    .values(tokens.map((t) => ({
      mintAddress: t.mintAddress,
      tokenName: t.tokenName ?? null,
      tokenSymbol: t.tokenSymbol ?? null,
      imageUri: t.imageUri ?? null,
      marketCapUsd: t.marketCapUsd ?? null,
      createdTimestamp: t.createdTimestamp,
      expiresAt: t.expiresAt,
    })))
    .onConflictDoUpdate({
      target: pumpfunWatchList.mintAddress,
      // Update market cap tiap cron — nilainya bisa naik seiring waktu
      set: {
        marketCapUsd: sql`EXCLUDED.market_cap_usd`,
      },
    });
}

export async function getActivePumpfunWatchList() {
  const now = new Date();
  return db
    .select()
    .from(pumpfunWatchList)
    .where(gte(pumpfunWatchList.expiresAt, now))
    .orderBy(desc(pumpfunWatchList.createdTimestamp));
}

export async function purgeExpiredPumpfunWatchList() {
  const now = new Date();
  await db
    .delete(pumpfunWatchList)
    .where(lte(pumpfunWatchList.expiresAt, now));
}
