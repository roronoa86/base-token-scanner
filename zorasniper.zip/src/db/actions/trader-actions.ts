// Server-side only — do NOT add "use server" here.
// "use server" causes Next.js to serialize return values which breaks
// large numeric types (numeric(78,0) → BigInt → not serializable → overflow).
// This file is only imported by API routes (already server-side), so no directive needed.

import { db } from "@/neynar-db-sdk/db";
import { traderPositions } from "@/db/schema";
import { eq, and, desc, or } from "drizzle-orm";

export type TraderPosition = typeof traderPositions.$inferSelect;

export async function createPosition(data: {
  fid: number;
  tokenAddress: string;
  tokenName?: string;
  tokenSymbol?: string;
  tokenPriceUsd?: string;
  tokenImageUrl?: string;
  buyAmountEth: string;
  buyTriggerPriceUsd?: string | null;
  sellTargetPriceUsd?: string | null;
  takeProfitPct?: string | null;
  stopLossPct?: string | null;
}) {
  // status: pending_buy = ada trigger price, menunggu harga turun ke target
  //         active     = langsung beli, posisi sudah aktif
  // Catatan: buy/route.ts akan panggil updatePositionBuy dengan status "active"
  //          setelah TX confirm. Set "active" di sini supaya monitor cron tidak
  //          ikut coba beli posisi yang sudah dieksekusi.
  const status = data.buyTriggerPriceUsd ? "pending_buy" : "active";
  const result = await db
    .insert(traderPositions)
    .values({
      fid: data.fid,
      tokenAddress: data.tokenAddress.toLowerCase(),
      tokenName: data.tokenName ?? null,
      tokenSymbol: data.tokenSymbol ?? null,
      tokenPriceUsd: data.tokenPriceUsd ?? null,
      tokenImageUrl: data.tokenImageUrl ?? null,
      buyAmountEth: data.buyAmountEth,
      buyTriggerPriceUsd: data.buyTriggerPriceUsd ?? null,
      sellTargetPriceUsd: data.sellTargetPriceUsd ?? null,
      takeProfitPct: data.takeProfitPct ?? null,
      stopLossPct: data.stopLossPct ?? null,
      status,
    })
    .returning();
  return result[0];
}

export async function updatePositionBuy(
  id: string,
  data: {
    buyTxHash?: string;
    buyPriceUsd?: string;
    buyPriceEth?: string;
    ethUsdAtBuy?: string;   // ETH/USD rate saat TX dieksekusi — untuk PnL akurat
    tokensReceived?: string;
    status?: string;
    errorMessage?: string;
  },
) {
  await db
    .update(traderPositions)
    .set({
      ...(data.buyTxHash !== undefined && { buyTxHash: data.buyTxHash }),
      ...(data.buyPriceUsd !== undefined && { buyPriceUsd: data.buyPriceUsd }),
      ...(data.buyPriceEth !== undefined && { buyPriceEth: data.buyPriceEth }),
      ...(data.ethUsdAtBuy !== undefined && { ethUsdAtBuy: data.ethUsdAtBuy }),
      ...(data.tokensReceived !== undefined && { tokensReceived: data.tokensReceived }),
      ...(data.status !== undefined && { status: data.status }),
      ...(data.errorMessage !== undefined && { errorMessage: data.errorMessage }),
      updatedAt: new Date(),
    })
    .where(eq(traderPositions.id, id));
}

export async function closePosition(
  id: string,
  data: {
    sellTxHash: string;
    sellPriceUsd: string;
    sellAmountEth: string;
    pnlEth: string;
    pnlPct: string;
    closeReason: string;
  },
) {
  await db
    .update(traderPositions)
    .set({
      status: "sold",
      sellTxHash: data.sellTxHash,
      sellPriceUsd: data.sellPriceUsd,
      sellAmountEth: data.sellAmountEth,
      pnlEth: data.pnlEth,
      pnlPct: data.pnlPct,
      closeReason: data.closeReason,
      closedAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(traderPositions.id, id));
}

export async function updatePositionTargets(
  id: string,
  fid: number,
  data: {
    takeProfitPct?: string | null;
    stopLossPct?: string | null;
    sellTargetPriceUsd?: string | null;
  },
) {
  await db
    .update(traderPositions)
    .set({
      ...(data.takeProfitPct !== undefined && { takeProfitPct: data.takeProfitPct }),
      ...(data.stopLossPct !== undefined && { stopLossPct: data.stopLossPct }),
      ...(data.sellTargetPriceUsd !== undefined && { sellTargetPriceUsd: data.sellTargetPriceUsd }),
      updatedAt: new Date(),
    })
    .where(and(eq(traderPositions.id, id), eq(traderPositions.fid, fid)));
}

export async function cancelPosition(id: string, fid: number) {
  await db
    .update(traderPositions)
    .set({ status: "cancelled", closedAt: new Date(), updatedAt: new Date() })
    .where(and(eq(traderPositions.id, id), eq(traderPositions.fid, fid)));
}

// Posisi yang butuh monitoring: pending_buy (tunggu trigger) atau active (monitoring sell)
export async function getActivePositions(fid: number) {
  return db
    .select()
    .from(traderPositions)
    .where(
      and(
        eq(traderPositions.fid, fid),
        or(
          eq(traderPositions.status, "pending_buy"),
          eq(traderPositions.status, "active"),
        ),
      ),
    )
    .orderBy(desc(traderPositions.createdAt));
}

export async function getAllMonitorablePositions() {
  return db
    .select()
    .from(traderPositions)
    .where(
      or(
        eq(traderPositions.status, "pending_buy"),
        eq(traderPositions.status, "active"),
      ),
    )
    .orderBy(desc(traderPositions.createdAt));
}

export async function getPositionHistory(fid: number, limit = 50) {
  return db
    .select()
    .from(traderPositions)
    .where(eq(traderPositions.fid, fid))
    .orderBy(desc(traderPositions.createdAt))
    .limit(limit);
}

export async function getPositionById(id: string) {
  const result = await db
    .select()
    .from(traderPositions)
    .where(eq(traderPositions.id, id))
    .limit(1);
  return result[0] ?? null;
}
