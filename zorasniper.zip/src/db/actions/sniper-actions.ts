// Server-side only — no "use server" directive (called from API routes, not client).

import { db } from "@/neynar-db-sdk/db";
import {
  watchedWallets,
  sniperSettings,
  snipeHistory,
  detectedDeployments,
} from "@/db/schema";
import { eq, and, desc, sql, ne } from "drizzle-orm";
import { isAddress } from "viem";

// ─── Watched Wallets ─────────────────────────────────────────────────────────

export async function getWatchedWallets(fid: number) {
  return db
    .select()
    .from(watchedWallets)
    .where(and(eq(watchedWallets.fid, fid), eq(watchedWallets.isActive, true)))
    .orderBy(desc(watchedWallets.createdAt));
}

export async function addWatchedWallet(
  fid: number,
  walletAddress: string,
  label?: string,
) {
  if (!isAddress(walletAddress)) {
    return { error: "Alamat wallet tidak valid (harus 42 karakter, awalan 0x)" };
  }

  const cleanAddress = walletAddress.toLowerCase();

  // Check duplicate
  const existing = await db
    .select()
    .from(watchedWallets)
    .where(
      and(
        eq(watchedWallets.fid, fid),
        eq(watchedWallets.walletAddress, cleanAddress),
        eq(watchedWallets.isActive, true),
      ),
    )
    .limit(1);

  if (existing.length > 0) {
    return { error: "Wallet sudah ada di watchlist" };
  }

  // Max 20 wallets per user
  const count = await db
    .select({ count: sql<number>`count(*)` })
    .from(watchedWallets)
    .where(
      and(eq(watchedWallets.fid, fid), eq(watchedWallets.isActive, true)),
    );

  if ((count[0]?.count ?? 0) >= 20) {
    return { error: "Maksimal 20 wallet per user" };
  }

  await db.insert(watchedWallets).values({
    fid,
    walletAddress: cleanAddress,
    label: label?.trim() || null,
    // Per-wallet settings default null (pakai global)
    buyAmountEth: null,
    maxBuysPerDay: null,
    slippageBps: null,
  });

  return { success: true };
}

export async function removeWatchedWallet(fid: number, walletId: string) {
  await db
    .update(watchedWallets)
    .set({ isActive: false })
    .where(
      and(eq(watchedWallets.fid, fid), eq(watchedWallets.id, walletId)),
    );
  return { success: true };
}

/**
 * Update per-wallet settings override
 * Pass null untuk hapus override (pakai global settings)
 */
export async function updateWalletSettings(
  fid: number,
  walletId: string,
  settings: {
    label?: string;
    buyAmountEth?: string | null;
    maxBuysPerDay?: number | null;
    slippageBps?: number | null;
  },
) {
  // Validate buy amount if provided
  if (settings.buyAmountEth !== undefined && settings.buyAmountEth !== null) {
    const amount = parseFloat(settings.buyAmountEth);
    if (isNaN(amount) || amount <= 0 || amount > 1) {
      return { error: "Buy amount harus antara 0 dan 1 ETH" };
    }
  }

  // Validate slippage if provided
  if (settings.slippageBps !== undefined && settings.slippageBps !== null) {
    if (settings.slippageBps < 50 || settings.slippageBps > 5000) {
      return { error: "Slippage harus antara 0.5% dan 50%" };
    }
  }

  // Validate maxBuysPerDay if provided
  if (settings.maxBuysPerDay !== undefined && settings.maxBuysPerDay !== null) {
    if (settings.maxBuysPerDay < 1 || settings.maxBuysPerDay > 100) {
      return { error: "Max buys per day harus antara 1 dan 100" };
    }
  }

  await db
    .update(watchedWallets)
    .set({
      ...(settings.label !== undefined && { label: settings.label.trim() || null }),
      ...(settings.buyAmountEth !== undefined && { buyAmountEth: settings.buyAmountEth }),
      ...(settings.maxBuysPerDay !== undefined && { maxBuysPerDay: settings.maxBuysPerDay }),
      ...(settings.slippageBps !== undefined && { slippageBps: settings.slippageBps }),
    })
    .where(
      and(eq(watchedWallets.fid, fid), eq(watchedWallets.id, walletId)),
    );

  return { success: true };
}

// ─── Sniper Settings ─────────────────────────────────────────────────────────

export async function getSniperSettings(fid: number) {
  const result = await db
    .select()
    .from(sniperSettings)
    .where(eq(sniperSettings.fid, fid))
    .limit(1);
  return result[0] ?? null;
}

export async function upsertSniperSettings(
  fid: number,
  settings: {
    isEnabled?: boolean;
    buyAmountEth?: string;
    slippageBps?: number;
    minLiquidityUsd?: number;
    privateKeyEncrypted?: string;
    walletAddress?: string;
    maxBuysPerDay?: number;
  },
) {
  // Validate buy amount
  if (settings.buyAmountEth !== undefined) {
    const amount = parseFloat(settings.buyAmountEth);
    if (isNaN(amount) || amount <= 0 || amount > 1) {
      return { error: "Buy amount harus antara 0 dan 1 ETH" };
    }
  }

  // Validate slippage
  if (settings.slippageBps !== undefined) {
    if (settings.slippageBps < 50 || settings.slippageBps > 5000) {
      return { error: "Slippage harus antara 0.5% dan 50%" };
    }
  }

  // Validate minLiquidityUsd
  if (settings.minLiquidityUsd !== undefined) {
    if (settings.minLiquidityUsd < 0 || settings.minLiquidityUsd > 1_000_000) {
      return { error: "Min liquidity harus antara $0 dan $1,000,000" };
    }
  }

  // Validate wallet address if provided
  if (settings.walletAddress && !isAddress(settings.walletAddress)) {
    return { error: "Wallet address tidak valid" };
  }

  await db
    .insert(sniperSettings)
    .values({
      fid,
      isEnabled: settings.isEnabled ?? false,
      buyAmountEth: settings.buyAmountEth ?? "0.001",
      slippageBps: settings.slippageBps ?? 500,
      minLiquidityUsd: settings.minLiquidityUsd ?? 5000,
      privateKeyEncrypted: settings.privateKeyEncrypted ?? null,
      walletAddress: settings.walletAddress ?? null,
      maxBuysPerDay: settings.maxBuysPerDay ?? 10,
    })
    .onConflictDoUpdate({
      target: sniperSettings.fid,
      set: {
        ...(settings.isEnabled !== undefined && { isEnabled: settings.isEnabled }),
        ...(settings.buyAmountEth !== undefined && { buyAmountEth: settings.buyAmountEth }),
        ...(settings.slippageBps !== undefined && { slippageBps: settings.slippageBps }),
        ...(settings.minLiquidityUsd !== undefined && { minLiquidityUsd: settings.minLiquidityUsd }),
        ...(settings.privateKeyEncrypted !== undefined && {
          privateKeyEncrypted: settings.privateKeyEncrypted,
        }),
        ...(settings.walletAddress !== undefined && { walletAddress: settings.walletAddress }),
        ...(settings.maxBuysPerDay !== undefined && { maxBuysPerDay: settings.maxBuysPerDay }),
        updatedAt: new Date(),
      },
    });

  return { success: true };
}

// ─── Snipe History ────────────────────────────────────────────────────────────

export async function getSnipeHistory(fid: number, limit = 50) {
  return db
    .select()
    .from(snipeHistory)
    .where(eq(snipeHistory.fid, fid))
    .orderBy(desc(snipeHistory.createdAt))
    .limit(limit);
}

export async function getSnipeStats(fid: number) {
  const history = await db
    .select()
    .from(snipeHistory)
    .where(eq(snipeHistory.fid, fid));

  const total = history.length;
  const success = history.filter((h) => h.status === "success").length;
  const failed = history.filter((h) => h.status === "failed").length;
  const totalSpentEth = history
    .filter((h) => h.status === "success")
    .reduce((acc, h) => acc + parseFloat(h.buyAmountEth ?? "0"), 0);

  return { total, success, failed, totalSpentEth };
}

export async function createSnipeRecord(data: {
  fid: number;
  triggeredByWallet: string;
  tokenAddress: string;
  tokenName?: string;
  tokenSymbol?: string;
  buyAmountEth: string;
}) {
  const result = await db
    .insert(snipeHistory)
    .values({
      fid: data.fid,
      triggeredByWallet: data.triggeredByWallet.toLowerCase(),
      tokenAddress: data.tokenAddress.toLowerCase(),
      tokenName: data.tokenName ?? null,
      tokenSymbol: data.tokenSymbol ?? null,
      buyAmountEth: data.buyAmountEth,
      status: "pending",
    })
    .returning();
  return result[0];
}

export async function updateSnipeRecord(
  id: string,
  update: {
    status: "success" | "failed";
    txHash?: string;
    tokensReceived?: string;
    errorMessage?: string;
  },
) {
  await db
    .update(snipeHistory)
    .set({
      status: update.status,
      txHash: update.txHash ?? null,
      tokensReceived: update.tokensReceived ?? null,
      errorMessage: update.errorMessage ?? null,
      updatedAt: new Date(),
    })
    .where(eq(snipeHistory.id, id));
}

// ─── Detected Deployments ─────────────────────────────────────────────────────

export async function saveDetectedDeployment(data: {
  deployerWallet: string;
  tokenAddress: string;
  tokenName?: string;
  tokenSymbol?: string;
  txHash: string;
  blockNumber?: number;
}) {
  // Check duplicate txHash — kalau sudah ada DAN sudah processed, return null
  // supaya poll route tidak memproses ulang deployment yang sama
  const existing = await db
    .select()
    .from(detectedDeployments)
    .where(eq(detectedDeployments.txHash, data.txHash))
    .limit(1);

  if (existing.length > 0) {
    // Sudah processed sebelumnya → return null agar poll route skip
    if (existing[0].processed) return null;
    // Belum processed (mungkin crash di tengah jalan) → return agar diproses ulang
    return existing[0];
  }

  const result = await db
    .insert(detectedDeployments)
    .values({
      deployerWallet: data.deployerWallet.toLowerCase(),
      tokenAddress: data.tokenAddress.toLowerCase(),
      tokenName: data.tokenName ?? null,
      tokenSymbol: data.tokenSymbol ?? null,
      txHash: data.txHash,
      blockNumber: data.blockNumber ?? null,
      processed: false,
    })
    .returning();

  return result[0];
}

export async function getUnprocessedDeployments() {
  return db
    .select()
    .from(detectedDeployments)
    .where(eq(detectedDeployments.processed, false))
    .orderBy(desc(detectedDeployments.detectedAt))
    .limit(100);
}

export async function markDeploymentProcessed(id: string) {
  await db
    .update(detectedDeployments)
    .set({ processed: true })
    .where(eq(detectedDeployments.id, id));
}

// Cek apakah FID sudah pernah berhasil beli token ini sebelumnya
// Mencegah double-buy saat token yang sama muncul lagi di queue atau scan ulang
export async function hasAlreadyBought(fid: number, tokenAddress: string): Promise<boolean> {
  const result = await db
    .select({ id: snipeHistory.id })
    .from(snipeHistory)
    .where(
      and(
        eq(snipeHistory.fid, fid),
        eq(snipeHistory.tokenAddress, tokenAddress.toLowerCase()),
        ne(snipeHistory.status, "failed"),
      ),
    )
    .limit(1);
  return result.length > 0;
}

// Get all active watchers for a specific wallet (including per-wallet settings)
export async function getWatchersForWallet(walletAddress: string) {
  return db
    .select({
      fid: watchedWallets.fid,
      walletAddress: watchedWallets.walletAddress,
      walletId: watchedWallets.id,
      // Per-wallet overrides (null = pakai global)
      walletBuyAmountEth: watchedWallets.buyAmountEth,
      walletMaxBuysPerDay: watchedWallets.maxBuysPerDay,
      walletSlippageBps: watchedWallets.slippageBps,
    })
    .from(watchedWallets)
    .where(
      and(
        eq(watchedWallets.walletAddress, walletAddress.toLowerCase()),
        eq(watchedWallets.isActive, true),
      ),
    );
}

// Get all active watched wallets (for the cron poller)
export async function getAllActiveWatchedWallets() {
  const results = await db
    .select({ walletAddress: watchedWallets.walletAddress })
    .from(watchedWallets)
    .where(eq(watchedWallets.isActive, true));

  // Return unique addresses
  const unique = [...new Set(results.map((r) => r.walletAddress))];
  return unique;
}
