import {
  pgTable,
  text,
  integer,
  timestamp,
  boolean,
  numeric,
  uuid,
} from "drizzle-orm/pg-core";

/**
 * Key-Value Store Table
 *
 * Built-in table for simple key-value storage.
 * Available immediately without schema changes.
 *
 * ⚠️ CRITICAL: DO NOT DELETE OR EDIT THIS TABLE DEFINITION ⚠️
 * This table is required for the app to function properly.
 * DO NOT delete, modify, rename, or change any part of this table.
 * Removing or editing it will cause database schema conflicts and prevent
 * the app from starting.
 *
 * Use for:
 * - User preferences/settings
 * - App configuration
 * - Simple counters
 * - Temporary data
 */
export const kv = pgTable("kv", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

/**
 * Watched wallets - daftar wallet yang dimonitor per user
 * Setiap wallet punya settings sendiri (buy amount, limit, slippage)
 * Kalau null → pakai global settings dari sniper_settings
 */
export const watchedWallets = pgTable("watched_wallets", {
  id: uuid("id").primaryKey().defaultRandom(),
  fid: integer("fid").notNull(),
  walletAddress: text("wallet_address").notNull(),
  label: text("label"),
  isActive: boolean("is_active").default(true).notNull(),
  // Per-wallet override settings (null = pakai global settings)
  buyAmountEth: numeric("buy_amount_eth", { precision: 18, scale: 8 }),
  maxBuysPerDay: integer("max_buys_per_day"),
  slippageBps: integer("slippage_bps"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * Sniper settings per user (global defaults)
 */
export const sniperSettings = pgTable("sniper_settings", {
  id: uuid("id").primaryKey().defaultRandom(),
  fid: integer("fid").notNull().unique(),
  isEnabled: boolean("is_enabled").default(false).notNull(),
  buyAmountEth: numeric("buy_amount_eth", { precision: 18, scale: 8 })
    .default("0.001")
    .notNull(),
  slippageBps: integer("slippage_bps").default(500).notNull(), // 500 = 5%
  minLiquidityUsd: integer("min_liquidity_usd").default(5000).notNull(), // default $5K min liquidity
  privateKeyEncrypted: text("private_key_encrypted"),
  walletAddress: text("wallet_address"),
  maxBuysPerDay: integer("max_buys_per_day").default(10).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/**
 * Snipe history - log semua snipe yang terjadi
 */
export const snipeHistory = pgTable("snipe_history", {
  id: uuid("id").primaryKey().defaultRandom(),
  fid: integer("fid").notNull(),
  triggeredByWallet: text("triggered_by_wallet").notNull(),
  tokenAddress: text("token_address").notNull(),
  tokenName: text("token_name"),
  tokenSymbol: text("token_symbol"),
  buyAmountEth: numeric("buy_amount_eth", { precision: 18, scale: 8 }).notNull(),
  tokensReceived: numeric("tokens_received", { precision: 78, scale: 0 }),
  txHash: text("tx_hash"),
  status: text("status").notNull().default("pending"), // pending | success | failed
  errorMessage: text("error_message"),
  ethPriceUsd: numeric("eth_price_usd", { precision: 12, scale: 4 }),
  currentValueEth: numeric("current_value_eth", { precision: 18, scale: 8 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/**
 * Web accounts — dipertahankan agar drizzle tidak drop tabel (backward compat)
 */
export const webAccounts = pgTable("web_accounts", {
  id: uuid("id").primaryKey().defaultRandom(),
  fid: integer("fid").notNull().unique(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/**
 * Email sessions — login via email OTP, terhubung ke FID
 * User input email + FID saat pertama kali, OTP dikirim untuk verifikasi
 */
export const emailSessions = pgTable("email_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull().unique(),
  fid: integer("fid").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * OTP codes — kode 6 digit sementara untuk verifikasi email
 * Expired setelah 10 menit
 */
export const otpCodes = pgTable("otp_codes", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull(),
  code: text("code").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * Auto Trader positions — setiap buy yang sedang aktif dimonitor
 * Support semua token di Base (Zora, Clanker, dll)
 */
export const traderPositions = pgTable("trader_positions", {
  id: uuid("id").primaryKey().defaultRandom(),
  fid: integer("fid").notNull(),
  tokenAddress: text("token_address").notNull(),
  tokenName: text("token_name"),
  tokenSymbol: text("token_symbol"),
  tokenPriceUsd: text("token_price_usd"), // harga USD saat lookup
  tokenImageUrl: text("token_image_url"),
  // Buy config
  buyAmountEth: numeric("buy_amount_eth", { precision: 18, scale: 8 }).notNull(),
  // Buy trigger: null = beli sekarang, isi = beli kalau harga turun ke angka ini (USD)
  buyTriggerPriceUsd: numeric("buy_trigger_price_usd", { precision: 20, scale: 8 }),
  // Sell targets — bisa pakai salah satu atau keduanya
  sellTargetPriceUsd: numeric("sell_target_price_usd", { precision: 20, scale: 8 }), // harga absolut
  takeProfitPct: numeric("take_profit_pct", { precision: 8, scale: 2 }),             // atau % profit
  stopLossPct: numeric("stop_loss_pct", { precision: 8, scale: 2 }),
  // Eksekusi buy
  buyTxHash: text("buy_tx_hash"),
  buyPriceUsd: numeric("buy_price_usd", { precision: 20, scale: 8 }), // harga aktual saat buy
  buyPriceEth: numeric("buy_price_eth", { precision: 30, scale: 18 }),
  ethUsdAtBuy: numeric("eth_usd_at_buy", { precision: 12, scale: 2 }), // ETH/USD rate saat buy dieksekusi
  tokensReceived: numeric("tokens_received", { precision: 78, scale: 0 }),
  // Status: pending_buy | active | sold | cancelled | buy_failed
  status: text("status").notNull().default("pending_buy"),
  // Eksekusi sell
  sellTxHash: text("sell_tx_hash"),
  sellPriceUsd: numeric("sell_price_usd", { precision: 20, scale: 8 }),
  sellAmountEth: numeric("sell_amount_eth", { precision: 18, scale: 8 }),
  pnlEth: numeric("pnl_eth", { precision: 18, scale: 8 }),
  pnlPct: numeric("pnl_pct", { precision: 8, scale: 2 }),
  closeReason: text("close_reason"), // take_profit | stop_loss | manual
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  closedAt: timestamp("closed_at"),
});

/**
 * Session tokens — dipakai setelah login email OTP berhasil
 * Setiap session punya token acak, terhubung ke FID, expired 30 hari
 */
export const sessionTokens = pgTable("session_tokens", {
  id: uuid("id").primaryKey().defaultRandom(),
  token: text("token").notNull().unique(),
  fid: integer("fid").notNull(),
  email: text("email").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * Token deploy events detected dari monitoring
 */
export const detectedDeployments = pgTable("detected_deployments", {
  id: uuid("id").primaryKey().defaultRandom(),
  deployerWallet: text("deployer_wallet").notNull(),
  tokenAddress: text("token_address").notNull(),
  tokenName: text("token_name"),
  tokenSymbol: text("token_symbol"),
  txHash: text("tx_hash").notNull(),
  blockNumber: integer("block_number"),
  detectedAt: timestamp("detected_at").defaultNow().notNull(),
  processed: boolean("processed").default(false).notNull(),
});

/**
 * Clanker sniper settings per user
 * Terpisah dari sniper settings utama — fitur sendiri, bisa dinonaktifkan
 */
export const clankerSniperSettings = pgTable("clanker_sniper_settings", {
  id: uuid("id").primaryKey().defaultRandom(),
  fid: integer("fid").notNull().unique(),
  isEnabled: boolean("is_enabled").default(false).notNull(),
  buyAmountEth: numeric("buy_amount_eth", { precision: 18, scale: 8 }).default("0.001").notNull(),
  slippageBps: integer("slippage_bps").default(500).notNull(),          // 500 = 5%
  maxBuysPerDay: integer("max_buys_per_day").default(5).notNull(),       // max snipe per hari, max 50
  minLiquidityUsd: integer("min_liquidity_usd").default(1000).notNull(), // min liquid threshold (USD)
  maxTokenAgeMin: integer("max_token_age_min").default(15).notNull(),    // 5 | 15 | 30 | 60 menit
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/**
 * Clanker watch list — token baru yang sedang dipantau, belum lolos filter volume.
 * Global (bukan per-FID) — satu entry per token address.
 * Tiap cron: token baru masuk sini, lalu semua di-re-cek sampai expired.
 */
export const clankerWatchList = pgTable("clanker_watch_list", {
  id: uuid("id").primaryKey().defaultRandom(),
  tokenAddress: text("token_address").notNull().unique(),
  tokenName: text("token_name"),
  tokenSymbol: text("token_symbol"),
  clankerTokenId: integer("clanker_token_id"),
  deployedAt: timestamp("deployed_at").notNull(),   // dari Clanker API deployed_at
  expiresAt: timestamp("expires_at").notNull(),     // deployedAt + maxTokenAge user terpanjang
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * Pump.fun sniper settings per user
 * Solana ecosystem — terpisah dari Clanker (EVM)
 */
export const pumpfunSniperSettings = pgTable("pumpfun_sniper_settings", {
  id: uuid("id").primaryKey().defaultRandom(),
  fid: integer("fid").notNull().unique(),
  isEnabled: boolean("is_enabled").default(false).notNull(),
  buyAmountSol: numeric("buy_amount_sol", { precision: 18, scale: 9 }).default("0.01").notNull(),
  slippageBps: integer("slippage_bps").default(1000).notNull(),        // 1000 = 10% (Solana perlu lebih tinggi)
  maxBuysPerDay: integer("max_buys_per_day").default(5).notNull(),
  minVolumeUsd: integer("min_volume_usd").default(1000).notNull(),     // min volume 1 jam (USD)
  maxTokenAgeMin: integer("max_token_age_min").default(15).notNull(),  // 5 | 15 | 30 | 60 menit
  // Solana wallet — terpisah dari EVM wallet
  solanaPrivateKey: text("solana_private_key"),    // encrypted base58 private key
  solanaWalletAddress: text("solana_wallet_address"), // public key (base58)
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/**
 * Pump.fun watch list — token baru yang sedang dipantau
 * Global (bukan per-FID) — satu entry per mint address
 */
export const pumpfunWatchList = pgTable("pumpfun_watch_list", {
  id: uuid("id").primaryKey().defaultRandom(),
  mintAddress: text("mint_address").notNull().unique(),   // Solana mint address
  tokenName: text("token_name"),
  tokenSymbol: text("token_symbol"),
  imageUri: text("image_uri"),
  marketCapUsd: integer("market_cap_usd"),               // dari Pump.fun API — proxy volume untuk token baru
  createdTimestamp: timestamp("created_timestamp").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * Pump.fun snipe log — semua token yang sudah dicoba snipe
 * Anti-duplicate: satu token hanya boleh di-snipe sekali per FID
 */
export const pumpfunSnipeLog = pgTable("pumpfun_snipe_log", {
  id: uuid("id").primaryKey().defaultRandom(),
  fid: integer("fid").notNull(),
  mintAddress: text("mint_address").notNull(),       // Solana mint address
  tokenName: text("token_name"),
  tokenSymbol: text("token_symbol"),
  volumeUsdAtSnipe: integer("volume_usd_at_snipe"),
  buyAmountSol: numeric("buy_amount_sol", { precision: 18, scale: 9 }).notNull(),
  txSignature: text("tx_signature"),                 // Solana tx signature (bukan hash)
  status: text("status").notNull().default("pending"), // pending | success | failed
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * Clanker snipe log — semua token yang sudah dicoba snipe
 * Anti-duplicate: satu token hanya boleh di-snipe sekali per FID
 */
export const clankerSnipeLog = pgTable("clanker_snipe_log", {
  id: uuid("id").primaryKey().defaultRandom(),
  fid: integer("fid").notNull(),
  tokenAddress: text("token_address").notNull(),
  tokenName: text("token_name"),
  tokenSymbol: text("token_symbol"),
  clankerTokenId: integer("clanker_token_id"), // ID dari Clanker API
  volumeUsdAtSnipe: integer("volume_usd_at_snipe"),
  buyAmountEth: numeric("buy_amount_eth", { precision: 18, scale: 8 }).notNull(),
  txHash: text("tx_hash"),
  status: text("status").notNull().default("pending"), // pending | success | failed | skipped
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
