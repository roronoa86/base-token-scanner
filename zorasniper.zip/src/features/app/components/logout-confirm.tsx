"use client";

interface Props {
  username: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export function LogoutConfirmModal({ username, onConfirm, onCancel }: Props) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6" onClick={onCancel}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-xs rounded-3xl p-6"
        style={{
          background: "linear-gradient(160deg,rgba(12,22,58,0.98),rgba(5,12,36,0.99))",
          border: "1px solid rgba(80,130,255,0.2)",
          boxShadow: "0 24px 60px rgba(0,0,0,0.7)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Icon */}
        <div className="flex justify-center mb-4">
          <div className="w-14 h-14 rounded-2xl bg-red-500/15 flex items-center justify-center text-3xl">
            🚪
          </div>
        </div>

        {/* Text */}
        <p className="text-white font-black text-lg text-center mb-1">Keluar?</p>
        <p className="text-white/50 text-sm text-center leading-relaxed mb-6">
          Kamu akan logout dari akun{" "}
          <span className="text-white/80 font-semibold">{username}</span>.
          <br />Bisa login lagi kapan saja.
        </p>

        {/* Buttons */}
        <div className="flex flex-col gap-2.5">
          <button
            onClick={onConfirm}
            className="w-full rounded-2xl py-3.5 text-sm font-black text-white transition-all active:scale-[0.97]"
            style={{
              background: "linear-gradient(135deg,#dc2626,#b91c1c)",
              boxShadow: "0 0 20px rgba(220,38,38,0.3)",
            }}
          >
            Ya, Keluar
          </button>
          <button
            onClick={onCancel}
            className="w-full rounded-2xl py-3.5 text-sm font-bold text-white/70 border border-white/10 hover:text-white hover:border-white/20 transition-all"
          >
            Batal
          </button>
        </div>
      </div>
    </div>
  );
}
