"use client";

import { useState } from "react";
import { isAddress } from "viem";
import type { WatchedWallet } from "@/features/app/types";
import { apiFetch } from "@/lib/api-client";

interface WatchlistTabProps {
  fid: number;
  wallets: WatchedWallet[];
  onWalletsChange: () => void;
  globalBuyAmountEth: string;
  globalMaxBuysPerDay: number;
  globalSlippageBps: number;
}

function truncateAddress(addr: string) {
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

function WalletCard({
  wallet, fid, onRemove, onUpdate,
  globalBuyAmountEth, globalMaxBuysPerDay, globalSlippageBps,
}: {
  wallet: WatchedWallet; fid: number;
  onRemove: (id: string) => void; onUpdate: () => void;
  globalBuyAmountEth: string; globalMaxBuysPerDay: number; globalSlippageBps: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [error, setError] = useState("");
  const [label, setLabel] = useState(wallet.label ?? "");
  const [buyAmount, setBuyAmount] = useState(wallet.buyAmountEth ?? "");
  const [maxBuys, setMaxBuys] = useState(
    wallet.maxBuysPerDay !== null ? String(wallet.maxBuysPerDay) : ""
  );
  const [slippage, setSlippage] = useState(
    wallet.slippageBps !== null ? String(wallet.slippageBps / 100) : ""
  );

  const hasOverride =
    wallet.buyAmountEth !== null ||
    wallet.maxBuysPerDay !== null ||
    wallet.slippageBps !== null;

  const handleSave = async () => {
    setSaving(true); setError("");
    try {
      const res = await apiFetch("/api/sniper/wallets", {
        method: "PATCH",
        body: JSON.stringify({
          fid, walletId: wallet.id,
          label: label || null,
          buyAmountEth: buyAmount.trim() !== "" ? buyAmount.trim() : null,
          maxBuysPerDay: maxBuys.trim() !== "" ? parseInt(maxBuys) : null,
          slippageBps: slippage.trim() !== "" ? Math.round(parseFloat(slippage) * 100) : null,
        }),
      });
      const data = await res.json();
      if (data.error) { setError(data.error); }
      else { setExpanded(false); onUpdate(); }
    } catch { setError("Gagal menyimpan"); }
    finally { setSaving(false); }
  };

  const handleRemove = async () => {
    setRemoving(true);
    try {
      await apiFetch("/api/sniper/wallets", {
        method: "DELETE",
        body: JSON.stringify({ fid, walletId: wallet.id }),
      });
      onRemove(wallet.id);
    } catch { /* silent */ }
    finally { setRemoving(false); }
  };

  const inputCls = "w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2 text-sm text-white placeholder-white/25 focus:border-[#0052FF]/60 focus:outline-none";

  return (
    <div className="glass rounded-xl overflow-hidden">
      <div className="flex items-center gap-3 p-3">
        <button onClick={() => setExpanded((v) => !v)}
          className="flex-1 flex flex-col items-start min-w-0 text-left">
          <div className="flex items-center gap-2 w-full">
            {wallet.label && (
              <span className="text-xs text-[#6b9fff] font-bold">{wallet.label}</span>
            )}
            {hasOverride && (
              <span className="text-[9px] rounded-full bg-[#0052FF]/20 text-[#0052FF] px-1.5 py-0.5 font-black border border-[#0052FF]/20">
                custom
              </span>
            )}
            <span className="ml-auto text-white/30 text-xs">{expanded ? "▲" : "▼"}</span>
          </div>
          <p className="font-mono text-sm font-bold text-white mt-0.5">
            {truncateAddress(wallet.walletAddress)}
          </p>
          <div className="flex gap-3 mt-1">
            <span className="text-[10px] text-white/75">
              💰 {wallet.buyAmountEth ?? globalBuyAmountEth} ETH
            </span>
            <span className="text-[10px] text-white/75">
              🔁 max {wallet.maxBuysPerDay ?? globalMaxBuysPerDay}x
            </span>
            <span className="text-[10px] text-white/75">
              📉 {((wallet.slippageBps ?? globalSlippageBps) / 100).toFixed(1)}%
            </span>
          </div>
        </button>

        <button onClick={handleRemove} disabled={removing}
          className="flex-shrink-0 rounded-lg border border-[#ff3b5c]/30 p-2 text-[#ff3b5c] hover:bg-[#ff3b5c]/15 disabled:opacity-50 transition-colors">
          {removing ? <span className="text-xs">...</span> : <span className="text-sm">🗑</span>}
        </button>
      </div>

      {expanded && (
        <div className="border-t border-[#0052FF]/15 p-3 flex flex-col gap-3 bg-[#0052FF]/5">
          <p className="text-xs text-white/70 font-bold">⚙️ Pengaturan khusus wallet ini</p>
          <p className="text-[10px] text-white/70">Kosongkan untuk mengikuti pengaturan global</p>
          <div>
            <label className="text-[10px] text-[#6b9fff]/70 mb-1 block font-bold uppercase tracking-wide">Label</label>
            <input type="text" value={label} onChange={(e) => setLabel(e.target.value)}
              placeholder="Nama wallet (opsional)" className={inputCls} />
          </div>
          <div>
            <label className="text-[10px] text-[#6b9fff]/70 mb-1 block font-bold uppercase tracking-wide">
              Buy Amount (ETH) <span className="text-white/55 font-normal">— global: {globalBuyAmountEth}</span>
            </label>
            <input type="number" value={buyAmount} onChange={(e) => setBuyAmount(e.target.value)}
              placeholder={`Kosong = ${globalBuyAmountEth} ETH`} step="0.0001" min="0.0001" max="1" className={inputCls} />
          </div>
          <div>
            <label className="text-[10px] text-[#6b9fff]/70 mb-1 block font-bold uppercase tracking-wide">
              Max Buy/Hari <span className="text-white/55 font-normal">— global: {globalMaxBuysPerDay}x</span>
            </label>
            <input type="number" value={maxBuys} onChange={(e) => setMaxBuys(e.target.value)}
              placeholder={`Kosong = ${globalMaxBuysPerDay}x`} step="1" min="1" max="100" className={inputCls} />
          </div>
          <div>
            <label className="text-[10px] text-[#6b9fff]/70 mb-1 block font-bold uppercase tracking-wide">
              Slippage (%) <span className="text-white/55 font-normal">— global: {(globalSlippageBps / 100).toFixed(1)}%</span>
            </label>
            <input type="number" value={slippage} onChange={(e) => setSlippage(e.target.value)}
              placeholder={`Kosong = ${(globalSlippageBps / 100).toFixed(1)}%`} step="0.5" min="0.5" max="50" className={inputCls} />
          </div>
          {error && <p className="text-xs text-[#ff3b5c] bg-[#ff3b5c]/10 rounded-lg px-3 py-1.5">{error}</p>}
          <div className="flex gap-2">
            <button onClick={handleSave} disabled={saving}
              className="flex-1 rounded-lg bg-[#0052FF] py-2 text-sm font-black text-white shadow-[0_0_10px_rgba(0,82,255,0.30)] hover:opacity-90 disabled:opacity-50 transition-all">
              {saving ? "Menyimpan..." : "Simpan"}
            </button>
            <button onClick={() => setExpanded(false)}
              className="rounded-lg border border-[#0052FF]/20 px-4 py-2 text-sm text-white/60 hover:text-white transition-colors">
              Batal
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export function WatchlistTab({
  fid, wallets, onWalletsChange,
  globalBuyAmountEth, globalMaxBuysPerDay, globalSlippageBps,
}: WatchlistTabProps) {
  const [newAddress, setNewAddress] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleAdd = async () => {
    setError("");
    const trimmed = newAddress.trim();
    if (!trimmed) { setError("Masukkan wallet address"); return; }
    if (!isAddress(trimmed)) { setError("Address tidak valid. Harus 42 karakter, awalan 0x"); return; }
    setLoading(true);
    try {
      const res = await apiFetch("/api/sniper/wallets", {
        method: "POST",
        body: JSON.stringify({ fid, walletAddress: trimmed, label: newLabel }),
      });
      const data = await res.json();
      if (data.error) { setError(data.error); }
      else { setNewAddress(""); setNewLabel(""); onWalletsChange(); }
    } catch { setError("Gagal menambahkan wallet"); }
    finally { setLoading(false); }
  };

  return (
    <div className="flex flex-col gap-4 p-4">
      <div>
        <p className="text-[10px] text-[#6b9fff]/60 uppercase tracking-widest mb-1 font-semibold">Watchlist</p>
        <p className="text-xs text-white/50">
          Pantau wallet target. Tiap wallet bisa punya pengaturan sendiri — tekan untuk edit.
        </p>
      </div>

      <div className="glass rounded-2xl p-4 flex flex-col gap-3">
        <input type="text" placeholder="0x... (wallet address)"
          value={newAddress} onChange={(e) => { setNewAddress(e.target.value); setError(""); }}
          className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2.5 font-mono text-sm text-white placeholder-white/25 focus:border-[#0052FF]/60 focus:outline-none"
        />
        <input type="text" placeholder="Label (opsional, misal: whale_1)"
          value={newLabel} onChange={(e) => setNewLabel(e.target.value)}
          className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2.5 text-sm text-white placeholder-white/25 focus:border-[#0052FF]/60 focus:outline-none"
        />
        {error && <p className="text-xs text-[#ff3b5c] bg-[#ff3b5c]/10 rounded-lg px-3 py-1.5">{error}</p>}
        <button onClick={handleAdd} disabled={loading}
          className="w-full rounded-xl bg-[#0052FF] py-2.5 text-sm font-black text-white shadow-[0_0_16px_rgba(0,82,255,0.35)] hover:bg-[#0047e0] disabled:opacity-50 transition-all">
          {loading ? "Menambahkan..." : "+ Tambah Wallet"}
        </button>
      </div>

      <div className="flex flex-col gap-2">
        {wallets.length === 0 ? (
          <div className="glass rounded-2xl p-8 text-center border border-dashed border-[#0052FF]/20">
            <p className="text-2xl mb-2">👁</p>
            <p className="text-sm text-white/50 font-bold">Belum ada wallet yang dipantau</p>
            <p className="text-xs text-white/30 mt-1">Tambah wallet di atas untuk mulai</p>
          </div>
        ) : (
          wallets.map((wallet) => (
            <WalletCard key={wallet.id} wallet={wallet} fid={fid}
              onRemove={() => onWalletsChange()} onUpdate={onWalletsChange}
              globalBuyAmountEth={globalBuyAmountEth}
              globalMaxBuysPerDay={globalMaxBuysPerDay}
              globalSlippageBps={globalSlippageBps} />
          ))
        )}
      </div>
    </div>
  );
}
