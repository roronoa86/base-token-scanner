"use client";

import { useState, useRef } from "react";

const PRESETS = [
  { id: "1779667332438.png", label: "Nebula", emoji: "🌌" },
  { id: "1779525414670.jpg", label: "Dark City", emoji: "🌃" },
  { id: "1779612476364.jpg", label: "Neon Grid", emoji: "⚡" },
] as const;

interface Props {
  fid: number;
  currentBg: string;        // preset id or "custom"
  currentDataUrl?: string;  // only if currentBg === "custom"
  onClose: () => void;
  onSelect: (bgId: string, dataUrl?: string) => void;
}

export function BackgroundPicker({ fid, currentBg, currentDataUrl, onClose, onSelect }: Props) {
  const [saving, setSaving]     = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError]       = useState("");
  const fileInputRef            = useRef<HTMLInputElement>(null);

  const savePreset = async (bgId: string) => {
    setSaving(true);
    setError("");
    try {
      await fetch("/api/user/background", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fid, bgId }),
      });
      onSelect(bgId);
      onClose();
    } catch {
      onSelect(bgId);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError("");

    try {
      const form = new FormData();
      form.append("fid", String(fid));
      form.append("file", file);

      const res = await fetch("/api/user/background/upload", {
        method: "POST",
        body: form,
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Upload gagal");
        return;
      }

      onSelect("custom", data.dataUrl);
      onClose();
    } catch {
      setError("Upload gagal, coba lagi");
    } finally {
      setUploading(false);
      // reset input so same file can be re-selected
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleRemoveCustom = async () => {
    setSaving(true);
    setError("");
    try {
      await fetch(`/api/user/background/upload?fid=${fid}`, { method: "DELETE" });
      // fall back to first preset
      await fetch("/api/user/background", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fid, bgId: PRESETS[0].id }),
      });
      onSelect(PRESETS[0].id);
      onClose();
    } catch {
      onSelect(PRESETS[0].id);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  const busy = saving || uploading;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />

      <div
        className="relative w-full max-w-sm rounded-t-3xl p-6 pb-10"
        style={{
          background: "linear-gradient(180deg,rgba(10,20,55,0.98),rgba(4,10,32,0.99))",
          border: "1px solid rgba(80,130,255,0.2)",
          borderBottom: "none",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Handle */}
        <div className="mx-auto mb-5 h-1 w-10 rounded-full bg-white/20" />

        <p className="text-white font-black text-base mb-0.5">Ganti Background</p>
        <p className="text-white/40 text-xs mb-5">Tersimpan di semua device kamu</p>

        {/* Upload section */}
        <div className="mb-4">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif"
            className="hidden"
            onChange={handleUpload}
          />

          {currentBg === "custom" && currentDataUrl ? (
            // Shows custom thumbnail + replace/remove options
            <div
              className="relative flex items-center gap-4 rounded-2xl overflow-hidden mb-1"
              style={{ border: "2px solid rgba(0,82,255,0.8)", boxShadow: "0 0 20px rgba(0,82,255,0.25)" }}
            >
              <div className="w-24 h-16 shrink-0 overflow-hidden">
                <img src={currentDataUrl} alt="Custom" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-white font-bold text-sm">📸 Foto Kamu</p>
                <p className="text-[#0052FF] text-xs font-semibold mt-0.5">Aktif sekarang</p>
              </div>
              <div className="mr-3 flex flex-col gap-1.5">
                <button
                  onClick={() => !busy && fileInputRef.current?.click()}
                  disabled={busy}
                  className="text-[10px] font-bold text-white/70 border border-white/15 rounded-lg px-2.5 py-1 hover:text-white hover:border-white/30 transition-all"
                >
                  Ganti
                </button>
                <button
                  onClick={() => !busy && handleRemoveCustom()}
                  disabled={busy}
                  className="text-[10px] font-bold text-red-400/80 border border-red-500/20 rounded-lg px-2.5 py-1 hover:text-red-400 hover:border-red-500/40 transition-all"
                >
                  Hapus
                </button>
              </div>
            </div>
          ) : (
            // Upload button
            <button
              onClick={() => !busy && fileInputRef.current?.click()}
              disabled={busy}
              className="w-full flex items-center gap-4 rounded-2xl p-4 transition-all active:scale-[0.98] disabled:opacity-50"
              style={{
                background: "rgba(0,82,255,0.08)",
                border: "2px dashed rgba(0,82,255,0.35)",
              }}
            >
              <div className="w-10 h-10 rounded-xl bg-[#0052FF]/20 flex items-center justify-center shrink-0 text-xl">
                {uploading ? "⏳" : "📸"}
              </div>
              <div className="text-left">
                <p className="text-white font-bold text-sm">
                  {uploading ? "Mengupload..." : "Upload Foto Sendiri"}
                </p>
                <p className="text-white/40 text-xs mt-0.5">JPG, PNG, WebP — maks 3MB</p>
              </div>
            </button>
          )}
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1 h-px bg-white/10" />
          <p className="text-white/30 text-xs font-semibold">atau pilih preset</p>
          <div className="flex-1 h-px bg-white/10" />
        </div>

        {/* Presets */}
        <div className="flex flex-col gap-3">
          {PRESETS.map((bg) => {
            const isActive = currentBg === bg.id;
            return (
              <button
                key={bg.id}
                onClick={() => !busy && savePreset(bg.id)}
                disabled={busy}
                className="relative flex items-center gap-4 rounded-2xl overflow-hidden transition-all active:scale-[0.98] disabled:opacity-50"
                style={{
                  border: isActive
                    ? "2px solid rgba(0,82,255,0.8)"
                    : "2px solid rgba(255,255,255,0.08)",
                  boxShadow: isActive ? "0 0 20px rgba(0,82,255,0.25)" : "none",
                }}
              >
                <div className="w-24 h-16 shrink-0 overflow-hidden">
                  <img src={`/${bg.id}`} alt={bg.label} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-white font-bold text-sm">{bg.emoji} {bg.label}</p>
                  {isActive && (
                    <p className="text-[#0052FF] text-xs font-semibold mt-0.5">Aktif sekarang</p>
                  )}
                </div>
                {isActive && (
                  <div className="mr-4 w-5 h-5 rounded-full bg-[#0052FF] flex items-center justify-center shrink-0">
                    <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                      <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {error && (
          <p className="text-red-400 text-xs font-semibold text-center mt-4">{error}</p>
        )}
      </div>
    </div>
  );
}
