"use client";

import { useState, useEffect, useCallback } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────

type TrendingFilter = "24h" | "2d" | "vol24h";

interface ClankerToken {
  id: number;
  name: string;
  symbol: string;
  contract_address: string;
  img_url: string | null;
  cast_hash: string | null;
  created_at: string;
  // price data from DexScreener
  priceUsd: number;
  marketCap: number;
  volume24h: number;
  volume6h: number;
  priceChange24h: number;
  priceChange1h: number;
  liquidity: number;
  age: string;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmtUsd(v: number): string {
  if (v >= 1_000_000_000) return `$${(v / 1_000_000_000).toFixed(2)}B`;
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(2)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(1)}K`;
  return `$${v.toFixed(2)}`;
}

function fmtPrice(v: number): string {
  if (v === 0) return "$0";
  if (v < 0.000001) return `$${v.toExponential(2)}`;
  if (v < 0.001) return `$${v.toFixed(7)}`;
  if (v < 1) return `$${v.toFixed(5)}`;
  return `$${v.toFixed(3)}`;
}

function fmtAge(createdAt: string): string {
  const diffMs  = Date.now() - new Date(createdAt).getTime();
  const diffMin = Math.floor(diffMs / 60_000);
  const diffH   = Math.floor(diffMs / 3_600_000);
  const diffD   = Math.floor(diffMs / 86_400_000);
  if (diffMin < 60)  return `${diffMin}m`;
  if (diffH < 24)    return `${diffH}h`;
  if (diffD < 30)    return `${diffD}d`;
  return `${Math.floor(diffD / 30)}mo`;
}

// ─── Token Card ───────────────────────────────────────────────────────────────

function TokenCard({
  token,
  rank,
  filter,
}: {
  token: ClankerToken;
  rank: number;
  filter: TrendingFilter;
}) {
  const [expanded, setExpanded]   = useState(false);
  const [copied, setCopied]       = useState(false);

  const pos24h = token.priceChange24h >= 0;
  const pos1h  = token.priceChange1h  >= 0;
  const volHighlight = token.volume24h;
  const zoraUrl = `https://zora.co/coin/base:${token.contract_address}`;

  const copyCA = async () => {
    try {
      await navigator.clipboard.writeText(token.contract_address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* silent */ }
  };

  return (
    <div className={`glass rounded-xl overflow-hidden transition-all ${expanded ? "ring-1 ring-[#0052FF]/40" : ""}`}>
      {/* ── Collapsed row (always visible, click to expand) ── */}
      <button
        onClick={() => setExpanded((v) => !v)}
        className="w-full p-3 text-left"
      >
        <div className="flex items-center gap-2.5">
          {/* Rank */}
          <span className="text-[10px] font-black text-white/30 w-4 shrink-0 text-center">
            {rank}
          </span>

          {/* Logo */}
          {token.img_url ? (
            <img src={token.img_url} alt={token.symbol}
              className="w-9 h-9 rounded-full shrink-0 ring-1 ring-[#0052FF]/25" />
          ) : (
            <div className="w-9 h-9 rounded-full bg-[#0052FF]/20 border border-[#0052FF]/25 flex items-center justify-center shrink-0 text-base">
              🪙
            </div>
          )}

          {/* Name + symbol + age */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-black text-white text-sm leading-tight truncate max-w-[110px]">
                {token.name}
              </span>
              <span className="text-[#6b9fff] font-bold text-[10px]">${token.symbol}</span>
            </div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-[9px] text-white/40 font-mono">
                {token.contract_address.slice(0, 6)}…{token.contract_address.slice(-4)}
              </span>
              <span className="text-[9px] font-bold text-white/40">·</span>
              <span className="text-[9px] font-bold text-white/50">{token.age}</span>
            </div>
          </div>

          {/* Price + change + chevron */}
          <div className="text-right shrink-0 flex flex-col items-end gap-0.5">
            <p className="text-white font-black text-sm leading-tight">{fmtPrice(token.priceUsd)}</p>
            <div className="flex gap-1 justify-end">
              {token.priceChange1h !== 0 && (
                <span className={`text-[9px] font-bold ${pos1h ? "text-[#00ff87]" : "text-[#ff3b5c]"}`}>
                  {pos1h ? "▲" : "▼"}{Math.abs(token.priceChange1h).toFixed(1)}%
                </span>
              )}
              {token.priceChange24h !== 0 && (
                <span className={`text-[9px] font-bold ${pos24h ? "text-[#00ff87]" : "text-[#ff3b5c]"}`}>
                  {pos24h ? "▲" : "▼"}{Math.abs(token.priceChange24h).toFixed(1)}% 24h
                </span>
              )}
            </div>
            <span className={`text-[9px] text-white/30 mt-0.5 transition-transform ${expanded ? "rotate-180" : ""}`}>▼</span>
          </div>
        </div>
      </button>

      {/* ── Expanded detail panel ── */}
      {expanded && (
        <div className="px-3 pb-3 border-t border-[#0052FF]/15 pt-3 flex flex-col gap-3">

          {/* Contract Address — full, copyable */}
          <div>
            <p className="text-[9px] font-black uppercase tracking-wider text-[#6b9fff] mb-1">Contract Address</p>
            <div className="flex items-center gap-2 glass-cell rounded-lg px-3 py-2">
              <span className="flex-1 text-[10px] font-mono text-white/85 break-all leading-relaxed">
                {token.contract_address}
              </span>
              <button
                onClick={copyCA}
                className={`shrink-0 rounded-lg px-2.5 py-1.5 text-[10px] font-black transition-all ${
                  copied
                    ? "bg-[#00ff87]/20 text-[#00ff87] border border-[#00ff87]/30"
                    : "bg-[#0052FF]/20 text-[#6b9fff] border border-[#0052FF]/25 hover:bg-[#0052FF]/35"
                }`}
              >
                {copied ? "✓ Copied" : "Copy"}
              </button>
            </div>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-3 gap-1.5">
            <div className="glass-cell rounded-lg p-2 text-center">
              <p className="text-[8px] font-bold uppercase tracking-wide text-[#6b9fff]">MC</p>
              <p className="text-white font-black text-[11px] leading-tight">{fmtUsd(token.marketCap)}</p>
            </div>
            <div className={`glass-cell rounded-lg p-2 text-center ${filter === "vol24h" ? "ring-1 ring-[#0052FF]/30" : ""}`}>
              <p className="text-[8px] font-bold uppercase tracking-wide text-[#6b9fff]">Vol 24h</p>
              <p className="text-white font-black text-[11px] leading-tight">{fmtUsd(volHighlight)}</p>
            </div>
            <div className="glass-cell rounded-lg p-2 text-center">
              <p className="text-[8px] font-bold uppercase tracking-wide text-[#6b9fff]">Liq</p>
              <p className="text-white font-black text-[11px] leading-tight">{fmtUsd(token.liquidity)}</p>
            </div>
          </div>

          {/* Vol 6h + Usia */}
          {token.volume6h > 0 && (
            <div className="grid grid-cols-2 gap-1.5">
              <div className="glass-cell rounded-lg p-2 text-center">
                <p className="text-[8px] font-bold uppercase tracking-wide text-[#6b9fff]">Vol 6h</p>
                <p className="text-white font-black text-[11px] leading-tight">{fmtUsd(token.volume6h)}</p>
              </div>
              <div className="glass-cell rounded-lg p-2 text-center">
                <p className="text-[8px] font-bold uppercase tracking-wide text-[#6b9fff]">Usia</p>
                <p className="text-white font-black text-[11px] leading-tight">{token.age}</p>
              </div>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex gap-2">
            <a
              href={zoraUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 rounded-lg bg-[#0052FF]/15 border border-[#0052FF]/25 py-2 text-[10px] font-black text-[#6b9fff] text-center hover:bg-[#0052FF]/25 transition-all"
            >
              🔗 Zora
            </a>
            <a
              href={`https://dexscreener.com/base/${token.contract_address}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 rounded-lg bg-white/5 border border-white/10 py-2 text-[10px] font-black text-white/65 text-center hover:bg-white/10 transition-all"
            >
              📊 Chart
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main Trending Tab ────────────────────────────────────────────────────────

export function TrendingTab() {
  const [filter, setFilter]   = useState<TrendingFilter>("vol24h");
  const [tokens, setTokens]   = useState<ClankerToken[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    setTokens([]);
    try {
      const res  = await fetch(`/api/trending/clanker?filter=${filter}`);
      const data = await res.json();
      if (!res.ok || data.error) { setError(data.error ?? "Gagal memuat data"); return; }
      // Client-side dedup safety: deduplicate by contract_address
      const raw: ClankerToken[] = data.tokens ?? [];
      const seen = new Set<string>();
      const unique = raw.filter((t) => {
        const addr = t.contract_address.toLowerCase();
        if (seen.has(addr)) return false;
        seen.add(addr);
        return true;
      });
      setTokens(unique);
      setLastUpdate(new Date());
    } catch {
      setError("Koneksi gagal");
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  const FILTERS: { id: TrendingFilter; label: string; desc: string }[] = [
    { id: "vol24h", label: "🔥 Vol 24h",  desc: "Semua Zora Coins · volume 24h tertinggi"  },
    { id: "24h",    label: "🆕 Baru 24h", desc: "Zora Coins baru 24h · vol tertinggi"      },
    { id: "2d",     label: "📅 Baru 2 Hari", desc: "Zora Coins baru 2 hari · vol tertinggi" },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Filter tabs */}
      <div className="glass-header px-3 py-2.5">
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`shrink-0 rounded-lg px-3 py-1.5 text-[11px] font-black transition-all ${
                filter === f.id
                  ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.4)]"
                  : "bg-white/5 border border-white/10 text-white/65 hover:text-white hover:bg-white/10"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="flex items-center justify-between mt-1.5">
          <p className="text-[9px] text-white/35 font-semibold">
            {FILTERS.find((f) => f.id === filter)?.desc}
          </p>
          {lastUpdate && (
            <p className="text-[9px] text-white/30">
              Update {lastUpdate.toLocaleTimeString("id", { hour: "2-digit", minute: "2-digit" })}
            </p>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2.5">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3">
            <div className="text-3xl animate-pulse">🔥</div>
            <p className="text-white/65 text-sm font-bold">Memuat trending...</p>
          </div>
        ) : error ? (
          <div className="glass rounded-xl px-4 py-6 text-center">
            <p className="text-[#ff3b5c] text-sm font-bold mb-2">⚠️ {error}</p>
            <button onClick={load}
              className="rounded-lg bg-[#0052FF]/20 border border-[#0052FF]/25 px-4 py-2 text-xs font-bold text-[#6b9fff] hover:bg-[#0052FF]/30 transition-all">
              Coba lagi
            </button>
          </div>
        ) : tokens.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-3xl mb-3">😶</div>
            <p className="text-white/65 text-sm font-bold">Tidak ada token ditemukan</p>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between px-1">
              <p className="text-[10px] font-black text-white/50 uppercase tracking-wider">
                {tokens.length} Zora Coins
              </p>
              <button onClick={load} disabled={loading}
                className="text-[10px] font-bold text-[#6b9fff]/70 hover:text-[#6b9fff] disabled:opacity-40 transition-colors">
                ↻ Refresh
              </button>
            </div>
            {tokens.map((t, i) => (
              <TokenCard key={`${t.contract_address}-${i}`} token={t} rank={i + 1} filter={filter} />
            ))}
          </>
        )}
      </div>
    </div>
  );
}
