"use client";

import { useState, useEffect } from "react";
import type { SniperSettings } from "@/features/app/types";
import { apiFetch } from "@/lib/api-client";

interface SettingsTabProps {
  fid: number;
  settings: SniperSettings | null;
  onSettingsChange: () => void;
}

export function SettingsTab({ fid, settings, onSettingsChange }: SettingsTabProps) {
  const [buyAmount, setBuyAmount] = useState(settings?.buyAmountEth ?? "0.001");
  const [slippage, setSlippage] = useState(
    settings ? (settings.slippageBps / 100).toString() : "5",
  );
  const [maxBuys, setMaxBuys] = useState(settings?.maxBuysPerDay?.toString() ?? "10");
  const [minLiquidity, setMinLiquidity] = useState(settings?.minLiquidityUsd?.toString() ?? "5000");
  const [privateKey, setPrivateKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Email linking
  const [linkEmail, setLinkEmail] = useState("");
  const [linkOtp, setLinkOtp] = useState("");
  const [linkStep, setLinkStep] = useState<"email" | "otp">("email");
  const [linkLoading, setLinkLoading] = useState(false);
  const [linkError, setLinkError] = useState("");
  const [linkSuccess, setLinkSuccess] = useState("");
  const [linkedEmail, setLinkedEmail] = useState<string | null>(null);

  useEffect(() => {
    // Cek apakah FID ini sudah punya email terhubung
    fetch(`/api/auth/linked-email?fid=${fid}`)
      .then(r => r.json())
      .then(d => { if (d.email) setLinkedEmail(d.email); })
      .catch(() => {});
  }, [fid]);

  const handleSendLinkOtp = async () => {
    setLinkError("");
    setLinkLoading(true);
    try {
      const res = await apiFetch("/api/auth/link-email", {
        method: "POST",
        body: JSON.stringify({ fid, email: linkEmail.trim(), step: "send" }),
      });
      const data = await res.json();
      if (!res.ok) { setLinkError(data.error ?? "Gagal mengirim kode"); return; }
      setLinkStep("otp");
    } catch { setLinkError("Gagal terhubung ke server"); }
    finally { setLinkLoading(false); }
  };

  const handleVerifyLinkOtp = async () => {
    setLinkError("");
    setLinkLoading(true);
    try {
      const res = await apiFetch("/api/auth/link-email", {
        method: "POST",
        body: JSON.stringify({ fid, email: linkEmail.trim(), code: linkOtp.trim(), step: "verify" }),
      });
      const data = await res.json();
      if (!res.ok) { setLinkError(data.error ?? "Kode salah"); return; }
      setLinkedEmail(linkEmail.trim().toLowerCase());
      setLinkSuccess("Email berhasil ditautkan!");
      setLinkEmail(""); setLinkOtp(""); setLinkStep("email");
    } catch { setLinkError("Gagal terhubung ke server"); }
    finally { setLinkLoading(false); }
  };

  useEffect(() => {
    if (settings) {
      setBuyAmount(settings.buyAmountEth);
      setSlippage((settings.slippageBps / 100).toString());
      setMaxBuys(settings.maxBuysPerDay.toString());
      setMinLiquidity((settings.minLiquidityUsd ?? 5000).toString());
    }
  }, [settings]);

  const handleSave = async () => {
    setSaveError("");
    setSaveSuccess(false);
    const buyAmt = parseFloat(buyAmount);
    if (isNaN(buyAmt) || buyAmt < 0.0001 || buyAmt > 0.5) {
      setSaveError("Buy amount minimum 0.0001 ETH");
      return;
    }
    const slip = parseFloat(slippage);
    if (isNaN(slip) || slip < 0.5 || slip > 50) {
      setSaveError("Slippage harus antara 0.5% dan 50%");
      return;
    }
    const maxB = parseInt(maxBuys);
    if (isNaN(maxB) || maxB < 1 || maxB > 100) {
      setSaveError("Max buys harus antara 1 dan 100");
      return;
    }
    const minLiq = parseInt(minLiquidity);
    if (isNaN(minLiq) || minLiq < 0 || minLiq > 1_000_000) {
      setSaveError("Min liquidity harus antara $0 dan $1,000,000");
      return;
    }
    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        fid,
        buyAmountEth: buyAmt.toFixed(6),
        slippageBps: Math.round(slip * 100),
        maxBuysPerDay: maxB,
        minLiquidityUsd: minLiq,
      };
      if (privateKey.trim()) payload.privateKey = privateKey.trim();
      const res = await apiFetch("/api/sniper/settings", {
        method: "POST",
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.error) {
        setSaveError(data.error);
      } else {
        setSaveSuccess(true);
        setPrivateKey("");
        onSettingsChange();
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch {
      setSaveError("Gagal menyimpan settings");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 p-4">
      <p className="text-[10px] text-[#6b9fff]/60 uppercase tracking-widest font-semibold">Pengaturan Sniper</p>

      {/* Buy amount */}
      <div className="glass rounded-2xl p-4">
        <label className="block text-sm font-black text-white mb-1">Buy Amount (ETH)</label>
        <p className="text-xs text-white/75 mb-3">Min 0.0001 ETH per snipe. Disarankan minimal 0.001 ETH.</p>
        <div className="relative mb-2">
          <input
            type="number"
            value={buyAmount}
            onChange={(e) => setBuyAmount(e.target.value)}
            step="0.0001" min="0.0001" max="0.5"
            className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2.5 pr-14 font-mono text-sm text-white focus:border-[#0052FF]/60 focus:outline-none"
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#6b9fff]/50 font-bold">ETH</span>
        </div>
        <div className="flex gap-2">
          {["0.0001", "0.0005", "0.001", "0.005"].map((v) => (
            <button key={v} onClick={() => setBuyAmount(v)}
              className={`flex-1 rounded-lg py-1.5 text-[11px] font-black font-mono transition-all ${
                buyAmount === v
                  ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.35)]"
                  : "glass-cell text-white/75 hover:text-white/70"
              }`}>
              {v}
            </button>
          ))}
        </div>
      </div>

      {/* Slippage */}
      <div className="glass rounded-2xl p-4">
        <label className="block text-sm font-black text-white mb-1">Slippage Tolerance</label>
        <p className="text-xs text-white/75 mb-3">New token volatile: 5–20% aman.</p>
        <div className="relative mb-2">
          <input
            type="number"
            value={slippage}
            onChange={(e) => setSlippage(e.target.value)}
            step="0.5" min="0.5" max="50"
            className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2.5 pr-8 font-mono text-sm text-white focus:border-[#0052FF]/60 focus:outline-none"
          />
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#6b9fff]/50 font-bold">%</span>
        </div>
        <div className="flex gap-2">
          {["1", "3", "5", "10", "20"].map((v) => (
            <button key={v} onClick={() => setSlippage(v)}
              className={`flex-1 rounded-lg py-1.5 text-[11px] font-black font-mono transition-all ${
                slippage === v
                  ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.35)]"
                  : "glass-cell text-white/75 hover:text-white/70"
              }`}>
              {v}%
            </button>
          ))}
        </div>
      </div>

      {/* Max buys */}
      <div className="glass rounded-2xl p-4">
        <label className="block text-sm font-black text-white mb-1">Maks Snipe per Hari</label>
        <input
          type="number"
          value={maxBuys}
          onChange={(e) => setMaxBuys(e.target.value)}
          min="1" max="100"
          className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2.5 font-mono text-sm text-white focus:border-[#0052FF]/60 focus:outline-none"
        />
      </div>

      {/* Min Liquidity */}
      <div className="glass rounded-2xl p-4">
        <label className="block text-sm font-black text-white mb-1">Minimum Likuiditas Token</label>
        <p className="text-xs text-white/75 mb-3">Tolak beli token jika total likuiditas di bawah angka ini. Mencegah beli token low-liquidity yang mudah di-rug.</p>
        <div className="relative mb-2">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-[#6b9fff]/50 font-bold">$</span>
          <input
            type="number"
            value={minLiquidity}
            onChange={(e) => setMinLiquidity(e.target.value)}
            min="0" max="1000000" step="1000"
            className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2.5 pl-7 font-mono text-sm text-white focus:border-[#0052FF]/60 focus:outline-none"
          />
        </div>
        <div className="flex gap-2">
          {[["0", "Bebas"], ["1000", "$1K"], ["5000", "$5K"], ["10000", "$10K"], ["50000", "$50K"]].map(([v, label]) => (
            <button key={v} onClick={() => setMinLiquidity(v)}
              className={`flex-1 rounded-lg py-1.5 text-[10px] font-black transition-all ${
                minLiquidity === v
                  ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.35)]"
                  : "glass-cell text-white/75 hover:text-white/70"
              }`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Private key */}
      <div className="glass rounded-2xl p-4 border border-[#ff3b5c]/20">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[#ff3b5c]">🔑</span>
          <label className="text-sm font-black text-white">Private Key Wallet</label>
          {settings?.hasPrivateKey && (
            <span className="ml-auto text-[10px] bg-[#00ff87]/10 text-[#00ff87] border border-[#00ff87]/20 px-2 py-0.5 rounded-full font-bold">✓ Tersimpan</span>
          )}
        </div>
        <p className="text-xs text-white/80 mb-2">
          {settings?.hasPrivateKey
            ? "Isi lagi untuk mengganti private key."
            : "Masukkan private key wallet dedicated yang sudah diisi ETH."}
        </p>
        <p className="text-xs text-[#ff3b5c]/80 mb-3">
          ⚠ Gunakan wallet khusus untuk snipe. Jangan pakai wallet utama.
        </p>
        <div className="relative">
          <input
            type={showKey ? "text" : "password"}
            value={privateKey}
            onChange={(e) => setPrivateKey(e.target.value)}
            placeholder={settings?.hasPrivateKey ? "Key baru untuk mengganti..." : "0x... atau tanpa prefix 0x"}
            className="w-full rounded-lg border border-[#ff3b5c]/25 bg-[#ff3b5c]/10 px-3 py-2.5 pr-12 font-mono text-xs text-white placeholder-white/25 focus:border-[#ff3b5c]/50 focus:outline-none"
          />
          <button onClick={() => setShowKey(!showKey)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-white/75 hover:text-white">
            {showKey ? "🙈" : "👁"}
          </button>
        </div>
        {settings?.walletAddress && (
          <p className="mt-2 font-mono text-[10px] text-[#6b9fff]">
            Wallet: {settings.walletAddress.slice(0, 8)}...{settings.walletAddress.slice(-6)}
          </p>
        )}
      </div>

      {/* Email linking untuk akses via web */}
      <div className="glass rounded-2xl p-4 border border-[#0052FF]/20">
        <div className="flex items-center gap-2 mb-2">
          <span>📧</span>
          <label className="text-sm font-black text-white">Akses via Web Browser</label>
          {linkedEmail && (
            <span className="ml-auto text-[10px] bg-[#00ff87]/10 text-[#00ff87] border border-[#00ff87]/20 px-2 py-0.5 rounded-full font-bold">✓ Terhubung</span>
          )}
        </div>
        {linkedEmail ? (
          <div>
            <p className="text-xs text-white/60 mb-1">Email terhubung:</p>
            <p className="text-xs text-[#6b9fff] font-bold font-mono">{linkedEmail}</p>
            <p className="text-[10px] text-white/40 mt-2">Gunakan email ini untuk login di browser kapan saja.</p>
          </div>
        ) : (
          <>
            <p className="text-xs text-white/60 mb-3">Tautkan email untuk bisa buka app ini di browser tanpa Farcaster.</p>
            {linkStep === "email" && (
              <div className="flex gap-2">
                <input
                  type="email"
                  value={linkEmail}
                  onChange={e => setLinkEmail(e.target.value)}
                  placeholder="email@kamu.com"
                  className="flex-1 rounded-lg px-3 py-2 text-xs font-semibold text-white placeholder-white/25 outline-none"
                  style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)" }}
                />
                <button
                  onClick={handleSendLinkOtp}
                  disabled={!linkEmail.trim() || linkLoading}
                  className="rounded-lg px-3 py-2 text-xs font-black text-white disabled:opacity-40 transition-all whitespace-nowrap"
                  style={{ background: "#0052FF" }}
                >
                  {linkLoading ? "..." : "Kirim OTP"}
                </button>
              </div>
            )}
            {linkStep === "otp" && (
              <div className="flex flex-col gap-2">
                <p className="text-[10px] text-[#6b9fff]">Kode dikirim ke {linkEmail}</p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    value={linkOtp}
                    onChange={e => setLinkOtp(e.target.value.replace(/\D/g, ""))}
                    placeholder="6 digit kode"
                    className="flex-1 rounded-lg px-3 py-2 text-sm font-black text-white placeholder-white/25 tracking-widest outline-none text-center"
                    style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)" }}
                  />
                  <button
                    onClick={handleVerifyLinkOtp}
                    disabled={linkOtp.length !== 6 || linkLoading}
                    className="rounded-lg px-3 py-2 text-xs font-black text-white disabled:opacity-40 transition-all"
                    style={{ background: "linear-gradient(135deg,#00c853,#00897b)" }}
                  >
                    {linkLoading ? "..." : "Verifikasi"}
                  </button>
                </div>
                <button onClick={() => { setLinkStep("email"); setLinkOtp(""); }}
                  className="text-[10px] text-white/35 hover:text-white/60 transition-colors">
                  Kirim ulang
                </button>
              </div>
            )}
            {linkError && <p className="text-red-400 text-xs mt-2">{linkError}</p>}
          </>
        )}
        {linkSuccess && <p className="text-[#00ff87] text-xs mt-2 font-bold">{linkSuccess}</p>}
      </div>

      {saveError && (
        <p className="rounded-xl bg-[#ff3b5c]/10 border border-[#ff3b5c]/20 px-3 py-2.5 text-sm text-[#ff3b5c]">
          {saveError}
        </p>
      )}

      {saveSuccess && (
        <p className="rounded-xl bg-[#0052FF]/10 border border-[#0052FF]/25 px-3 py-2.5 text-sm text-[#6b9fff] font-bold">
          ✅ Settings tersimpan!
        </p>
      )}

      <button
        onClick={handleSave}
        disabled={saving}
        className="w-full rounded-2xl bg-[#0052FF] py-3.5 text-sm font-black text-white shadow-[0_0_20px_rgba(0,82,255,0.40)] hover:bg-[#0047e0] disabled:opacity-50 transition-all"
      >
        {saving ? "Menyimpan..." : "Simpan Settings"}
      </button>
    </div>
  );
}
