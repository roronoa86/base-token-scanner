"use client";

import { cn } from "@neynar/ui";
import type { Tab } from "@/features/app/types";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "sniper",    label: "Sniper",    icon: "🎯" },
  { id: "watchlist", label: "Watchlist", icon: "👁" },
  { id: "history",   label: "History",   icon: "📋" },
  { id: "trader",    label: "AutoTrade", icon: "📈" },
  { id: "clanker",   label: "Clanker",   icon: "🔫" },
  { id: "pumpfun",   label: "Pump.fun",  icon: "🚀" },
];

interface TabBarProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

export function TabBar({ activeTab, onTabChange }: TabBarProps) {
  return (
    <div className="flex items-center glass-header">
      {TABS.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={cn(
            "flex flex-1 flex-col items-center gap-0.5 py-3 text-xs font-bold transition-all min-h-[56px] justify-center relative",
            activeTab === tab.id
              ? "text-white"
              : "text-white/50 hover:text-white/75",
          )}
        >
          <span className={cn(
            "text-base leading-none transition-all",
            activeTab === tab.id && "drop-shadow-[0_0_6px_rgba(0,82,255,0.8)]"
          )}>{tab.icon}</span>
          <span className={cn(
            "tracking-tight text-[10px]",
            activeTab === tab.id ? "text-white font-black" : "font-semibold"
          )}>{tab.label}</span>
          {activeTab === tab.id && (
            <span className="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 w-10 rounded-full bg-[#0052FF] shadow-[0_0_8px_rgba(0,82,255,0.8)]" />
          )}
        </button>
      ))}
    </div>
  );
}
