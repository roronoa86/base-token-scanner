"use client";

import { useEffect, useState } from "react";
import type { SnipeStats, SniperSettings, WatchedWallet } from "@/features/app/types";
import { apiFetch } from "@/lib/api-client";

interface DashboardTabProps {
  fid: number;
  settings: SniperSettings | null;
  wallets: WatchedWallet[];
  onToggleSniper: (enabled: boolean) => void;
  isToggling: boolean;
}

export function DashboardTab({
  fid,
  settings,
  wallets,
  onToggleSniper,
  isToggling,
}: DashboardTabProps) {
  const [stats, setStats] = useState<SnipeStats | null>(null);
  const [pollResult, setPollResult] = useState<string | null>(null);
  const [polling, setPolling] = useState(false);
  const [lastBlock, setLastBlock] = useState<string | null>(null);
  const [monitorResult, setMonitorResult] = useState<string | null>(null);
  const [monitoring, setMonitoring] = useState(false);

  useEffect(() => {
    apiFetch(`/api/sniper/history?fid=${fid}`)
      .then((r) => r.json())
      .then((d) => setStats(d.stats ?? null))
      .catch(() => {});
    fetch(`/api/sniper/debug?fid=${fid}`)
      .then((r) => r.json())
      .then((d) => setLastBlock(d.polling?.lastBlockScanned ?? null))
      .catch(() => {});
  }, [fid]);

  const handleManualPoll = async () => {
    setPolling(true);
    setPollResult(null);
    try {
      const res = await fetch("/api/sniper/poll");
      const data = await res.json();
      if (data.error) {
        setPollResult(`❌ Error: ${data.error}`);
      } else {
        setPollResult(
          `✅ Scan selesai: ${data.blocksScanned} blok, ${data.deploymentsDetected} deploy terdeteksi, ${data.snipesExecuted} snipe dieksekusi`
        );
        apiFetch(`/api/sniper/history?fid=${fid}`)
          .then((r) => r.json())
          .then((d) => setStats(d.stats ?? null))
          .catch(() => {});
        fetch(`/api/sniper/debug?fid=${fid}`)
          .then((r) => r.json())
          .then((d) => setLastBlock(d.polling?.lastBlockScanned ?? null))
          .catch(() => {});
      }
    } catch {
      setPollResult("❌ Gagal konek ke server");
    } finally {
      setPolling(false);
    }
  };

  const handleManualMonitor = async () => {
    setMonitoring(true);
    setMonitorResult(null);
    try {
      const res = await fetch("/api/trader/monitor");
      const data = await res.json();
      if (data.error) {
        setMonitorResult(`❌ Error: ${data.error}`);
      } else {
        const triggered = data.triggered ?? 0;
        const checked = data.checked ?? 0;
        // Show per-position detail
        const details = (data.results ?? []).map((r: Record<string, unknown>) => {
          const pct = r.changePct ? ` (${r.changePct}%)` : "";
          const trigger = r.trigger === "take_profit" ? " → TP 🎯" : r.trigger === "stop_loss" ? " → SL 🛑" : "";
          return `${r.token ?? r.id}${pct}${trigger}: ${r.status ?? r.trigger ?? "hold"}`;
        }).join(" | ");
        setMonitorResult(`✅ Cek ${checked} posisi, ${triggered} dieksekusi${details ? ` — ${details}` : ""}`);
      }
    } catch {
      setMonitorResult("❌ Gagal konek ke server");
    } finally {
      setMonitoring(false);
    }
  };

  const isReady = settings?.hasPrivateKey && wallets.length > 0;
  const isActive = settings?.isEnabled ?? false;

  return (
    <div className="flex flex-col gap-4 p-4">

      {/* Sniper ON/OFF card */}
      <div className="glass rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-[11px] text-[#6b9fff] uppercase tracking-widest mb-2 font-black">Sniper Status</p>
            <div className="flex items-center gap-2">
              <span className={`h-2.5 w-2.5 rounded-full transition-all ${
                isActive ? "bg-[#00ff87] shadow-[0_0_10px_#00ff87]" : "bg-white/50"
              }`} />
              <span className={`text-xl font-black tracking-tight ${isActive ? "text-[#00ff87]" : "text-white"}`}>
                {isActive ? "AKTIF" : "NONAKTIF"}
              </span>
            </div>
          </div>
          <button
            onClick={() => onToggleSniper(!isActive)}
            disabled={isToggling || !isReady}
            className={`relative h-8 w-14 rounded-full transition-all duration-300 disabled:opacity-40 ${
              isActive
                ? "bg-[#0052FF] shadow-[0_0_14px_rgba(0,82,255,0.50)]"
                : "bg-white/20 border border-white/30"
            }`}
          >
            <span className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-md transition-transform duration-300 ${
              isActive ? "translate-x-7" : "translate-x-1"
            }`} />
          </button>
        </div>
        {!isReady && (
          <p className="mt-3 text-xs font-bold text-[#ff3b5c] bg-[#ff3b5c]/10 border border-[#ff3b5c]/20 rounded-lg px-3 py-1.5">
            {!settings?.hasPrivateKey
              ? "⚠ Set private key di Settings dulu"
              : "⚠ Tambahkan wallet di Watchlist dulu"}
          </p>
        )}
      </div>

      {/* Config summary */}
      <div className="glass rounded-2xl p-4">
        <p className="text-[11px] text-[#6b9fff] uppercase tracking-widest mb-3 font-black">Konfigurasi Aktif</p>
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: "Buy Amount", value: `${settings?.buyAmountEth ?? "–"} ETH`, color: "text-white" },
            { label: "Slippage",   value: settings ? `${(settings.slippageBps / 100).toFixed(1)}%` : "–", color: "text-white" },
            { label: "Wallet Dipantau", value: `${wallets.length}`, color: "text-[#6b9fff]" },
            { label: "Max Beli/Hari",   value: `${settings?.maxBuysPerDay ?? "–"}x`, color: "text-white" },
          ].map(({ label, value, color }) => (
            <div key={label} className="glass-cell rounded-xl p-3">
              <p className="text-[10px] text-[#6b9fff] font-bold uppercase tracking-wide mb-1">{label}</p>
              <p className={`text-sm font-black font-mono ${color}`}>{value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="glass rounded-2xl p-4">
        <p className="text-[11px] text-[#6b9fff] uppercase tracking-widest mb-3 font-black">Statistik Snipe</p>
        <div className="grid grid-cols-2 gap-3">
          <div className="glass-cell rounded-xl p-3 text-center">
            <p className="text-2xl font-black text-white">{stats?.total ?? 0}</p>
            <p className="text-[11px] text-white font-bold mt-0.5 uppercase tracking-wide">Total</p>
          </div>
          <div className="glass-cell rounded-xl p-3 text-center">
            <p className="text-2xl font-black text-[#00ff87]">{stats?.success ?? 0}</p>
            <p className="text-[11px] text-white font-bold mt-0.5 uppercase tracking-wide">Berhasil</p>
          </div>
          <div className="glass-cell rounded-xl p-3 text-center">
            <p className="text-2xl font-black text-[#ff3b5c]">{stats?.failed ?? 0}</p>
            <p className="text-[11px] text-white font-bold mt-0.5 uppercase tracking-wide">Gagal</p>
          </div>
          <div className="glass-cell rounded-xl p-3 text-center">
            <p className="text-2xl font-black text-[#6b9fff]">
              {stats ? stats.totalSpentEth.toFixed(4) : "0"}
            </p>
            <p className="text-[11px] text-white font-bold mt-0.5 uppercase tracking-wide">ETH Dipakai</p>
          </div>
        </div>
      </div>

      {/* Sniper wallet */}
      {settings?.walletAddress && (
        <div className="glass rounded-2xl p-4">
          <p className="text-[11px] text-[#6b9fff] uppercase tracking-widest mb-2 font-black">Sniper Wallet</p>
          <p className="font-mono text-xs text-white font-bold break-all leading-relaxed">
            {settings.walletAddress}
          </p>
        </div>
      )}

      {/* Polling / cron */}
      <div className="glass rounded-2xl p-4">
        <div className="mb-3">
          <p className="text-[11px] text-[#6b9fff] uppercase tracking-widest mb-1 font-black">Polling Status</p>
          <p className="text-sm text-white font-bold">
            {lastBlock && lastBlock !== "BELUM PERNAH"
              ? `Blok terakhir: #${lastBlock}`
              : "⚠ Belum pernah polling"}
          </p>
        </div>

        <button
          onClick={handleManualPoll}
          disabled={polling}
          className="w-full rounded-xl border border-[#0052FF]/50 bg-[#0052FF]/20 py-2.5 text-sm font-black text-white hover:bg-[#0052FF]/30 transition-all disabled:opacity-50"
        >
          {polling ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
              Scanning Base...
            </span>
          ) : (
            "🔍 Test Poll Manual"
          )}
        </button>

        {pollResult && (
          <p className="mt-2 text-xs text-white font-semibold bg-white/10 rounded-lg px-3 py-2 leading-relaxed">{pollResult}</p>
        )}

        <p className="mt-3 text-[10px] text-white/50 font-semibold leading-relaxed">
          Auto-snipe: Cron Vercel sudah setup, aktif setelah app di-publish.
        </p>
      </div>

      {/* TP/SL Monitor */}
      <div className="glass rounded-2xl p-4">
        <div className="mb-3">
          <p className="text-[11px] text-[#6b9fff] uppercase tracking-widest mb-1 font-black">AutoTrade Monitor</p>
          <p className="text-xs text-white/70 font-semibold">Cek semua posisi aktif — trigger TP/SL jika sudah tercapai</p>
        </div>

        <button
          onClick={handleManualMonitor}
          disabled={monitoring}
          className="w-full rounded-xl border border-[#00ff87]/30 bg-[#00ff87]/10 py-2.5 text-sm font-black text-white hover:bg-[#00ff87]/20 transition-all disabled:opacity-50"
        >
          {monitoring ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
              Mengecek posisi...
            </span>
          ) : (
            "🎯 Run Monitor TP/SL"
          )}
        </button>

        {monitorResult && (
          <p className="mt-2 text-xs text-white font-semibold bg-white/10 rounded-lg px-3 py-2 leading-relaxed break-words">{monitorResult}</p>
        )}

        <p className="mt-3 text-[10px] text-white/50 font-semibold leading-relaxed">
          Auto-monitor: Cron Vercel sudah setup (<span className="font-mono text-[#6b9fff]/70">/api/trader/monitor</span> tiap menit), aktif setelah publish.
        </p>
      </div>
    </div>
  );
}
