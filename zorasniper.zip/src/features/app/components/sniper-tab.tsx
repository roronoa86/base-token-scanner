"use client";

import { useState } from "react";
import { DashboardTab } from "@/features/app/components/dashboard-tab";
import { SettingsTab } from "@/features/app/components/settings-tab";
import type { SniperSettings, WatchedWallet } from "@/features/app/types";

type SniperSubTab = "status" | "settings";

interface SniperTabProps {
  fid: number;
  settings: SniperSettings | null;
  wallets: WatchedWallet[];
  onToggleSniper: (enabled: boolean) => void;
  isToggling: boolean;
  onSettingsChange: () => void;
}

export function SniperTab({
  fid, settings, wallets, onToggleSniper, isToggling, onSettingsChange,
}: SniperTabProps) {
  const [sub, setSub] = useState<SniperSubTab>("status");

  return (
    <div className="flex flex-col h-full">
      {/* Sub-tab bar */}
      <div className="flex mx-4 mt-4 mb-0 glass rounded-xl p-1 gap-1">
        {([
          { key: "status",   label: "🎯 Status & Monitor" },
          { key: "settings", label: "⚙️ Pengaturan" },
        ] as { key: SniperSubTab; label: string }[]).map((t) => (
          <button
            key={t.key}
            onClick={() => setSub(t.key)}
            className={`flex-1 rounded-lg py-2 text-xs font-black transition-all ${
              sub === t.key
                ? "bg-[#0052FF] text-white shadow-[0_0_12px_rgba(0,82,255,0.40)]"
                : "text-white/60 hover:text-white/85"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Sub-tab content */}
      <div className="flex-1 overflow-y-auto">
        {sub === "status" && (
          <DashboardTab
            fid={fid}
            settings={settings}
            wallets={wallets}
            onToggleSniper={onToggleSniper}
            isToggling={isToggling}
          />
        )}
        {sub === "settings" && (
          <SettingsTab
            fid={fid}
            settings={settings}
            onSettingsChange={onSettingsChange}
          />
        )}
      </div>
    </div>
  );
}
