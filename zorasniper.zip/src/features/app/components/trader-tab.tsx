"use client";

import { useState, useEffect, useCallback } from "react";
import { apiFetch } from "@/lib/api-client";

// Format PnL % manusiawi — angka besar disingkat
function formatPct(pct: number): string {
  const abs = Math.abs(pct);
  const sign = pct >= 0 ? "+" : "-";
  if (abs >= 100_000) return `${sign}${(abs / 1000).toFixed(1)}K%`;
  if (abs >= 10_000)  return `${sign}${abs.toFixed(0)}%`;
  if (abs >= 1_000)   return `${sign}${abs.toFixed(0)}%`;
  return `${sign}${abs.toFixed(1)}%`;
}

interface TokenInfo {
  found: boolean;
  address: string;
  name: string;
  symbol: string;
  priceUsd: string;
  priceNative: string;
  priceChange5m: number;
  priceChange1h: number;
  priceChange6h: number;
  priceChange24h: number;
  liquidity: number;
  volume24h: number;
  volume6h: number;
  volume1h: number;
  marketCap: number;
  fdv: number;
  buys24h: number;
  sells24h: number;
  buys6h: number;
  sells6h: number;
  holders: number | null;
  pairCreatedAt: number | null;
  totalSupply: string | null;
  decimals: number;
  dex: string;
  pairAddress: string | null;
  imageUrl: string | null;
  tradeable?: boolean;
  tradeWarning?: string | null;
}

interface Position {
  id: string;
  tokenAddress: string;
  tokenName: string | null;
  tokenSymbol: string | null;
  tokenPriceUsd: string | null;
  tokenImageUrl: string | null;
  buyAmountEth: string;
  buyTxHash: string | null;
  buyPriceUsd: string | null;
  buyPriceEth: string | null;
  ethUsdAtBuy: string | null;       // ETH/USD rate saat TX dieksekusi — cost basis akurat
  tokensReceived: string | null;
  buyTriggerPriceUsd: string | null;
  sellTargetPriceUsd: string | null;
  takeProfitPct: string | null;
  stopLossPct: string | null;
  status: string;
  sellTxHash: string | null;
  sellPriceUsd: string | null;
  pnlEth: string | null;
  pnlPct: string | null;
  closeReason: string | null;
  createdAt: string;
}

interface LiveStats {
  priceUsd: string;
  priceNative: string;
  priceChange24h: number;
  priceChange1h: number;
  liquidity: number;
  volume24h: number;
  marketCap: number;
  fdv: number;
  buys24h: number;
  sells24h: number;
  imageUrl: string | null;
  // wallet-specific (from on-chain balance)
  tokenBalance: string | null;    // human-readable token qty
  tokenBalanceUsd: number;        // USD value of holding
  pnlPct: number;                 // % change from entry price
  pnlUsd: number;                 // USD PnL
}

type TraderView = "lookup" | "orders" | "history";

// ─── Confirmation Modal ────────────────────────────────────────────────────────

function ConfirmModal({
  title,
  message,
  confirmLabel,
  confirmClass,
  onConfirm,
  onCancel,
}: {
  title: string;
  message: string;
  confirmLabel: string;
  confirmClass: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-md px-4 pb-6">
      <div className="w-full max-w-sm rounded-2xl glass p-5 flex flex-col gap-4 shadow-2xl">
        <div>
          <p className="font-black text-white text-base mb-1">{title}</p>
          <p className="text-sm text-white/85 leading-relaxed">{message}</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 rounded-xl border border-[#0052FF]/25 bg-[#0052FF]/10 py-3 text-sm font-bold text-white/80 hover:text-white hover:border-[#0052FF]/50 transition-colors"
          >
            Tidak
          </button>
          <button
            onClick={onConfirm}
            className={`flex-1 rounded-xl py-3 text-sm font-black text-white transition-opacity hover:opacity-90 ${confirmClass}`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function fmtUsd(v: number): string {
  if (v >= 1_000_000_000) return `$${(v / 1_000_000_000).toFixed(2)}B`;
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(2)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(1)}K`;
  return `$${v.toFixed(2)}`;
}

function fmtPrice(v: number): string {
  if (v === 0) return "$0";
  if (v < 0.000001) return `$${v.toExponential(3)}`;
  if (v < 0.001) return `$${v.toFixed(7)}`;
  if (v < 1) return `$${v.toFixed(6)}`;
  return `$${v.toFixed(4)}`;
}

function PctBadge({ v, label }: { v: number; label: string }) {
  const pos = v >= 0;
  return (
    <span className={`inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-[10px] font-bold ${
      pos ? "bg-[#00ff87]/10 text-[#00ff87]" : "bg-[#ff3b5c]/10 text-[#ff3b5c]"
    }`}>
      {pos ? "▲" : "▼"} {Math.abs(v).toFixed(1)}% {label}
    </span>
  );
}

function fmtAge(createdAtMs: number | null): string {
  if (!createdAtMs) return "—";
  const diffMs = Date.now() - createdAtMs;
  const diffMin = Math.floor(diffMs / 60_000);
  const diffH   = Math.floor(diffMs / 3_600_000);
  const diffD   = Math.floor(diffMs / 86_400_000);
  if (diffMin < 60)   return `${diffMin}m`;
  if (diffH < 24)     return `${diffH}h ${diffMin % 60}m`;
  if (diffD < 30)     return `${diffD}d ${diffH % 24}h`;
  const diffMo = Math.floor(diffD / 30);
  return `${diffMo}mo ${diffD % 30}d`;
}

// ─── Token Lookup Card ────────────────────────────────────────────────────────

function TokenLookup({ onSelect }: { onSelect: (info: TokenInfo) => void }) {
  const [input, setInput]     = useState("");
  const [loading, setLoading] = useState(false);
  const [token, setToken]     = useState<TokenInfo | null>(null);
  const [error, setError]     = useState("");

  const lookup = async () => {
    const addr = input.trim().toLowerCase();
    if (!/^0x[0-9a-f]{40}$/.test(addr)) { setError("Masukkan contract address yang valid (0x...)"); return; }
    setError(""); setLoading(true); setToken(null);
    try {
      const res = await fetch(`/api/trader/lookup?address=${addr}`);
      const data = await res.json();
      if (!res.ok || data.error) { setError(data.error ?? "Token tidak ditemukan"); return; }
      setToken(data);
    } catch { setError("Koneksi gagal"); }
    finally { setLoading(false); }
  };

  const price = token ? parseFloat(token.priceUsd) : 0;
  const totalTxns24h = token ? (token.buys24h + token.sells24h) : 0;
  const totalTxns6h  = token ? (token.buys6h  + token.sells6h)  : 0;
  const buyPct24h = totalTxns24h > 0 ? Math.round((token!.buys24h / totalTxns24h) * 100) : 50;
  const buyPct6h  = totalTxns6h  > 0 ? Math.round((token!.buys6h  / totalTxns6h)  * 100) : 50;

  return (
    <div className="flex flex-col gap-3">
      {/* Search input */}
      <div>
        <label className="text-xs text-white/85 mb-1.5 block font-bold">Contract Address Token</label>
        <div className="flex gap-2">
          <input
            type="text" placeholder="0x... (Zora Coin, Clanker, dll)"
            value={input} onChange={(e) => { setInput(e.target.value); setError(""); setToken(null); }}
            onKeyDown={(e) => e.key === "Enter" && lookup()}
            className="flex-1 rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 backdrop-blur-sm px-3 py-2.5 text-sm text-white placeholder-white/30 focus:border-[#0052FF]/60 focus:outline-none font-mono"
          />
          <button onClick={lookup} disabled={loading || !input.trim()}
            className="rounded-lg bg-[#0052FF] px-4 py-2.5 text-sm font-black text-white shadow-[0_0_12px_rgba(0,82,255,0.35)] hover:bg-[#0047e0] disabled:opacity-40 transition-all">
            {loading ? "⟳" : "Cari"}
          </button>
        </div>
        <p className="text-[10px] text-white/65 mt-1">Token Base: Zora Coins, Clanker, Uniswap V3/V4</p>
      </div>

      {error && <p className="text-xs text-[#ff3b5c] bg-[#ff3b5c]/10 rounded-lg px-3 py-2 font-bold">{error}</p>}

      {token && (
        <div className="glass rounded-2xl overflow-hidden">
          {/* ── Token header ── */}
          <div className="px-4 pt-4 pb-3 border-b border-[#0052FF]/15">
            <div className="flex items-center gap-3">
              {token.imageUrl ? (
                <img src={token.imageUrl} alt={token.symbol}
                  className="w-12 h-12 rounded-full ring-2 ring-[#0052FF]/40 shadow-[0_0_12px_rgba(0,82,255,0.25)] shrink-0" />
              ) : (
                <div className="w-12 h-12 rounded-full bg-[#0052FF]/20 border border-[#0052FF]/30 flex items-center justify-center text-xl shrink-0">🪙</div>
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-black text-white text-base leading-tight">{token.name}</span>
                  <span className="text-[#6b9fff] font-bold text-sm">${token.symbol}</span>
                  <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-[#0052FF]/20 text-[#6b9fff]">
                    {token.dex === "unknown" ? "DEX" : token.dex.toUpperCase()}
                  </span>
                </div>
                <p className="text-[10px] text-white/50 font-mono mt-0.5 truncate">{token.address}</p>
              </div>
            </div>

            {/* Price + changes */}
            <div className="mt-3 flex items-end gap-3 flex-wrap">
              <div>
                <p className="text-2xl font-black text-white leading-none">{fmtPrice(price)}</p>
                <p className="text-[10px] text-white/50 mt-0.5">{parseFloat(token.priceNative).toFixed(8)} ETH</p>
              </div>
              <div className="flex gap-1 flex-wrap mb-0.5">
                {token.priceChange5m  !== 0 && <PctBadge v={token.priceChange5m}  label="5m"  />}
                {token.priceChange1h  !== 0 && <PctBadge v={token.priceChange1h}  label="1h"  />}
                {token.priceChange6h  !== 0 && <PctBadge v={token.priceChange6h}  label="6h"  />}
                {token.priceChange24h !== 0 && <PctBadge v={token.priceChange24h} label="24h" />}
              </div>
            </div>
          </div>

          {/* ── Row 1: MC + Liquidity + Age ── */}
          <div className="px-4 pt-3 grid grid-cols-3 gap-2">
            <div className="glass-cell rounded-xl p-3">
              <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Market Cap</p>
              <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.marketCap)}</p>
              {token.fdv > 0 && token.fdv !== token.marketCap && (
                <p className="text-[9px] text-white/45 mt-0.5">FDV {fmtUsd(token.fdv)}</p>
              )}
            </div>
            <div className="glass-cell rounded-xl p-3">
              <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Liquidity</p>
              <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.liquidity)}</p>
              <p className="text-[9px] text-white/45 mt-0.5 uppercase">{token.dex === "unknown" ? "DEX" : token.dex}</p>
            </div>
            <div className="glass-cell rounded-xl p-3">
              <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Usia Token</p>
              <p className="text-white font-black text-sm leading-tight">{fmtAge(token.pairCreatedAt)}</p>
              {token.holders !== null && (
                <p className="text-[9px] text-white/45 mt-0.5">{token.holders.toLocaleString()} holders</p>
              )}
            </div>
          </div>

          {/* ── Row 2: Vol 24h + Vol 6h + Vol 1h ── */}
          <div className="px-4 pt-2 grid grid-cols-3 gap-2">
            <div className="glass-cell rounded-xl p-3">
              <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Vol 24h</p>
              <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.volume24h)}</p>
              {totalTxns24h > 0 && (
                <p className="text-[9px] mt-0.5">
                  <span className="text-[#00ff87]">B{token.buys24h}</span>
                  <span className="text-white/40">/</span>
                  <span className="text-[#ff3b5c]">S{token.sells24h}</span>
                </p>
              )}
            </div>
            <div className="glass-cell rounded-xl p-3">
              <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Vol 6h</p>
              <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.volume6h)}</p>
              {totalTxns6h > 0 && (
                <p className="text-[9px] mt-0.5">
                  <span className="text-[#00ff87]">B{token.buys6h}</span>
                  <span className="text-white/40">/</span>
                  <span className="text-[#ff3b5c]">S{token.sells6h}</span>
                </p>
              )}
            </div>
            <div className="glass-cell rounded-xl p-3">
              <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Vol 1h</p>
              <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.volume1h)}</p>
            </div>
          </div>

          {/* ── Buy/Sell pressure bars (24h + 6h) ── */}
          {(totalTxns24h > 0 || totalTxns6h > 0) && (
            <div className="px-4 pt-2 pb-1 flex flex-col gap-2">
              {totalTxns24h > 0 && (
                <div>
                  <div className="flex justify-between text-[9px] font-bold mb-1">
                    <span className="text-[#00ff87]">BUY {buyPct24h}%</span>
                    <span className="text-white/40 text-[8px]">TEKANAN 24h</span>
                    <span className="text-[#ff3b5c]">SELL {100 - buyPct24h}%</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full overflow-hidden bg-[#ff3b5c]/25">
                    <div className="h-full rounded-full bg-[#00ff87] shadow-[0_0_6px_rgba(0,255,135,0.4)] transition-all"
                      style={{ width: `${buyPct24h}%` }} />
                  </div>
                </div>
              )}
              {totalTxns6h > 0 && (
                <div>
                  <div className="flex justify-between text-[9px] font-bold mb-1">
                    <span className="text-[#00ff87]">BUY {buyPct6h}%</span>
                    <span className="text-white/40 text-[8px]">TEKANAN 6h</span>
                    <span className="text-[#ff3b5c]">SELL {100 - buyPct6h}%</span>
                  </div>
                  <div className="h-1 w-full rounded-full overflow-hidden bg-[#ff3b5c]/20">
                    <div className="h-full rounded-full bg-[#00ff87]/70 transition-all"
                      style={{ width: `${buyPct6h}%` }} />
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="px-4 pb-1" />

          {/* ── Warning ── */}
          {token.tradeWarning && (
            <div className="mx-4 mb-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 px-3 py-2">
              <p className="text-[11px] text-yellow-400 font-bold">⚠️ {token.tradeWarning}</p>
            </div>
          )}

          {/* ── CTA ── */}
          <div className="px-4 pb-4">
            <button onClick={() => onSelect(token)}
              className="w-full rounded-xl bg-[#0052FF] py-3 text-sm font-black text-white shadow-[0_0_20px_rgba(0,82,255,0.40)] hover:bg-[#0047e0] transition-all">
              ⚡ Setup Trade →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Token Analyzer (Safety Check) ───────────────────────────────────────────

interface AnalyzeResult {
  address: string;
  platform: string;
  isProtocol: boolean;
  isHoneypot: boolean;
  buyTax: number | null;
  sellTax: number | null;
  lockStatus: "locked" | "unlocked" | "partial" | "protocol" | "unverified";
  lockStatusLabel: string;
  lockDetail: string;
  lpLockedPct: number;
  lpTotalSupply: number;
  lpHolderCount: number | null;
  lpHolderRows: Array<{
    address: string; tag: string; percent: string; locked: boolean;
    lockedSource?: string; nftClass?: string; value: string; nftIds: string[];
  }>;
  contractChecks: {
    sourceVerified: boolean; isProxy: boolean; isMintable: boolean;
    canTakeBackOwnership: boolean; ownerCanChangeBalance: boolean; hasHiddenOwner: boolean;
    canSelfDestruct: boolean; hasExternalCall: boolean; hasBlacklist: boolean;
    hasWhitelist: boolean; hasAntiWhale: boolean; hasTradingCooldown: boolean; canPauseTrading: boolean;
  };
  ownerAddress: string | null;
  creatorAddress: string | null;
  ownerRenounced: boolean;
  holderCount: number | null;
  top10Holders: Array<{ address: string; tag: string; percent: string; balance: string; isContract: boolean; isLocked: boolean }>;
  top10HolderPct: number;
  totalLiquidity: number;
  dexList: Array<{ pairAddress: string; dex: string; labels: string[]; quoteSymbol: string; liqUsd: number }>;
  riskScore: number;
  riskLevel: "safe" | "caution" | "danger";
  riskWarnings?: string[];
  // Pool type
  hasV4Pool?: boolean;
  hasV3Pool?: boolean;
  onlyV4?: boolean;
  // Token age
  pairCreatedAt?: number | null;
  tokenAgeH?: number | null;
  isNewToken?: boolean;
  // Volume pattern
  vol1h?: number;
  vol6h?: number;
  volumeDead?: boolean;
  pumpDumpFlag?: boolean;
}

function RiskBadge({ level, score }: { level: "safe" | "caution" | "danger"; score: number }) {
  const cfg = {
    safe:    { bg: "bg-[#00ff87]/10 border-[#00ff87]/30", text: "text-[#00ff87]", icon: "🟢", label: "AMAN" },
    caution: { bg: "bg-yellow-500/10 border-yellow-500/25", text: "text-yellow-400", icon: "🟡", label: "HATI-HATI" },
    danger:  { bg: "bg-[#ff3b5c]/10 border-[#ff3b5c]/30", text: "text-[#ff3b5c]", icon: "🔴", label: "BAHAYA" },
  }[level];
  return (
    <div className={`flex items-center gap-2 rounded-xl border px-4 py-3 ${cfg.bg}`}>
      <span className="text-2xl">{cfg.icon}</span>
      <div>
        <p className={`font-black text-base leading-tight ${cfg.text}`}>{cfg.label}</p>
        <p className="text-white/50 text-[10px]">Risk Score: {score}/100</p>
      </div>
    </div>
  );
}

function LockBadge({ locked, label }: { locked: boolean; label: string }) {
  return locked ? (
    <span className="inline-flex items-center gap-1 rounded-md bg-[#00ff87]/10 border border-[#00ff87]/25 px-2 py-0.5 text-[10px] font-black text-[#00ff87]">
      🔒 {label}
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 rounded-md bg-[#ff3b5c]/10 border border-[#ff3b5c]/25 px-2 py-0.5 text-[10px] font-black text-[#ff3b5c]">
      🔓 {label}
    </span>
  );
}

function TokenAnalyzer({ token, onTrade }: { token: TokenInfo; onTrade: () => void }) {
  const [result, setResult]   = useState<AnalyzeResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");

  useEffect(() => {
    setResult(null); setError("");
    setLoading(true);
    fetch(`/api/trader/analyze?address=${token.address}`)
      .then(r => r.json())
      .then(d => { if (d.error) setError(d.error); else setResult(d); })
      .catch(() => setError("Gagal menganalisis token"))
      .finally(() => setLoading(false));
  }, [token.address]);

  const fmtAddr = (a: string) => a ? `${a.slice(0, 8)}...${a.slice(-6)}` : "";

  // Check row: green = safe, red = risky, yellow = attention
  const CheckRow = ({ label, ok, attention, desc }: { label: string; ok: boolean; attention?: boolean; desc?: string }) => (
    <div className="flex items-start gap-2.5 py-2 border-b border-white/5 last:border-0">
      <span className="text-base mt-0.5 shrink-0">{ok ? "✅" : attention ? "⚠️" : "❌"}</span>
      <div className="flex-1 min-w-0">
        <p className={`text-[11px] font-black ${ok ? "text-white" : attention ? "text-yellow-300" : "text-[#ff3b5c]"}`}>{label}</p>
        {desc && <p className="text-[10px] text-white/40 mt-0.5 leading-snug">{desc}</p>}
      </div>
    </div>
  );

  if (loading) return (
    <div className="flex flex-col gap-3">
      <div className="glass rounded-2xl p-8 text-center">
        <div className="text-3xl mb-3 animate-pulse">🔍</div>
        <p className="text-white font-black text-sm">Menganalisis keamanan token...</p>
        <p className="text-white/40 text-xs mt-1">GoPlus + onchain fingerprint + DexScreener</p>
      </div>
    </div>
  );

  if (error) return (
    <div className="flex flex-col gap-3">
      <div className="rounded-xl bg-[#ff3b5c]/10 border border-[#ff3b5c]/25 px-4 py-3">
        <p className="text-[#ff3b5c] text-sm font-bold">⚠️ {error}</p>
      </div>
      <button onClick={onTrade} className="w-full rounded-xl bg-[#0052FF] py-3 text-sm font-black text-white">⚡ Trade Anyway →</button>
    </div>
  );

  if (!result) return null;

  const locked = result.lockStatus === "protocol" || result.lockStatus === "locked";
  const riskCfg = {
    safe:    { bg: "bg-[#00ff87]/10 border-[#00ff87]/30", text: "text-[#00ff87]", label: "AMAN" },
    caution: { bg: "bg-yellow-500/10 border-yellow-400/30", text: "text-yellow-300", label: "HATI-HATI" },
    danger:  { bg: "bg-[#ff3b5c]/10 border-[#ff3b5c]/30", text: "text-[#ff3b5c]", label: "BAHAYA" },
  }[result.riskLevel];

  return (
    <div className="flex flex-col gap-3">

      {/* ── Risk header ── */}
      <div className={`rounded-2xl border px-4 pt-3 pb-3 ${riskCfg.bg}`}>
        {/* Row 1: icon + label + badges + tax */}
        <div className="flex items-center gap-3">
          <span className="text-3xl">{result.riskLevel === "safe" ? "🟢" : result.riskLevel === "caution" ? "🟡" : "🔴"}</span>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <p className={`font-black text-lg leading-none ${riskCfg.text}`}>{riskCfg.label}</p>
              {result.isHoneypot && <span className="text-[10px] font-black bg-[#ff3b5c] text-white px-2 py-0.5 rounded-full">HONEYPOT</span>}
              {result.isProtocol && <span className="text-[10px] font-black bg-[#00ff87]/20 text-[#00ff87] px-2 py-0.5 rounded-full border border-[#00ff87]/30">{result.platform}</span>}
            </div>
            <p className="text-white/50 text-[10px] mt-0.5">
              Score: <span className={`font-black ${riskCfg.text}`}>{result.riskScore}</span>
              <span className="text-white/30"> / 100 — semakin kecil semakin aman</span>
            </p>
          </div>
          <div className="text-right shrink-0">
            <p className="text-[9px] text-white/40 font-bold">Buy / Sell Tax</p>
            <p className="text-sm font-black">
              {result.buyTax === null || result.buyTax === undefined ? (
                <span className="text-white/40">?%</span>
              ) : (
                <span className={result.buyTax > 10 ? "text-[#ff3b5c]" : result.buyTax > 0 ? "text-yellow-300" : "text-[#00ff87]"}>{result.buyTax.toFixed(0)}%</span>
              )}
              <span className="text-white/30 mx-1">/</span>
              {result.sellTax === null || result.sellTax === undefined ? (
                <span className="text-white/40">?%</span>
              ) : (
                <span className={result.sellTax > 10 ? "text-[#ff3b5c]" : result.sellTax > 0 ? "text-yellow-300" : "text-[#00ff87]"}>{result.sellTax.toFixed(0)}%</span>
              )}
            </p>
          </div>
        </div>

        {/* Row 2: score bar */}
        <div className="mt-3">
          <div className="relative h-2 w-full rounded-full bg-white/10 overflow-hidden">
            {/* Gradient track: green → yellow → red */}
            <div className="absolute inset-0 rounded-full"
              style={{ background: "linear-gradient(to right, #00ff87 0%, #ffcc00 40%, #ff3b5c 80%)" }} />
            {/* White mask that covers from score% to 100% */}
            <div className="absolute top-0 right-0 h-full rounded-r-full bg-black/60"
              style={{ width: `${100 - result.riskScore}%` }} />
            {/* Needle */}
            <div className="absolute top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-white shadow-[0_0_4px_rgba(255,255,255,0.8)]"
              style={{ left: `calc(${result.riskScore}% - 4px)` }} />
          </div>
          <div className="flex justify-between text-[9px] font-bold mt-1">
            <span className="text-[#00ff87]">0 AMAN</span>
            <span className="text-yellow-400">50 HATI-HATI</span>
            <span className="text-[#ff3b5c]">100 BAHAYA</span>
          </div>
        </div>
      </div>

      {/* ── Risk Warnings Panel ── */}
      {result.riskWarnings && result.riskWarnings.length > 0 && (
        <div className="rounded-2xl border border-[#ff3b5c]/30 bg-[#ff3b5c]/5 px-4 py-3 flex flex-col gap-1.5">
          <p className="text-[10px] font-black text-[#ff3b5c] uppercase tracking-wider mb-0.5">Peringatan Risiko</p>
          {result.riskWarnings.map((w, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="text-xs shrink-0 mt-0.5">
                {w.toLowerCase().includes("honeypot") ? "🍯" :
                 w.toLowerCase().includes("v4") ? "🔓" :
                 w.toLowerCase().includes("pump") ? "📉" :
                 w.toLowerCase().includes("baru") ? "⏰" :
                 w.toLowerCase().includes("mintable") ? "🖨️" :
                 w.toLowerCase().includes("hidden") ? "👤" : "⚠️"}
              </span>
              <p className="text-[11px] text-white/80 leading-snug font-bold">{w}</p>
            </div>
          ))}
        </div>
      )}

      {/* ── Contract Security ── */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="px-4 py-2.5 border-b border-white/5 flex items-center gap-2">
          <span className="text-sm">🛡️</span>
          <p className="text-xs font-black text-white uppercase tracking-wider">Contract Security</p>
        </div>
        <div className="px-4 py-1">
          {/* Label = kondisi AMAN. ok=true → ✅, ok=false → ❌/⚠️ */}
          <CheckRow
            label="Source Code Verified"
            ok={result.contractChecks.sourceVerified}
            desc={result.contractChecks.sourceVerified
              ? "Contract verified — kode bisa diaudit siapa saja"
              : "Contract TIDAK verified — kode tidak bisa diaudit"} />
          <CheckRow
            label="Bukan Proxy Contract"
            ok={!result.contractChecks.isProxy}
            attention={result.contractChecks.isProxy}
            desc={result.contractChecks.isProxy
              ? "⚠️ Proxy contract — owner bisa upgrade logic contract kapan saja"
              : "Bukan proxy, logic contract tidak bisa diubah"} />
          <CheckRow
            label="Tidak Ada Mint Function"
            ok={!result.contractChecks.isMintable}
            attention={result.contractChecks.isMintable}
            desc={result.contractChecks.isMintable
              ? "⚠️ Ada mint function — developer bisa cetak token baru dan dilusi holder"
              : "Supply tetap, tidak ada yang bisa mencetak token baru"} />
          <CheckRow
            label="Ownership Tidak Bisa Diambil Balik"
            ok={!result.contractChecks.canTakeBackOwnership}
            desc={result.contractChecks.canTakeBackOwnership
              ? "❌ Ada fungsi ambil balik ownership — meski renounced, bisa di-reclaim"
              : "Tidak ada fungsi ambil balik ownership"} />
          <CheckRow
            label="Owner Tidak Bisa Ubah Balance"
            ok={!result.contractChecks.ownerCanChangeBalance}
            desc={result.contractChecks.ownerCanChangeBalance
              ? "❌ Owner bisa mengubah saldo token di wallet manapun"
              : "Owner tidak bisa mengubah saldo token holder"} />
          <CheckRow
            label="Tidak Ada Hidden Owner"
            ok={!result.contractChecks.hasHiddenOwner}
            desc={result.contractChecks.hasHiddenOwner
              ? "❌ Hidden owner terdeteksi — bisa manipulasi contract meski sudah renounced"
              : "Tidak ada hidden owner"} />
          <CheckRow
            label="Tidak Ada Self-destruct"
            ok={!result.contractChecks.canSelfDestruct}
            desc={result.contractChecks.canSelfDestruct
              ? "❌ Self-destruct function ada — contract bisa dihancurkan, aset hilang"
              : "Contract tidak bisa dihancurkan"} />
          <CheckRow
            label="Tidak Ada External Call Risiko"
            ok={!result.contractChecks.hasExternalCall}
            attention={result.contractChecks.hasExternalCall}
            desc={result.contractChecks.hasExternalCall
              ? "⚠️ Ada external call — contract bergantung pada contract lain"
              : "Tidak ada external call risiko"} />
        </div>
      </div>

      {/* ── HoneyPot Risk ── */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="px-4 py-2.5 border-b border-white/5 flex items-center gap-2">
          <span className="text-sm">🍯</span>
          <p className="text-xs font-black text-white uppercase tracking-wider">HoneyPot Risk</p>
          <span className="ml-auto text-[10px] font-black text-white/40">
            Buy Tax <span className={(result.buyTax ?? 0) > 0 ? "text-yellow-300" : "text-[#00ff87]"}>{result.buyTax != null ? result.buyTax.toFixed(0) : "?"}%</span>
            {" · "}Sell Tax <span className={(result.sellTax ?? 0) > 0 ? "text-yellow-300" : "text-[#00ff87]"}>{result.sellTax != null ? result.sellTax.toFixed(0) : "?"}%</span>
          </span>
        </div>
        <div className="px-4 py-1">
          <CheckRow
            label="Trading Tidak Bisa Di-pause"
            ok={!result.contractChecks.canPauseTrading}
            desc={result.contractChecks.canPauseTrading
              ? "❌ Ada fungsi pause trading — developer bisa freeze beli/jual kapan saja"
              : "Tidak ada fungsi pause, trading selalu bisa dilakukan"} />
          <CheckRow
            label="Bukan Honeypot — Token Bisa Dijual"
            ok={!result.isHoneypot}
            desc={result.isHoneypot
              ? "❌ HONEYPOT — token tidak bisa dijual kembali"
              : "Token bisa dibeli dan dijual secara normal"} />
          <CheckRow
            label="Tidak Ada Trading Cooldown"
            ok={!result.contractChecks.hasTradingCooldown}
            attention={result.contractChecks.hasTradingCooldown}
            desc={result.contractChecks.hasTradingCooldown
              ? "⚠️ Ada cooldown — holder harus tunggu beberapa blok sebelum bisa jual"
              : "Tidak ada cooldown, bisa jual kapan saja"} />
          <CheckRow
            label="Tidak Ada Anti-Whale Limit"
            ok={!result.contractChecks.hasAntiWhale}
            attention={result.contractChecks.hasAntiWhale}
            desc={result.contractChecks.hasAntiWhale
              ? "⚠️ Ada anti-whale — ada batas maksimal transaksi per wallet"
              : "Tidak ada limit transaksi, bisa jual semua sekaligus"} />
          <CheckRow
            label="Tidak Ada Blacklist Function"
            ok={!result.contractChecks.hasBlacklist}
            attention={result.contractChecks.hasBlacklist}
            desc={result.contractChecks.hasBlacklist
              ? "⚠️ Ada blacklist — developer bisa blokir wallet tertentu dari trading"
              : "Tidak ada blacklist"} />
          <CheckRow
            label="Tidak Ada Whitelist"
            ok={!result.contractChecks.hasWhitelist}
            attention={result.contractChecks.hasWhitelist}
            desc={result.contractChecks.hasWhitelist
              ? "⚠️ Ada whitelist — hanya alamat tertentu yang bisa trading"
              : "Tidak ada whitelist, siapa saja bisa trading"} />
        </div>
      </div>

      {/* ── LP / Liquidity Lock ── */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="px-4 py-2.5 border-b border-white/5 flex items-center gap-2">
          <span className="text-sm">💧</span>
          <p className="text-xs font-black text-white uppercase tracking-wider">Liquidity Lock</p>
          {result.onlyV4 && (
            <span className="ml-auto text-[9px] font-black bg-orange-500/20 text-orange-400 border border-orange-500/30 px-2 py-0.5 rounded-full">
              V4 — GoPlus buta
            </span>
          )}
        </div>
        <div className="px-4 py-3 flex flex-col gap-3">

          {/* ── VERDICT BANNER — satu kalimat, jelas banget ── */}
          {(() => {
            const isFullSafe = result.isProtocol || result.lockStatus === "locked";
            const isPartial  = result.lockStatus === "partial";
            const isDanger   = result.lockStatus === "unlocked";
            const isUnknown  = result.lockStatus === "unverified";
            const lockedPct  = result.isProtocol ? 100 : result.lpLockedPct;

            if (isFullSafe) return (
              <div className="rounded-xl bg-[#00ff87]/10 border border-[#00ff87]/30 px-4 py-3 flex items-center gap-3">
                <span className="text-2xl shrink-0">🔒</span>
                <div>
                  <p className="text-[#00ff87] font-black text-sm leading-tight">LP AMAN</p>
                  <p className="text-[#00ff87]/80 text-[11px] font-bold mt-0.5">
                    {lockedPct.toFixed(0)}% liquidity dikunci — dev <span className="underline">tidak bisa</span> tarik dana
                  </p>
                </div>
              </div>
            );
            if (isPartial) return (
              <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/30 px-4 py-3 flex items-center gap-3">
                <span className="text-2xl shrink-0">⚠️</span>
                <div>
                  <p className="text-yellow-300 font-black text-sm leading-tight">LP SEBAGIAN AMAN</p>
                  <p className="text-yellow-300/80 text-[11px] font-bold mt-0.5">
                    {lockedPct.toFixed(0)}% terkunci, {(100 - lockedPct).toFixed(0)}% masih bisa ditarik dev
                  </p>
                </div>
              </div>
            );
            if (isDanger) return (
              <div className="rounded-xl bg-[#ff3b5c]/10 border border-[#ff3b5c]/30 px-4 py-3 flex items-center gap-3">
                <span className="text-2xl shrink-0">🔓</span>
                <div>
                  <p className="text-[#ff3b5c] font-black text-sm leading-tight">LP TIDAK AMAN — RISIKO RUGPULL</p>
                  <p className="text-[#ff3b5c]/80 text-[11px] font-bold mt-0.5">
                    {lockedPct.toFixed(0)}% terkunci — dev bisa tarik likuiditas kapan saja
                  </p>
                </div>
              </div>
            );
            // unverified
            return (
              <div className="rounded-xl bg-white/5 border border-white/15 px-4 py-3 flex items-center gap-3">
                <span className="text-2xl shrink-0">❓</span>
                <div>
                  <p className="text-white/70 font-black text-sm leading-tight">LP TIDAK TERVERIFIKASI</p>
                  <p className="text-white/50 text-[11px] font-bold mt-0.5">
                    Anggap tidak aman sampai terbukti sebaliknya
                  </p>
                </div>
              </div>
            );
          })()}

          {/* ── Lock bar + pct ── */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <p className="text-[10px] text-white/50 font-bold">LP terkunci</p>
              <p className={`text-sm font-black ${
                result.isProtocol || result.lockStatus === "locked" ? "text-[#00ff87]" :
                result.lockStatus === "partial" ? "text-yellow-400" :
                result.lockStatus === "unverified" ? "text-white/40" :
                "text-[#ff3b5c]"
              }`}>
                {result.isProtocol ? "100" : result.lockStatus === "unverified" ? "?" : result.lpLockedPct.toFixed(0)}%
              </p>
            </div>
            <div className="h-2.5 w-full rounded-full bg-white/10 overflow-hidden">
              <div className={`h-full rounded-full transition-all ${
                result.isProtocol || result.lockStatus === "locked" ? "bg-[#00ff87] shadow-[0_0_8px_rgba(0,255,135,0.5)]" :
                result.lockStatus === "partial" ? "bg-yellow-400" :
                result.lockStatus === "unverified" ? "bg-white/20" :
                "bg-[#ff3b5c]/50"
              }`} style={{ width: `${result.isProtocol ? 100 : Math.max(result.lpLockedPct, 0)}%` }} />
            </div>
            <div className="flex justify-between text-[9px] font-bold mt-1">
              <span className="text-[#ff3b5c]">0% — Bebas</span>
              <span className="text-white/30">50%</span>
              <span className="text-[#00ff87]">100% — Terkunci</span>
            </div>
          </div>

          {/* ── Penjelasan sumber lock ── */}
          {result.lockDetail && (
            <div className={`rounded-lg px-3 py-2 text-[11px] font-bold leading-snug ${
              result.lockStatus === "protocol" || result.lockStatus === "locked"
                ? "bg-[#00ff87]/5 text-[#00ff87]/80 border border-[#00ff87]/15"
                : result.lockStatus === "partial"
                ? "bg-yellow-500/5 text-yellow-400/80 border border-yellow-500/15"
                : result.lockStatus === "unverified"
                ? "bg-white/5 text-white/50 border border-white/10"
                : "bg-[#ff3b5c]/5 text-[#ff3b5c]/80 border border-[#ff3b5c]/15"
            }`}>
              {result.lockDetail}
            </div>
          )}

          {/* ── Holders: Total LP + holder count ── */}
          <div className="flex gap-3 text-[10px]">
            <span className="text-white/40 font-bold">Supply LP: {result.lpTotalSupply.toLocaleString("en", { maximumFractionDigits: 2 })}</span>
            <span className="text-white/40">·</span>
            <span className="text-white/40 font-bold">Holders: {result.lpHolderCount ?? "?"}</span>
          </div>

          {/* ── LP rows ── */}
          {result.lpHolderRows.map((lp, i) => {
            const src = lp.lockedSource ?? "none";
            // Icon & label per source — jelas dan tidak ambigu
            const lockIcon =
              src === "protocol"         ? "🔒" :
              src === "goplus"           ? "🔒" :
              src === "known_locker"     ? "🔒" :
              src === "unknown_contract" ? "⚠️" :
              src === "eoa"              ? "🔓" : "🔓";

            const lockLabel: { text: string; cls: string } =
              src === "protocol"         ? { text: "protokol — permanen",      cls: "bg-[#00ff87]/10 text-[#00ff87] border border-[#00ff87]/20" } :
              src === "goplus"           ? { text: "locker resmi (GoPlus)",    cls: "bg-[#00ff87]/10 text-[#00ff87] border border-[#00ff87]/20" } :
              src === "known_locker"     ? { text: "locker terverifikasi",     cls: "bg-[#00ff87]/10 text-[#00ff87] border border-[#00ff87]/20" } :
              src === "unknown_contract" ? { text: "⚠️ contract tdk dikenal", cls: "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20" } :
                                           { text: "wallet EOA — bisa ditarik", cls: "bg-[#ff3b5c]/10 text-[#ff3b5c] border border-[#ff3b5c]/20" };

            return (
              <div key={i} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs shrink-0">{lockIcon}</span>
                    <p className="text-[10px] font-mono text-white/70 truncate">{fmtAddr(lp.address)}</p>
                    {lp.tag && <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#0052FF]/15 text-[#6b9fff] font-bold shrink-0">{lp.tag}</span>}
                  </div>
                  <div className="ml-5 mt-0.5">
                    <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${lockLabel.cls}`}>
                      {lockLabel.text}
                    </span>
                    {lp.nftIds.length > 0 && (
                      <span className="text-[9px] text-white/30 ml-2">NFT #{lp.nftIds.slice(0,2).join(", #")}</span>
                    )}
                  </div>
                </div>
                <div className="text-right shrink-0 ml-3">
                  <p className="text-[11px] font-black text-white">{parseFloat(lp.percent).toFixed(2)}%</p>
                  {lp.value !== "0" && <p className="text-[9px] text-white/40">${parseFloat(lp.value).toLocaleString("en", { maximumFractionDigits: 0 })}</p>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Basic Info ── */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="px-4 py-2.5 border-b border-white/5 flex items-center gap-2">
          <span className="text-sm">📋</span>
          <p className="text-xs font-black text-white uppercase tracking-wider">Basic Info</p>
        </div>
        <div className="px-4 py-3 flex flex-col gap-2">
          {[
            ["Token Symbol", token.symbol],
            ["Token Name", token.name],
            ["Platform", result.platform],
            ["Creator", result.creatorAddress ? fmtAddr(result.creatorAddress) : "?"],
            ["Owner", result.ownerAddress ? fmtAddr(result.ownerAddress) : result.ownerRenounced ? "Renounced" : "?"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between">
              <span className="text-[11px] text-white/50 font-bold">{k}</span>
              <span className="text-[11px] font-black text-white font-mono">{v}</span>
            </div>
          ))}
          {result.dexList.length > 0 && (
            <div>
              <p className="text-[11px] text-white/50 font-bold mb-1.5">DEX</p>
              {result.dexList.map((d, i) => (
                <div key={i} className="flex items-center justify-between py-0.5">
                  <p className="text-[10px] font-mono text-white/40 truncate max-w-[120px]">{d.pairAddress.slice(0, 10)}...{d.pairAddress.slice(-6)}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] uppercase font-black text-[#6b9fff]">{d.dex}{d.labels.length ? " "+d.labels[0] : ""}</span>
                    <span className="text-[10px] font-black text-white">{fmtUsd(d.liqUsd)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Top 10 Holders ── */}
      {result.top10Holders.length > 0 && (
        <div className="glass rounded-2xl overflow-hidden">
          <div className="px-4 py-2.5 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-sm">👥</span>
              <p className="text-xs font-black text-white uppercase tracking-wider">Top 10 Holders</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-white/40">Holders: {result.holderCount?.toLocaleString() ?? "?"}</p>
            </div>
          </div>
          <div className="px-4 py-3">
            <div className="flex items-center justify-between mb-2">
              <p className="text-[10px] text-white/50">Top 10 ratio</p>
              <p className="text-[11px] font-black text-white">{result.top10HolderPct.toFixed(2)}%</p>
            </div>
            {/* Bar */}
            <div className="h-1.5 w-full rounded-full bg-white/10 mb-3 overflow-hidden">
              <div className="h-full rounded-full bg-[#0052FF]" style={{ width: `${Math.min(result.top10HolderPct, 100)}%` }} />
            </div>
            {result.top10Holders.map((h, i) => (
              <div key={i} className="flex items-center justify-between py-1 border-b border-white/5 last:border-0">
                <div className="flex items-center gap-1.5 flex-1 min-w-0">
                  <span className="text-[9px] text-white/30 w-4 shrink-0">{i+1}</span>
                  <span className="text-xs shrink-0">{h.isContract ? "📄" : "👤"}</span>
                  <p className="text-[10px] font-mono text-white/60 truncate">{fmtAddr(h.address)}</p>
                  {h.tag && <span className="text-[9px] px-1 py-0.5 rounded bg-[#0052FF]/10 text-[#6b9fff] font-bold shrink-0">{h.tag}</span>}
                </div>
                <div className="text-right shrink-0 ml-2">
                  <p className="text-[11px] font-black text-white">{parseFloat(h.percent).toFixed(4)}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Trade CTA */}
      <button onClick={onTrade}
        className="w-full rounded-xl bg-[#0052FF] py-3.5 text-sm font-black text-white shadow-[0_0_20px_rgba(0,82,255,0.40)] hover:bg-[#0047e0] transition-all">
        ⚡ Setup Trade Token Ini →
      </button>
    </div>
  );
}

// ─── Trade Setup Form ─────────────────────────────────────────────────────────

interface QuoteResult {
  totalLiqUsd: number;
  estimatedUsdOut: number;
  priceImpactPct: number;
  priceInconsistent: boolean;
  warnings: string[];
  safe: boolean;
  paraswapOk?: boolean; // true = Paraswap bisa estimasi
  kyberOk?: boolean;    // true = KyberSwap bisa estimasi (fallback)
  noRoute?: boolean;    // true = semua aggregator gagal estimasi (jarang terjadi)
}

function TradeSetupForm({ token, fid, onSuccess, onBack }: {
  token: TokenInfo; fid: number; onSuccess: () => void; onBack: () => void;
}) {
  const currentPrice = parseFloat(token.priceUsd);

  const [buyAmount, setBuyAmount]               = useState("0.001");
  const [buyTrigger, setBuyTrigger]             = useState("");
  const [sellMode, setSellMode]                 = useState<"price" | "pct">("pct");
  const [sellTargetPrice, setSellTargetPrice]   = useState((currentPrice * 2).toFixed(6));
  const [takeProfitPct, setTakeProfitPct]       = useState("100");
  const [stopLossPct, setStopLossPct]           = useState("50");
  const [useTP, setUseTP]                       = useState(true);
  const [useSL, setUseSL]                       = useState(true);
  const [gasTier, setGasTier]                   = useState<"slow" | "normal" | "fast">("normal");
  const [loading, setLoading]                   = useState(false);
  const [error, setError]                       = useState("");
  const [quote, setQuote]                       = useState<QuoteResult | null>(null);
  const [quoteLoading, setQuoteLoading]         = useState(false);
  const [confirmed, setConfirmed]               = useState(false);

  // Fetch quote simulasi saat amount berubah (debounced 600ms)
  useEffect(() => {
    setQuote(null); setConfirmed(false);
    const t = setTimeout(async () => {
      const amt = parseFloat(buyAmount);
      if (isNaN(amt) || amt <= 0) return;
      setQuoteLoading(true);
      try {
        const res = await fetch(`/api/trader/quote?tokenAddress=${token.address}&buyAmountEth=${buyAmount}`);
        const data = await res.json();
        if (!data.error) setQuote(data);
      } catch { /* silent */ }
      finally { setQuoteLoading(false); }
    }, 600);
    return () => clearTimeout(t);
  }, [buyAmount, token.address]);

  const handleSubmit = async () => {
    setError(""); setLoading(true);
    try {
      const body: Record<string, unknown> = {
        fid, tokenAddress: token.address, tokenName: token.name,
        tokenSymbol: token.symbol, tokenPriceUsd: token.priceUsd,
        tokenPriceNative: token.priceNative,   // harga ETH per token — untuk TP/SL akurat
        tokenImageUrl: token.imageUrl, buyAmountEth: buyAmount,
        buyTriggerPriceUsd: buyTrigger ? parseFloat(buyTrigger) : null,
      };
      if (sellMode === "price") {
        body.sellTargetPriceUsd = sellTargetPrice ? parseFloat(sellTargetPrice) : null;
        body.takeProfitPct = null;
      } else {
        body.takeProfitPct = useTP ? parseFloat(takeProfitPct) : null;
        body.sellTargetPriceUsd = null;
      }
      body.stopLossPct = useSL ? parseFloat(stopLossPct) : null;
      body.gasTier = gasTier;
      const res = await apiFetch("/api/trader/buy", {
        method: "POST", body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok || data.error) { setError(data.error ?? "Gagal"); return; }
      onSuccess();
    } catch { setError("Koneksi gagal"); }
    finally { setLoading(false); }
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 glass rounded-xl p-3">
        {token.imageUrl ? (
          <img src={token.imageUrl} alt={token.symbol} className="w-8 h-8 rounded-full ring-2 ring-[#0052FF]/30" />
        ) : (
          <div className="w-8 h-8 rounded-full bg-[#0052FF]/20 border border-[#0052FF]/30 flex items-center justify-center">🪙</div>
        )}
        <div className="flex-1">
          <p className="font-black text-white text-sm">{token.name} <span className="text-[#6b9fff]">${token.symbol}</span></p>
          <p className="text-xs text-white/75">Harga: <span className="text-white font-black">${currentPrice.toFixed(6)}</span></p>
        </div>
        <button onClick={onBack} className="text-[11px] font-bold text-[#6b9fff]/70 hover:text-[#6b9fff] border border-[#0052FF]/20 rounded-lg px-2 py-1">← Ganti</button>
      </div>

      <div>
        <label className="text-xs text-white/85 mb-1.5 block font-bold">Jumlah Beli (ETH)</label>
        <div className="flex gap-1.5 mb-2">
          {["0.0001","0.001","0.005","0.01"].map((v) => (
            <button key={v} onClick={() => setBuyAmount(v)}
              className={`flex-1 rounded-lg py-2 text-[11px] font-black transition-all ${buyAmount === v ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.4)]" : "border border-[#0052FF]/20 bg-[#0052FF]/5 text-white/70 hover:text-white/80"}`}>
              {v}
            </button>
          ))}
        </div>
        <input type="number" value={buyAmount} onChange={(e) => setBuyAmount(e.target.value)}
          className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 backdrop-blur-sm px-3 py-2 text-sm text-white focus:border-[#0052FF]/60 focus:outline-none"
          step="0.0001" min="0.0001" max="1" />
      </div>

      {/* ── Gas Fee Tier ── */}
      <div className="glass rounded-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs font-black text-white">⛽ Gas Fee</p>
          <p className="text-[10px] text-white/40">Base L2 — biasanya &lt; $0.01</p>
        </div>
        <div className="flex gap-1.5">
          {([
            { key: "slow",   label: "🐢 Hemat",  desc: "1x gas" },
            { key: "normal", label: "⚡ Normal",  desc: "1.2x gas" },
            { key: "fast",   label: "🚀 Cepat",   desc: "1.5x gas" },
          ] as const).map((t) => (
            <button key={t.key} onClick={() => setGasTier(t.key)}
              className={`flex-1 rounded-lg py-2 flex flex-col items-center gap-0.5 transition-all ${
                gasTier === t.key
                  ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.4)]"
                  : "border border-[#0052FF]/20 bg-[#0052FF]/5 text-white/60 hover:text-white/80"
              }`}>
              <span className="text-[11px] font-black">{t.label}</span>
              <span className="text-[9px] opacity-70">{t.desc}</span>
            </button>
          ))}
        </div>
        {gasTier === "slow" && (
          <p className="text-[10px] text-yellow-400/80 mt-1.5">⚠️ Hemat: TX bisa lebih lambat dikonfirmasi</p>
        )}
      </div>

      <div className="glass rounded-xl p-3">
        <p className="text-xs font-black text-white mb-1">⏳ Beli Otomatis di Harga <span className="text-[#6b9fff]/60 font-normal">(opsional)</span></p>
        <p className="text-[10px] text-white/75 mb-2">Kosongkan untuk beli sekarang. Isi untuk beli jika harga turun ke target.</p>
        <div className="flex items-center gap-2">
          <span className="text-sm text-[#6b9fff]/60">$</span>
          <input type="number" placeholder={`Sekarang: $${currentPrice.toFixed(6)}`}
            value={buyTrigger} onChange={(e) => setBuyTrigger(e.target.value)}
            className="flex-1 rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 backdrop-blur-sm px-3 py-2 text-sm text-white placeholder-white/30 focus:border-[#0052FF]/60 focus:outline-none"
            step="0.000001" min="0" />
        </div>
      </div>

      <div className="glass rounded-xl p-3">
        <p className="text-xs font-black text-white mb-2">🎯 Target Jual</p>
        <div className="flex gap-2 mb-3">
          {(["pct","price"] as const).map((m) => (
            <button key={m} onClick={() => setSellMode(m)}
              className={`flex-1 rounded-lg py-1.5 text-xs font-black transition-all ${sellMode === m ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.35)]" : "border border-[#0052FF]/20 bg-[#0052FF]/5 text-white/65 hover:text-white/85"}`}>
              {m === "pct" ? "% Profit" : "Harga Target"}
            </button>
          ))}
        </div>
        {sellMode === "price" ? (
          <div className="flex items-center gap-2">
            <span className="text-sm text-[#6b9fff]/60">Jual di $</span>
            <input type="number" value={sellTargetPrice} onChange={(e) => setSellTargetPrice(e.target.value)}
              className="flex-1 rounded-lg border border-[#00ff87]/30 bg-[#00ff87]/10 backdrop-blur-sm px-3 py-2 text-sm text-white focus:border-[#00ff87]/60 focus:outline-none"
              step="0.000001" min="0" />
            {sellTargetPrice && currentPrice > 0 && (
              <span className="text-xs text-[#00ff87] shrink-0">
                +{(((parseFloat(sellTargetPrice) - currentPrice) / currentPrice) * 100).toFixed(0)}%
              </span>
            )}
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-white/85">Take Profit</span>
              <button onClick={() => setUseTP((v) => !v)}
                className={`h-5 w-10 rounded-full transition-colors ${useTP ? "bg-[#00ff87]" : "bg-white/10"}`}>
                <div className={`h-4 w-4 rounded-full bg-white transition-transform mx-0.5 ${useTP ? "translate-x-5" : "translate-x-0"}`} />
              </button>
            </div>
            {useTP && (
              <div className="flex items-center gap-2 mb-1">
                <input type="number" value={takeProfitPct} onChange={(e) => setTakeProfitPct(e.target.value)}
                  className="flex-1 rounded-lg border border-[#00ff87]/30 bg-[#00ff87]/10 backdrop-blur-sm px-3 py-2 text-sm text-white focus:border-[#00ff87]/60 focus:outline-none"
                  min="1" max="10000" />
                <span className="text-sm text-white/85">%</span>
                <span className="text-xs text-white/65 shrink-0">
                  = ${(currentPrice * (1 + parseFloat(takeProfitPct || "0") / 100)).toFixed(6)}
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="glass rounded-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <div>
            <p className="text-xs font-black text-white">🛑 Stop Loss</p>
            <p className="text-[10px] text-white/75">Jual otomatis jika rugi melebihi %</p>
          </div>
          <button onClick={() => setUseSL((v) => !v)}
            className={`h-5 w-10 rounded-full transition-colors ${useSL ? "bg-[#ff3b5c]" : "bg-white/10"}`}>
            <div className={`h-4 w-4 rounded-full bg-white transition-transform mx-0.5 ${useSL ? "translate-x-5" : "translate-x-0"}`} />
          </button>
        </div>
        {useSL && (
          <div className="flex items-center gap-2">
            <input type="number" value={stopLossPct} onChange={(e) => setStopLossPct(e.target.value)}
              className="flex-1 rounded-lg border border-[#ff3b5c]/30 bg-[#ff3b5c]/10 backdrop-blur-sm px-3 py-2 text-sm text-white focus:border-[#ff3b5c]/60 focus:outline-none"
              min="1" max="100" />
            <span className="text-sm text-white/85">%</span>
            <span className="text-xs text-white/65 shrink-0">
              = ${(currentPrice * (1 - parseFloat(stopLossPct || "0") / 100)).toFixed(6)}
            </span>
          </div>
        )}
      </div>

      {/* ── Simulasi swap / warning ── */}
      {quoteLoading && (
        <div className="rounded-xl bg-[#0052FF]/10 border border-[#0052FF]/20 px-3 py-2.5 flex items-center gap-2">
          <span className="text-sm animate-pulse">🔍</span>
          <p className="text-[11px] text-[#6b9fff] font-bold">Simulasi swap...</p>
        </div>
      )}

      {quote && !quoteLoading && (
        <div className={`rounded-xl border px-3 py-3 flex flex-col gap-2 ${
          quote.safe ? "bg-[#00ff87]/5 border-[#00ff87]/20" :
          quote.priceImpactPct > 30 ? "bg-[#ff3b5c]/10 border-[#ff3b5c]/30" :
          "bg-yellow-500/10 border-yellow-500/25"
        }`}>
          {/* Estimasi output */}
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold text-white/50">Estimasi yang kamu dapat</p>
            <p className={`text-sm font-black ${
              quote.safe ? "text-[#00ff87]" :
              quote.priceImpactPct > 30 ? "text-[#ff3b5c]" : "text-yellow-300"
            }`}>
              ~${quote.estimatedUsdOut > 0 ? quote.estimatedUsdOut.toFixed(4) : "?"}
            </p>
          </div>
          {/* Price impact */}
          {quote.priceImpactPct > 0 && (
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-white/50">Price Impact</p>
              <p className={`text-xs font-black ${
                quote.priceImpactPct > 30 ? "text-[#ff3b5c]" :
                quote.priceImpactPct > 10 ? "text-yellow-300" : "text-[#00ff87]"
              }`}>~{quote.priceImpactPct.toFixed(1)}%</p>
            </div>
          )}
          {/* Likuiditas */}
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold text-white/50">Total Likuiditas</p>
            <p className={`text-xs font-black ${
              quote.totalLiqUsd < 1000 ? "text-[#ff3b5c]" :
              quote.totalLiqUsd < 5000 ? "text-yellow-300" : "text-[#00ff87]"
            }`}>${quote.totalLiqUsd.toLocaleString("en", { maximumFractionDigits: 0 })}</p>
          </div>
          {/* Warnings */}
          {quote.warnings.length > 0 && (
            <div className="flex flex-col gap-1 mt-1">
              {quote.warnings.map((w, i) => (
                <p key={i} className="text-[10px] leading-snug text-yellow-300 font-bold">{w}</p>
              ))}
            </div>
          )}
          {/* Konfirmasi jika ada warning */}
          {!quote.safe && (
            <label className="flex items-center gap-2 mt-1 cursor-pointer">
              <input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)}
                className="w-4 h-4 rounded accent-[#ff3b5c]" />
              <span className="text-[10px] text-white/70 font-bold">Saya mengerti risikonya dan tetap mau beli</span>
            </label>
          )}
        </div>
      )}

      {error && <p className="text-xs text-[#ff3b5c] bg-[#ff3b5c]/10 rounded-lg px-3 py-2">{error}</p>}

      {/* noRoute = semua aggregator gagal estimasi, tapi tetap boleh coba beli */}
      {quote?.noRoute && (
        <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/25 px-4 py-3">
          <p className="text-yellow-400 text-xs font-black mb-1">⚠️ Estimasi Tidak Tersedia</p>
          <p className="text-white/70 text-[11px] leading-relaxed">
            Sistem tidak bisa estimasi output sekarang. Beli tetap bisa dicoba — sistem akan cari rute otomatis (Paraswap → Kyber → LI.FI → Zora). Jika gagal, coba di{" "}
            <a href={`https://zora.co/coin/base:${token.address}`} target="_blank" rel="noopener noreferrer"
              className="text-[#6b9fff] underline font-bold">Zora.co</a>.
          </p>
        </div>
      )}

      <button
        onClick={handleSubmit}
        disabled={loading || quoteLoading || (!quote?.safe && !confirmed && quote !== null)}
        className="w-full rounded-xl bg-[#0052FF] py-3 text-sm font-black text-white shadow-[0_0_20px_rgba(0,82,255,0.45)] hover:bg-[#0047e0] disabled:opacity-40 transition-all">
        {loading ? "Memproses..." : buyTrigger ? `📋 Buat Order Beli di $${buyTrigger}` : `⚡ Beli ${buyAmount} ETH Sekarang`}
      </button>
    </div>
  );
}

// ─── Live Stats Hook ──────────────────────────────────────────────────────────

function useLiveStats(
  tokenAddress: string,
  tokensReceived: string | null,
  buyAmountEth: string,
  fid: number | null,
  enabled: boolean,
  ethUsdAtBuy: string | null,       // ETH/USD rate saat buy — cost basis akurat
) {
  const [stats, setStats] = useState<LiveStats | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStats = useCallback(async () => {
    if (!enabled) return;
    setRefreshing(true);
    try {
      // Fetch price data + on-chain sniper wallet balance in parallel
      const pricePromise = fetch(`/api/trader/lookup?address=${tokenAddress}`).then(r => r.json());
      const balancePromise = fid
        ? fetch(`/api/trader/balance?fid=${fid}&tokenAddress=${tokenAddress}`).then(r => r.json()).catch(() => null)
        : Promise.resolve(null);

      const [data, balanceData] = await Promise.all([pricePromise, balancePromise]);
      if (!data || data.error) return;

      const currentPriceUsd = parseFloat(data.priceUsd ?? "0");
      const currentPriceNative = parseFloat(data.priceNative ?? "0");
      // Decimals from lookup — needed for accurate DB fallback conversion
      const tokenDecimals: number = typeof data.decimals === "number" ? data.decimals : 18;
      // ETH/USD rate untuk cost basis:
      // - Prioritas 1: rate saat buy dieksekusi (disimpan di DB) — paling akurat
      // - Prioritas 2: rate saat ini dari lookup — fallback untuk posisi lama
      const costBasisEthUsd: number = ethUsdAtBuy
        ? parseFloat(ethUsdAtBuy)
        : (data.ethUsdRate ?? 2000);
      const currentEthUsd: number = data.ethUsdRate ?? costBasisEthUsd;
      const buyEth = parseFloat(buyAmountEth);

      // ── Token quantity: on-chain sniper wallet balance (wallet crypto approach) ─
      // Priority:
      //   1. On-chain balance from sniper wallet (ALWAYS accurate, like MetaMask)
      //   2. tokensReceived from DB receipt (fallback jika balance API gagal)
      // Note: walletAddress di Farcaster ≠ sniper wallet, jadi kita pakai /api/trader/balance

      let tokensHeld: number | null = null;

      if (balanceData && !balanceData.error && balanceData.hasBalance && balanceData.balance > 0) {
        // Source 1: on-chain balance dari sniper wallet — paling akurat
        tokensHeld = balanceData.balance;
      } else if (tokensReceived) {
        // Source 2: tokensReceived dari DB — fallback
        // Use actual token decimals from lookup to handle 6-decimal tokens (USDC etc.)
        try {
          const rawBig = BigInt(tokensReceived);
          if (rawBig > BigInt(0)) {
            const divisor = 10n ** BigInt(tokenDecimals);
            const wholePart = rawBig / divisor;
            const fracPart  = rawBig % divisor;
            tokensHeld = Number(wholePart) + Number(fracPart) / Number(divisor);
          }
        } catch { /* ignore */ }
      }

      const tokenBalance: string | null = tokensHeld !== null ? tokensHeld.toFixed(6) : null;
      const tokenBalanceUsd = tokensHeld !== null ? tokensHeld * currentPriceUsd : 0;

      // ── PnL calculation ───────────────────────────────────────────────────────
      // Strategy:
      //   - priceNative from DexScreener is ONLY reliable when the best pair is ETH/WETH-quoted.
      //     For tokens like SUPPOK whose best pair is SUPPOK/VIRTUAL or SUPPOK/USDC,
      //     priceNative is in VIRTUAL/USDC, NOT ETH → using it gives nonsense ETH PnL.
      //   - The lookup route now sets priceNative="0" when no ETH pair exists.
      //
      // Primary method (ETH-based) — used when priceNative > 0 AND is a real ETH price:
      //   ethNow = tokensHeld × priceNative (ETH per token)
      //   pnlPct = (ethNow - buyEth) / buyEth × 100
      //
      // Fallback method (USD-based) — used when no ETH pair:
      //   currentValueUsd = tokensHeld × priceUsd
      //   buyValueUsd = buyEth × ethUsdRate  (ETH spent → USD equivalent at buy time)
      //   pnlPct = (currentValueUsd - buyValueUsd) / buyValueUsd × 100
      //
      // ETH/USD rate comes from the position's buyPriceUsd + buyAmountEth if available,
      // otherwise we approximate from the token's own USD/native ratio if it has an ETH pair.
      let pnlPct = 0;
      let pnlUsd = 0;

      if (tokensHeld !== null && tokensHeld > 0 && buyEth > 0) {
        // priceNative > 0 means lookup confirmed a reliable ETH/WETH pair exists.
        // lookup/route.ts already sets priceNative="0" when no ETH pair found,
        // so we only need to check > 0 here (no upper bound — some tokens cost > 1 ETH).
        const hasEthPrice = currentPriceNative > 0;

        if (hasEthPrice) {
          // ETH-based PnL — priceNative verified dari ETH/WETH pair
          const ethNow = tokensHeld * currentPriceNative;
          pnlPct = ((ethNow - buyEth) / buyEth) * 100;
          pnlUsd = (ethNow - buyEth) * currentEthUsd;
        } else if (currentPriceUsd > 0 && costBasisEthUsd > 0) {
          // USD-based PnL — token tidak punya ETH pair (e.g. SUPPOK/VIRTUAL)
          // buyValueUsd = ETH dikeluarkan × ETH/USD saat beli (akurat dari DB)
          const currentValueUsd = tokensHeld * currentPriceUsd;
          const buyValueUsd = buyEth * costBasisEthUsd;
          pnlUsd = currentValueUsd - buyValueUsd;
          pnlPct = buyValueUsd > 0 ? (pnlUsd / buyValueUsd) * 100 : 0;
        }
      }

      setStats({
        priceUsd: data.priceUsd,
        priceNative: data.priceNative,
        priceChange24h: data.priceChange24h ?? 0,
        priceChange1h: data.priceChange1h ?? 0,
        liquidity: data.liquidity ?? 0,
        volume24h: data.volume24h ?? 0,
        marketCap: data.marketCap ?? data.fdv ?? 0,
        fdv: data.fdv ?? 0,
        buys24h: data.buys24h ?? 0,
        sells24h: data.sells24h ?? 0,
        imageUrl: data.imageUrl,
        tokenBalance,
        tokenBalanceUsd,
        pnlPct,
        pnlUsd,
      });
    } catch { /* silent */ }
    finally { setRefreshing(false); }
  }, [tokenAddress, tokensReceived, buyAmountEth, fid, enabled, ethUsdAtBuy]);

  // Initial fetch + auto-refresh every 10s (real-time like Coinbase/OKX)
  useEffect(() => {
    if (!enabled) return;
    fetchStats();
    const interval = setInterval(fetchStats, 10_000);
    return () => clearInterval(interval);
  }, [fetchStats, enabled]);

  return { stats, refreshing, refresh: fetchStats };
}

// ─── Position Card ────────────────────────────────────────────────────────────

function PositionCard({ pos, fid, walletAddress, onCancel, onSellDone, onTargetsUpdated }: {
  pos: Position; fid: number;
  walletAddress: string | null;
  onCancel: (id: string) => void;
  onSellDone: () => void;
  onTargetsUpdated: () => void;
}) {
  const isActive = pos.status === "active";
  const isPending = pos.status === "pending_buy";

  const { stats, refreshing, refresh } = useLiveStats(
    pos.tokenAddress,
    pos.tokensReceived ?? null,
    pos.buyAmountEth,
    fid,
    isActive || isPending,
    pos.ethUsdAtBuy ?? null,
  );

  const [selling, setSelling]         = useState(false);
  const [sellError, setSellError]     = useState("");
  // confirm modal state: null = hidden, "sell" | "sell_loss" | "cancel" = shown
  const [confirm, setConfirm]         = useState<"sell" | "sell_loss" | "cancel" | null>(null);
  // displayed TP/SL values — optimistically updated on save so card shows new values immediately
  const [displayTP, setDisplayTP]     = useState(pos.takeProfitPct ?? "");
  const [displaySL, setDisplaySL]     = useState(pos.stopLossPct ?? "");
  // edit TP/SL inline
  const [editingTargets, setEditingTargets] = useState(false);
  const [editTP, setEditTP]           = useState(pos.takeProfitPct ?? "");
  const [editSL, setEditSL]           = useState(pos.stopLossPct ?? "");
  const [savingTargets, setSavingTargets] = useState(false);
  const [targetError, setTargetError] = useState("");

  const saveTargets = async () => {
    setSavingTargets(true); setTargetError("");
    try {
      const res = await apiFetch("/api/trader/positions", {
        method: "PATCH",
        body: JSON.stringify({
          fid,
          positionId: pos.id,
          takeProfitPct: editTP.trim() !== "" ? parseFloat(editTP) : null,
          stopLossPct:   editSL.trim() !== "" ? parseFloat(editSL) : null,
        }),
      });
      const data = await res.json();
      if (!res.ok || data.error) { setTargetError(data.error ?? "Gagal menyimpan"); return; }
      // Update displayed values immediately — don't wait for parent re-fetch
      setDisplayTP(editTP.trim());
      setDisplaySL(editSL.trim());
      setEditingTargets(false);
      onTargetsUpdated();
    } catch { setTargetError("Koneksi gagal"); }
    finally { setSavingTargets(false); }
  };

  const token = pos.tokenSymbol ? `$${pos.tokenSymbol}` : pos.tokenName ?? pos.tokenAddress.slice(0, 10) + "...";
  const statusMap: Record<string, { label: string; cls: string }> = {
    pending_buy: { label: "Menunggu Beli", cls: "bg-yellow-500/10 text-yellow-400" },
    active:      { label: "Aktif",         cls: "bg-[#00ff87]/10 text-[#00ff87]" },
    sold:        { label: "Terjual",        cls: "bg-[#0052FF]/10 text-[#6b9fff]" },
    cancelled:   { label: "Dibatalkan",     cls: "bg-[#4a5568]/20 text-white/65" },
    buy_failed:  { label: "Gagal Beli",     cls: "bg-[#ff3b5c]/10 text-[#ff3b5c]" },
  };
  const s = statusMap[pos.status] ?? { label: pos.status, cls: "bg-[#4a5568]/20 text-white/85" };

  const pnlPct = stats?.pnlPct ?? (pos.pnlPct ? parseFloat(pos.pnlPct) : null);
  const isProfit = pnlPct !== null && pnlPct >= 0;

  // confirmLoss: true dikirim setelah user acknowledge kerugian di modal
  const executeSell = async (confirmLoss = false) => {
    setSellError(""); setSelling(true);
    try {
      const res = await apiFetch("/api/trader/sell", {
        method: "POST",
        body: JSON.stringify({ fid, positionId: pos.id, confirmLoss }),
      });
      const data = await res.json();
      // Kalau API bilang posisi sedang rugi dan butuh konfirmasi eksplisit
      if (res.status === 422 && data.lossConfirmRequired) {
        setConfirm("sell_loss");
        return;
      }
      if (!res.ok || data.error) { setSellError(data.error ?? "Sell gagal"); return; }
      onSellDone();
    } catch { setSellError("Koneksi gagal"); }
    finally { setSelling(false); }
  };

  const executeCancel = () => {
    onCancel(pos.id);
  };

  return (
    <>
      {/* Sell confirmation modal */}
      {confirm === "sell" && (
        <ConfirmModal
          title={`Jual ${token} sekarang?`}
          message="Token akan dijual di harga pasar saat ini. Aksi ini tidak bisa dibatalkan."
          confirmLabel="Ya, Jual Sekarang"
          confirmClass="bg-[#ff3b5c]"
          onConfirm={() => { setConfirm(null); executeSell(false); }}
          onCancel={() => setConfirm(null)}
        />
      )}

      {/* Sell LOSS warning modal — tampil ketika posisi sedang rugi */}
      {confirm === "sell_loss" && (
        <ConfirmModal
          title="⚠️ Posisi Sedang Rugi!"
          message={`Kamu akan REALISE kerugian${
            stats?.pnlPct !== undefined && stats.pnlPct < 0
              ? ` sebesar ${formatPct(stats.pnlPct)}`
              : ""
          }${
            stats?.pnlUsd !== undefined && stats.pnlUsd < 0
              ? ` (~$${Math.abs(stats.pnlUsd).toFixed(4)})`
              : ""
          }. Yakin mau jual sekarang dan cut loss?`}
          confirmLabel="Ya, Cut Loss Sekarang"
          confirmClass="bg-[#ff3b5c]"
          onConfirm={() => { setConfirm(null); executeSell(true); }}
          onCancel={() => setConfirm(null)}
        />
      )}

      {/* Cancel confirmation modal */}
      {confirm === "cancel" && (
        <ConfirmModal
          title="Batalkan order ini?"
          message={`Order ${token} akan dibatalkan dan tidak akan dimonitor lagi.`}
          confirmLabel="Ya, Batalkan"
          confirmClass="bg-[#4a5568]"
          onConfirm={() => { setConfirm(null); executeCancel(); }}
          onCancel={() => setConfirm(null)}
        />
      )}

      <div className="glass rounded-xl overflow-hidden">
        {/* Header row */}
        <div className="w-full p-4 text-left">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              {(stats?.imageUrl || pos.tokenImageUrl) ? (
                <img src={stats?.imageUrl ?? pos.tokenImageUrl!} alt={token} className="w-8 h-8 rounded-full shrink-0 ring-2 ring-[#0052FF]/25" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-[#0052FF]/20 border border-[#0052FF]/30 flex items-center justify-center shrink-0">🪙</div>
              )}
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="font-bold text-white text-sm">{token}</span>
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${s.cls}`}>{s.label}</span>
                </div>
                <p className="text-[11px] text-white/80 font-semibold">
                  Entry: ${parseFloat(pos.buyPriceUsd ?? pos.tokenPriceUsd ?? "0").toFixed(7)}
                </p>
              </div>
            </div>

            {/* Badge pojok kanan atas — hanya untuk posisi sold (dari DB, akurat) */}
            {pos.status === "sold" && pos.pnlPct && (
              <div className={`text-right shrink-0 ${parseFloat(pos.pnlPct) >= 0 ? "text-[#00ff87]" : "text-[#ff3b5c]"}`}>
                <p className="text-sm font-bold leading-tight">{formatPct(parseFloat(pos.pnlPct))}</p>
                {pos.pnlEth && (
                  <p className="text-[10px] font-semibold opacity-80 leading-tight">
                    {parseFloat(pos.pnlEth) >= 0 ? "+" : ""}{parseFloat(pos.pnlEth).toFixed(5)} ETH
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Active position live stats */}
        {isActive && (
          <div className="px-4 pb-3 flex flex-col gap-2">
            {stats && (
              <div className="flex flex-col gap-1.5">
                {/* Row 1: Price + MC + Vol + Liq */}
                <div className="grid grid-cols-4 gap-1.5 text-center text-[10px]">
                  <div className="glass-cell rounded-lg py-1.5 px-1">
                    <p className="text-[#6b9fff] font-semibold">Harga</p>
                    <p className="text-white font-black leading-tight">
                      ${parseFloat(stats.priceUsd) < 0.000001
                        ? parseFloat(stats.priceUsd).toExponential(2)
                        : parseFloat(stats.priceUsd).toFixed(6)}
                    </p>
                    {stats.priceChange1h !== 0 && (
                      <p className={`text-[9px] leading-tight ${stats.priceChange1h >= 0 ? "text-[#00ff87]" : "text-[#ff3b5c]"}`}>
                        {stats.priceChange1h >= 0 ? "+" : ""}{stats.priceChange1h.toFixed(1)}% 1h
                      </p>
                    )}
                  </div>
                  <div className="glass-cell rounded-lg py-1.5 px-1">
                    <p className="text-[#6b9fff] font-semibold">MC</p>
                    <p className="text-white font-black leading-tight">
                      {stats.marketCap >= 1000000
                        ? `$${(stats.marketCap / 1000000).toFixed(2)}M`
                        : stats.marketCap >= 1000
                          ? `$${(stats.marketCap / 1000).toFixed(1)}K`
                          : `$${stats.marketCap.toFixed(0)}`}
                    </p>
                    {stats.priceChange24h !== 0 && (
                      <p className={`text-[9px] leading-tight ${stats.priceChange24h >= 0 ? "text-[#00ff87]" : "text-[#ff3b5c]"}`}>
                        {stats.priceChange24h >= 0 ? "+" : ""}{stats.priceChange24h.toFixed(1)}% 24h
                      </p>
                    )}
                  </div>
                  <div className="glass-cell rounded-lg py-1.5 px-1">
                    <p className="text-[#6b9fff] font-semibold">Vol 24h</p>
                    <p className="text-white font-black leading-tight">
                      {stats.volume24h >= 1000000
                        ? `$${(stats.volume24h / 1000000).toFixed(1)}M`
                        : stats.volume24h >= 1000
                          ? `$${(stats.volume24h / 1000).toFixed(1)}K`
                          : `$${stats.volume24h.toFixed(0)}`}
                    </p>
                    {(stats.buys24h > 0 || stats.sells24h > 0) && (
                      <p className="text-[9px] text-white/65 leading-tight">
                        <span className="text-[#00ff87]">B{stats.buys24h}</span>/<span className="text-[#ff3b5c]">S{stats.sells24h}</span>
                      </p>
                    )}
                  </div>
                  <div className="glass-cell rounded-lg py-1.5 px-1">
                    <p className="text-[#6b9fff] font-semibold">Liq</p>
                    <p className="text-white font-black leading-tight">
                      {stats.liquidity >= 1000000
                        ? `$${(stats.liquidity / 1000000).toFixed(1)}M`
                        : stats.liquidity >= 1000
                          ? `$${(stats.liquidity / 1000).toFixed(1)}K`
                          : `$${stats.liquidity.toFixed(0)}`}
                    </p>
                  </div>
                </div>

                {/* Row 2: Hold value (on-chain balance from sniper wallet) */}
                {(stats.tokenBalanceUsd > 0 || stats.tokenBalance) && (
                  <div className="glass-cell rounded-lg px-3 py-2 flex items-center justify-between">
                    <div>
                      <p className="text-[#6b9fff] text-[10px] font-semibold">Hold Value (on-chain)</p>
                      <p className="text-white text-xs font-black">
                        ${stats.tokenBalanceUsd > 0 ? stats.tokenBalanceUsd.toFixed(4) : "0.0000"}
                        {stats.tokenBalance && (
                          <span className="text-white/80 font-semibold ml-1">
                            ({parseFloat(stats.tokenBalance).toLocaleString(undefined, { maximumFractionDigits: 2 })} token)
                          </span>
                        )}
                      </p>
                    </div>
                    {stats.pnlPct !== 0 && (() => {
                      // Gunakan stats.pnlPct langsung — sudah dihitung akurat di useLiveStats
                      // (ETH-based jika ada ETH pair, USD-based fallback)
                      const isPos = stats.pnlPct >= 0;
                      return (
                        <div className={`text-right font-bold ${isPos ? "text-[#00ff87]" : "text-[#ff3b5c]"}`}>
                          <p className="text-sm leading-tight">{formatPct(stats.pnlPct)}</p>
                          {stats.pnlUsd !== 0 && (
                            <p className="text-[10px] opacity-80 leading-tight font-semibold">
                              {isPos ? "+" : ""}${Math.abs(stats.pnlUsd).toFixed(4)} PnL
                            </p>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>
            )}

            <div className="grid grid-cols-2 gap-1.5 text-xs">
              <div className="glass-cell rounded-lg p-2">
                <p className="text-[#6b9fff] font-semibold mb-0.5">Beli</p>
                <p className="text-white font-black">{parseFloat(pos.buyAmountEth).toFixed(6)} ETH</p>
              </div>
              <div className="glass-cell rounded-lg p-2">
                <div className="flex items-center justify-between mb-0.5">
                  <p className="text-[#6b9fff] font-semibold">Target Jual</p>
                  {!editingTargets && (
                    <button
                      onClick={() => { setEditTP(displayTP); setEditSL(displaySL); setEditingTargets(true); setTargetError(""); }}
                      className="text-[9px] font-black text-[#6b9fff] bg-[#0052FF]/15 border border-[#0052FF]/25 rounded px-1.5 py-0.5 hover:bg-[#0052FF]/30 transition-colors"
                    >
                      Edit
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-1">
                  {pos.sellTargetPriceUsd && <span className="text-[#00ff87]">${parseFloat(pos.sellTargetPriceUsd).toFixed(4)}</span>}
                  {displayTP && <span className="text-[#00ff87]">+{displayTP}%</span>}
                  {displaySL && <span className="text-[#ff3b5c]">-{displaySL}%</span>}
                  {!pos.sellTargetPriceUsd && !displayTP && !displaySL && <span className="text-white/65">—</span>}
                </div>
              </div>
            </div>

            {/* Inline TP/SL editor */}
            {editingTargets && (
              <div className="glass-cell rounded-xl p-3 flex flex-col gap-2.5">
                <p className="text-[10px] font-black text-white">✏️ Ubah Target</p>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[9px] font-bold text-[#00ff87] mb-1 block">Take Profit (%)</label>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        value={editTP}
                        onChange={(e) => setEditTP(e.target.value)}
                        placeholder="mis: 50"
                        min="1" max="10000"
                        className="flex-1 rounded-lg border border-[#00ff87]/30 bg-[#00ff87]/10 px-2 py-1.5 text-xs text-white focus:outline-none focus:border-[#00ff87]/60"
                      />
                      <span className="text-[10px] text-white/60">%</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-[#ff3b5c] mb-1 block">Stop Loss (%)</label>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        value={editSL}
                        onChange={(e) => setEditSL(e.target.value)}
                        placeholder="mis: 25"
                        min="1" max="100"
                        className="flex-1 rounded-lg border border-[#ff3b5c]/30 bg-[#ff3b5c]/10 px-2 py-1.5 text-xs text-white focus:outline-none focus:border-[#ff3b5c]/60"
                      />
                      <span className="text-[10px] text-white/60">%</span>
                    </div>
                  </div>
                </div>
                <p className="text-[9px] text-white/50">Kosongkan untuk nonaktifkan TP atau SL</p>
                {targetError && <p className="text-[10px] text-[#ff3b5c] bg-[#ff3b5c]/10 rounded px-2 py-1">{targetError}</p>}
                <div className="flex gap-2">
                  <button
                    onClick={saveTargets}
                    disabled={savingTargets}
                    className="flex-1 rounded-lg bg-[#0052FF] py-2 text-xs font-black text-white hover:opacity-90 disabled:opacity-50 transition-all"
                  >
                    {savingTargets ? "Menyimpan..." : "Simpan"}
                  </button>
                  <button
                    onClick={() => setEditingTargets(false)}
                    className="rounded-lg border border-white/15 px-3 py-2 text-xs text-white/60 hover:text-white transition-colors"
                  >
                    Batal
                  </button>
                </div>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-2 mt-1">
              <button
                onClick={refresh} disabled={refreshing}
                className="rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2 text-xs text-[#6b9fff] hover:bg-[#0052FF]/20 disabled:opacity-50 transition-all">
                {refreshing ? "⟳" : "↻"}
              </button>
              <button
                onClick={() => setConfirm("sell")} disabled={selling}
                className="flex-1 rounded-xl bg-[#ff3b5c] py-2 text-xs font-black text-white shadow-[0_0_10px_rgba(255,59,92,0.30)] hover:opacity-90 disabled:opacity-50 transition-opacity">
                {selling ? "Menjual..." : "💰 Sell Market"}
              </button>
              <button
                onClick={() => setConfirm("cancel")}
                className="rounded-lg border border-white/10 px-3 py-2 text-xs text-white/65 hover:text-[#ff3b5c] hover:border-[#ff3b5c]/30 transition-colors">
                Batal
              </button>
            </div>

            {sellError && (
              <p className="text-[11px] text-[#ff3b5c] bg-[#ff3b5c]/10 rounded-lg px-3 py-2">{sellError}</p>
            )}
          </div>
        )}

        {/* Pending buy */}
        {isPending && (
          <div className="px-4 pb-3 flex flex-col gap-2">
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              <div className="glass-cell rounded-lg p-2">
                <p className="text-[#6b9fff] font-semibold mb-0.5">Beli</p>
                <p className="text-white font-black">{parseFloat(pos.buyAmountEth).toFixed(6)} ETH</p>
              </div>
              <div className="glass-cell rounded-lg p-2">
                <p className="text-[#6b9fff] font-semibold mb-0.5">Target Jual</p>
                <div className="flex flex-wrap gap-1">
                  {pos.takeProfitPct && <span className="text-[#00ff87]">+{pos.takeProfitPct}%</span>}
                  {pos.stopLossPct && <span className="text-[#ff3b5c]">-{pos.stopLossPct}%</span>}
                  {!pos.takeProfitPct && !pos.stopLossPct && <span className="text-white/65">—</span>}
                </div>
              </div>
            </div>
            {pos.buyTriggerPriceUsd && (
              <p className="text-[11px] text-yellow-400 bg-yellow-500/5 rounded-lg px-2 py-1">
                ⏳ Akan beli jika harga ≤ ${parseFloat(pos.buyTriggerPriceUsd).toFixed(6)}
              </p>
            )}
            <button onClick={() => setConfirm("cancel")}
              className="w-full rounded-lg border border-[#0052FF]/20 bg-[#0052FF]/5 py-2 text-xs text-white/70 hover:text-[#ff3b5c] hover:border-[#ff3b5c]/30 transition-colors">
              Batalkan Order
            </button>
          </div>
        )}

        {/* Sold / closed */}
        {(pos.status === "sold" || pos.status === "cancelled" || pos.status === "buy_failed") && (
          <div className="px-4 pb-3">
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              <div className="glass-cell rounded-lg p-2">
                <p className="text-[#6b9fff] font-semibold mb-0.5">Beli</p>
                <p className="text-white font-black">{parseFloat(pos.buyAmountEth).toFixed(6)} ETH</p>
              </div>
              <div className="glass-cell rounded-lg p-2">
                <p className="text-[#6b9fff] font-semibold mb-0.5">Alasan</p>
                <p className="text-white font-bold capitalize">{pos.closeReason?.replace("_", " ") ?? pos.status}</p>
              </div>
            </div>
            {pos.status === "sold" && pos.pnlEth && (
              <div className={`mt-2 text-sm font-bold ${parseFloat(pos.pnlEth) >= 0 ? "text-[#00ff87]" : "text-[#ff3b5c]"}`}>
                {parseFloat(pos.pnlEth) >= 0 ? "+" : ""}{parseFloat(pos.pnlEth).toFixed(6)} ETH
                {pos.pnlPct && <span className="text-xs ml-1 opacity-70">({formatPct(parseFloat(pos.pnlPct))})</span>}
                {pos.closeReason === "take_profit" && <span className="ml-1">🎯</span>}
                {pos.closeReason === "stop_loss"   && <span className="ml-1">🛑</span>}
                {pos.closeReason === "manual_sell" && <span className="ml-1">💰</span>}
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
}

// ─── Main Trader Tab ──────────────────────────────────────────────────────────

// Sub-views inside "orders" tab
type OrdersSubView = "positions" | "new" | "analyze";

export function TraderTab({ fid }: { fid: number }) {
  const [view, setView]               = useState<TraderView>("orders");
  const [ordersSubView, setOrdersSub] = useState<OrdersSubView>("positions");
  const [selectedToken, setToken]     = useState<TokenInfo | null>(null);
  const [positions, setPositions]     = useState<Position[]>([]);
  const [history, setHistory]         = useState<Position[]>([]);
  const [loading, setLoading]         = useState(false);
  const [success, setSuccess]         = useState("");
  const [walletAddress, setWallet]    = useState<string | null>(null);

  // Lookup tab state
  const [lookupInput, setLookupInput]   = useState("");
  const [lookupLoading, setLookupLoading] = useState(false);
  const [lookupToken, setLookupToken]   = useState<TokenInfo | null>(null);
  const [lookupError, setLookupError]   = useState("");
  const [lookupSubView, setLookupSub]   = useState<"search" | "info" | "analyze">("search");

  useEffect(() => {
    apiFetch(`/api/sniper/settings?fid=${fid}`)
      .then((r) => r.json())
      .then((d) => { if (d?.walletAddress) setWallet(d.walletAddress.toLowerCase()); })
      .catch(() => {});
  }, [fid]);

  const loadPositions = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch(`/api/trader/positions?fid=${fid}&type=active`);
      const data = await res.json();
      setPositions(data.positions ?? []);
    } catch {/* silent */} finally { setLoading(false); }
  }, [fid]);

  const loadHistory = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch(`/api/trader/positions?fid=${fid}&type=history`);
      const data = await res.json();
      setHistory(data.positions ?? []);
    } catch {/* silent */} finally { setLoading(false); }
  }, [fid]);

  useEffect(() => {
    if (view === "orders" && ordersSubView === "positions") loadPositions();
    if (view === "history") loadHistory();
  }, [view, ordersSubView, loadPositions, loadHistory]);

  const handleCancel = async (id: string) => {
    await apiFetch(`/api/trader/positions?fid=${fid}&id=${id}`, { method: "DELETE" });
    loadPositions();
  };

  const handleTradeSuccess = () => {
    setSuccess("Order berhasil dibuat!");
    setToken(null);
    setOrdersSub("positions");
    loadPositions();
    setTimeout(() => setSuccess(""), 3000);
  };

  const handleSellDone = () => {
    setSuccess("Sell berhasil!");
    loadPositions();
    setTimeout(() => setSuccess(""), 3000);
  };

  const doLookup = async () => {
    const addr = lookupInput.trim().toLowerCase();
    if (!/^0x[0-9a-f]{40}$/.test(addr)) { setLookupError("Masukkan contract address yang valid (0x...)"); return; }
    setLookupError(""); setLookupLoading(true); setLookupToken(null); setLookupSub("search");
    try {
      const res = await fetch(`/api/trader/lookup?address=${addr}`);
      const data = await res.json();
      if (!res.ok || data.error) { setLookupError(data.error ?? "Token tidak ditemukan"); return; }
      setLookupToken(data);
      setLookupSub("info");
    } catch { setLookupError("Koneksi gagal"); }
    finally { setLookupLoading(false); }
  };

  // ── Tab nav items ──────────────────────────────────────────────────────────
  const TABS: { key: TraderView; label: string }[] = [
    { key: "lookup",  label: "🔍 Lookup" },
    { key: "orders",  label: "📋 Orders" },
    { key: "history", label: "📜 History" },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* ── Tab bar ── */}
      <div className="flex glass-header">
        {TABS.map((t) => (
          <button key={t.key}
            onClick={() => {
              setView(t.key);
              if (t.key === "orders") setOrdersSub("positions");
            }}
            className={`flex-1 py-3 text-xs transition-all relative ${
              view === t.key ? "text-white font-black" : "text-white/65 hover:text-white/85 font-bold"
            }`}>
            {t.label}
            {view === t.key && (
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 w-12 rounded-full bg-[#0052FF] shadow-[0_0_6px_rgba(0,82,255,0.8)]" />
            )}
          </button>
        ))}
      </div>

      {success && (
        <div className="mx-4 mt-3 rounded-lg bg-[#0052FF]/15 border border-[#0052FF]/25 px-3 py-2 text-xs text-[#6b9fff] font-bold">{success}</div>
      )}

      <div className="flex-1 overflow-y-auto p-4">

        {/* ════════════ LOOKUP TAB ════════════ */}
        {view === "lookup" && (
          <div className="flex flex-col gap-3">
            {/* Search bar — always visible */}
            <div>
              <label className="text-xs text-white/85 mb-1.5 block font-bold">Contract Address Token</label>
              <div className="flex gap-2">
                <input
                  type="text" placeholder="0x... (Base — Zora, Clanker, Uniswap)"
                  value={lookupInput}
                  onChange={(e) => { setLookupInput(e.target.value); setLookupError(""); }}
                  onKeyDown={(e) => e.key === "Enter" && doLookup()}
                  className="flex-1 rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 backdrop-blur-sm px-3 py-2.5 text-sm text-white placeholder-white/30 focus:border-[#0052FF]/60 focus:outline-none font-mono"
                />
                <button onClick={doLookup} disabled={lookupLoading || !lookupInput.trim()}
                  className="rounded-lg bg-[#0052FF] px-4 py-2.5 text-sm font-black text-white shadow-[0_0_12px_rgba(0,82,255,0.35)] hover:bg-[#0047e0] disabled:opacity-40 transition-all">
                  {lookupLoading ? "⟳" : "Cari"}
                </button>
              </div>
              <p className="text-[10px] text-white/50 mt-1">Analisis harga, MC, volume, likuiditas, & keamanan token</p>
            </div>

            {lookupError && <p className="text-xs text-[#ff3b5c] bg-[#ff3b5c]/10 rounded-lg px-3 py-2 font-bold">{lookupError}</p>}

            {/* Sub-nav once token is found */}
            {lookupToken && (
              <>
                <div className="flex gap-2">
                  {(["info", "analyze"] as const).map((s) => (
                    <button key={s} onClick={() => setLookupSub(s)}
                      className={`flex-1 rounded-xl py-2.5 text-xs font-black transition-all ${
                        lookupSubView === s
                          ? "bg-[#0052FF] text-white shadow-[0_0_12px_rgba(0,82,255,0.4)]"
                          : "border border-[#0052FF]/25 bg-[#0052FF]/5 text-white/60 hover:text-white/80"
                      }`}>
                      {s === "info" ? "📊 Info Harga" : "🛡️ Safety Check"}
                    </button>
                  ))}
                </div>

                {/* Info sub-view — existing TokenLookup result UI */}
                {lookupSubView === "info" && (() => {
                  const token = lookupToken;
                  const price = parseFloat(token.priceUsd);
                  const totalTxns24h = token.buys24h + token.sells24h;
                  const totalTxns6h  = token.buys6h  + token.sells6h;
                  const buyPct24h = totalTxns24h > 0 ? Math.round((token.buys24h / totalTxns24h) * 100) : 50;
                  const buyPct6h  = totalTxns6h  > 0 ? Math.round((token.buys6h  / totalTxns6h)  * 100) : 50;
                  return (
                    <div className="glass rounded-2xl overflow-hidden">
                      <div className="px-4 pt-4 pb-3 border-b border-[#0052FF]/15">
                        <div className="flex items-center gap-3">
                          {token.imageUrl ? (
                            <img src={token.imageUrl} alt={token.symbol} className="w-12 h-12 rounded-full ring-2 ring-[#0052FF]/40 shadow-[0_0_12px_rgba(0,82,255,0.25)] shrink-0" />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-[#0052FF]/20 border border-[#0052FF]/30 flex items-center justify-center text-xl shrink-0">🪙</div>
                          )}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-black text-white text-base leading-tight">{token.name}</span>
                              <span className="text-[#6b9fff] font-bold text-sm">${token.symbol}</span>
                              <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-[#0052FF]/20 text-[#6b9fff]">
                                {token.dex === "unknown" ? "DEX" : token.dex.toUpperCase()}
                              </span>
                            </div>
                            <p className="text-[10px] text-white/50 font-mono mt-0.5 truncate">{token.address}</p>
                          </div>
                        </div>
                        <div className="mt-3 flex items-end gap-3 flex-wrap">
                          <div>
                            <p className="text-2xl font-black text-white leading-none">{fmtPrice(price)}</p>
                            <p className="text-[10px] text-white/50 mt-0.5">{parseFloat(token.priceNative).toFixed(8)} ETH</p>
                          </div>
                          <div className="flex gap-1 flex-wrap mb-0.5">
                            {token.priceChange5m  !== 0 && <PctBadge v={token.priceChange5m}  label="5m"  />}
                            {token.priceChange1h  !== 0 && <PctBadge v={token.priceChange1h}  label="1h"  />}
                            {token.priceChange6h  !== 0 && <PctBadge v={token.priceChange6h}  label="6h"  />}
                            {token.priceChange24h !== 0 && <PctBadge v={token.priceChange24h} label="24h" />}
                          </div>
                        </div>
                      </div>
                      <div className="px-4 pt-3 grid grid-cols-3 gap-2">
                        <div className="glass-cell rounded-xl p-3">
                          <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Market Cap</p>
                          <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.marketCap)}</p>
                          {token.fdv > 0 && token.fdv !== token.marketCap && (
                            <p className="text-[9px] text-white/45 mt-0.5">FDV {fmtUsd(token.fdv)}</p>
                          )}
                        </div>
                        <div className="glass-cell rounded-xl p-3">
                          <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Liquidity</p>
                          <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.liquidity)}</p>
                          <p className="text-[9px] text-white/45 mt-0.5 uppercase">{token.dex === "unknown" ? "DEX" : token.dex}</p>
                        </div>
                        <div className="glass-cell rounded-xl p-3">
                          <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Usia</p>
                          <p className="text-white font-black text-sm leading-tight">{fmtAge(token.pairCreatedAt)}</p>
                          {token.holders !== null && (
                            <p className="text-[9px] text-white/45 mt-0.5">{token.holders.toLocaleString()} holders</p>
                          )}
                        </div>
                      </div>
                      <div className="px-4 pt-2 grid grid-cols-3 gap-2">
                        <div className="glass-cell rounded-xl p-3">
                          <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Vol 24h</p>
                          <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.volume24h)}</p>
                          {totalTxns24h > 0 && (
                            <p className="text-[9px] mt-0.5">
                              <span className="text-[#00ff87]">B{token.buys24h}</span>
                              <span className="text-white/40">/</span>
                              <span className="text-[#ff3b5c]">S{token.sells24h}</span>
                            </p>
                          )}
                        </div>
                        <div className="glass-cell rounded-xl p-3">
                          <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Vol 6h</p>
                          <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.volume6h)}</p>
                          {totalTxns6h > 0 && (
                            <p className="text-[9px] mt-0.5">
                              <span className="text-[#00ff87]">B{token.buys6h}</span>
                              <span className="text-white/40">/</span>
                              <span className="text-[#ff3b5c]">S{token.sells6h}</span>
                            </p>
                          )}
                        </div>
                        <div className="glass-cell rounded-xl p-3">
                          <p className="text-[9px] font-bold uppercase tracking-wider text-[#6b9fff] mb-1">Vol 1h</p>
                          <p className="text-white font-black text-sm leading-tight">{fmtUsd(token.volume1h)}</p>
                        </div>
                      </div>
                      {(totalTxns24h > 0 || totalTxns6h > 0) && (
                        <div className="px-4 pt-2 pb-1 flex flex-col gap-2">
                          {totalTxns24h > 0 && (
                            <div>
                              <div className="flex justify-between text-[9px] font-bold mb-1">
                                <span className="text-[#00ff87]">BUY {buyPct24h}%</span>
                                <span className="text-white/40 text-[8px]">TEKANAN 24h</span>
                                <span className="text-[#ff3b5c]">SELL {100 - buyPct24h}%</span>
                              </div>
                              <div className="h-1.5 w-full rounded-full overflow-hidden bg-[#ff3b5c]/25">
                                <div className="h-full rounded-full bg-[#00ff87] transition-all" style={{ width: `${buyPct24h}%` }} />
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                      {token.tradeWarning && (
                        <div className="mx-4 mb-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 px-3 py-2">
                          <p className="text-[11px] text-yellow-400 font-bold">⚠️ {token.tradeWarning}</p>
                        </div>
                      )}
                      <div className="px-4 pb-4 pt-2 flex gap-2">
                        <button onClick={() => setLookupSub("analyze")}
                          className="flex-1 rounded-xl border border-[#0052FF]/30 bg-[#0052FF]/10 py-3 text-sm font-black text-[#6b9fff] hover:bg-[#0052FF]/20 transition-all">
                          🛡️ Safety Check
                        </button>
                        <button onClick={() => { setToken(lookupToken); setView("orders"); setOrdersSub("new"); }}
                          className="flex-1 rounded-xl bg-[#0052FF] py-3 text-sm font-black text-white shadow-[0_0_20px_rgba(0,82,255,0.40)] hover:bg-[#0047e0] transition-all">
                          ⚡ Trade →
                        </button>
                      </div>
                    </div>
                  );
                })()}

                {/* Analyze sub-view */}
                {lookupSubView === "analyze" && (
                  <TokenAnalyzer
                    token={lookupToken}
                    onTrade={() => { setToken(lookupToken); setView("orders"); setOrdersSub("new"); }}
                  />
                )}
              </>
            )}
          </div>
        )}

        {/* ════════════ ORDERS TAB (positions + trade baru) ════════════ */}
        {view === "orders" && (
          <div className="flex flex-col gap-3">
            {/* Sub-tab: Posisi Aktif | Trade Baru */}
            <div className="flex gap-2 -mt-1 mb-1">
              {([
                { key: "positions", label: "📋 Posisi Aktif" },
                { key: "new",       label: "➕ Trade Baru" },
              ] as { key: OrdersSubView; label: string }[]).map((s) => (
                <button key={s.key} onClick={() => { setOrdersSub(s.key); setToken(null); }}
                  className={`flex-1 rounded-xl py-2.5 text-xs font-black transition-all ${
                    ordersSubView === s.key
                      ? "bg-[#0052FF] text-white shadow-[0_0_12px_rgba(0,82,255,0.4)]"
                      : "border border-[#0052FF]/25 bg-[#0052FF]/5 text-white/60 hover:text-white/80"
                  }`}>
                  {s.label}
                </button>
              ))}
            </div>

            {/* Posisi Aktif */}
            {ordersSubView === "positions" && (
              loading ? (
                <p className="text-center text-white/80 font-bold text-sm py-8">Memuat...</p>
              ) : positions.length === 0 ? (
                <div className="text-center py-10">
                  <div className="text-4xl mb-3">📊</div>
                  <p className="text-white/85 text-sm font-bold">Belum ada posisi aktif</p>
                  <p className="text-white/80 font-semibold text-xs mt-1">Buat trade baru untuk mulai</p>
                  <button onClick={() => setOrdersSub("new")}
                    className="mt-4 rounded-xl bg-[#0052FF] px-5 py-2.5 text-sm font-black text-white shadow-[0_0_16px_rgba(0,82,255,0.40)] hover:bg-[#0047e0] transition-all">
                    ➕ Trade Baru
                  </button>
                </div>
              ) : (
                positions.map((p) => (
                  <PositionCard key={p.id} pos={p} fid={fid} walletAddress={walletAddress} onCancel={handleCancel} onSellDone={handleSellDone} onTargetsUpdated={loadPositions} />
                ))
              )
            )}

            {/* Trade Baru */}
            {ordersSubView === "new" && (
              !selectedToken ? (
                <TokenLookup onSelect={setToken} />
              ) : (
                <TradeSetupForm
                  token={selectedToken} fid={fid}
                  onSuccess={handleTradeSuccess}
                  onBack={() => setToken(null)}
                />
              )
            )}
          </div>
        )}

        {/* ════════════ HISTORY TAB ════════════ */}
        {view === "history" && (
          <div className="flex flex-col gap-3">
            {loading ? (
              <p className="text-center text-white/80 font-bold text-sm py-8">Memuat...</p>
            ) : history.filter((p) => p.status === "sold" || p.status === "cancelled" || p.status === "buy_failed").length === 0 ? (
              <div className="text-center py-10">
                <div className="text-4xl mb-3">📜</div>
                <p className="text-white/85 font-bold text-sm">Belum ada riwayat trade</p>
              </div>
            ) : (
              history
                .filter((p) => p.status === "sold" || p.status === "cancelled" || p.status === "buy_failed")
                .map((p) => <PositionCard key={p.id} pos={p} fid={fid} walletAddress={walletAddress} onCancel={handleCancel} onSellDone={handleSellDone} onTargetsUpdated={loadHistory} />)
            )}
          </div>
        )}

      </div>
    </div>
  );
}
