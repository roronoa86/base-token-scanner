"use client";

import { useState, useEffect, useCallback } from "react";
import { apiFetch } from "@/lib/api-client";

interface ClankerSettings {
  isEnabled: boolean;
  buyAmountEth: string;
  slippageBps: number;
  maxBuysPerDay: number;
  minLiquidityUsd: number;
  maxTokenAgeMin: number;
}

interface SnipeLog {
  id: string;
  tokenAddress: string;
  tokenName: string | null;
  tokenSymbol: string | null;
  volumeUsdAtSnipe: number | null;
  buyAmountEth: string;
  txHash: string | null;
  status: string;
  errorMessage: string | null;
  createdAt: string;
}

function fmtAge(isoStr: string): string {
  const diffMs = Date.now() - new Date(isoStr).getTime();
  const m = Math.floor(diffMs / 60_000);
  const h = Math.floor(diffMs / 3_600_000);
  const d = Math.floor(diffMs / 86_400_000);
  if (m < 60) return `${m}m lalu`;
  if (h < 24) return `${h}j lalu`;
  return `${d}h lalu`;
}

const STATUS_MAP: Record<string, { label: string; cls: string }> = {
  pending: { label: "Pending",  cls: "bg-yellow-500/10 text-yellow-400" },
  success: { label: "Berhasil", cls: "bg-[#00ff87]/10 text-[#00ff87]" },
  failed:  { label: "Gagal",    cls: "bg-[#ff3b5c]/10 text-[#ff3b5c]" },
  skipped: { label: "Dilewati", cls: "bg-white/5 text-white/40" },
};

// Konversi bps ke persen untuk display
function bpsToPercent(bps: number): string {
  return (bps / 100).toFixed(1);
}

// Konversi persen ke bps untuk simpan
function percentToBps(pct: string): number {
  return Math.round(parseFloat(pct) * 100);
}

export function ClankerTab({ fid }: { fid: number }) {
  const [settings, setSettings]   = useState<ClankerSettings | null>(null);
  const [history, setHistory]     = useState<SnipeLog[]>([]);
  const [loading, setLoading]     = useState(true);
  const [saving, setSaving]       = useState(false);
  const [toggling, setToggling]   = useState(false);
  const [saveError, setSaveError] = useState("");
  const [saveOk, setSaveOk]       = useState(false);
  const [view, setView]           = useState<"settings" | "history">("settings");

  // Test poll (scan tanpa buy)
  const [pollRunning, setPollRunning] = useState(false);
  const [pollResult, setPollResult]   = useState<string | null>(null);

  // Test buy manual
  const [testAddr, setTestAddr]     = useState("");
  const [testRunning, setTestRunning] = useState(false);
  const [testLogs, setTestLogs]     = useState<string[]>([]);
  const [testResult, setTestResult] = useState<{ success: boolean; txHash?: string; error?: string } | null>(null);

  // Form state
  const [buyAmount, setBuyAmount]         = useState("0.001");
  const [slippagePct, setSlippagePct]     = useState("5.0");    // display sebagai %
  const [maxBuysPerDay, setMaxBuysPerDay] = useState("5");
  const [minLiquidity, setMinLiquidity]   = useState("1000");
  const [maxTokenAge, setMaxTokenAge]     = useState(15);       // menit: 5 | 15 | 30 | 60

  const loadSettings = useCallback(async () => {
    try {
      const res = await apiFetch(`/api/clanker/settings?fid=${fid}`);
      const data = await res.json();
      if (data && !data.error) {
        setSettings(data);
        setBuyAmount(data.buyAmountEth ?? "0.001");
        setSlippagePct(bpsToPercent(data.slippageBps ?? 500));
        setMaxBuysPerDay(String(data.maxBuysPerDay ?? 5));
        setMinLiquidity(String(data.minLiquidityUsd ?? 1000));
        setMaxTokenAge(data.maxTokenAgeMin ?? 15);
      } else {
        setSettings({
          isEnabled: false,
          buyAmountEth: "0.001",
          slippageBps: 500,
          maxBuysPerDay: 5,
          minLiquidityUsd: 1000,
          maxTokenAgeMin: 15,
        });
      }
    } catch { /* silent */ }
    finally { setLoading(false); }
  }, [fid]);

  const loadHistory = useCallback(async () => {
    try {
      const res = await apiFetch(`/api/clanker/history?fid=${fid}`);
      const data = await res.json();
      setHistory(data.history ?? []);
    } catch { /* silent */ }
  }, [fid]);

  useEffect(() => {
    loadSettings();
    loadHistory();
  }, [loadSettings, loadHistory]);

  const handleToggle = async () => {
    if (!settings) return;
    setToggling(true);
    try {
      await apiFetch("/api/clanker/settings", {
        method: "POST",
        body: JSON.stringify({ fid, isEnabled: !settings.isEnabled }),
      });
      await loadSettings();
    } catch { /* silent */ }
    finally { setToggling(false); }
  };

  const handleSave = async () => {
    setSaveError(""); setSaveOk(false);
    const buyAmt = parseFloat(buyAmount);
    const bps = percentToBps(slippagePct);
    const maxBuys = parseInt(maxBuysPerDay);
    const minLiq = parseInt(minLiquidity);

    if (isNaN(buyAmt) || buyAmt <= 0 || buyAmt > 1) {
      setSaveError("Buy amount harus 0–1 ETH"); return;
    }
    if (isNaN(bps) || bps < 10 || bps > 5000) {
      setSaveError("Slippage harus antara 0.1% – 50%"); return;
    }
    if (isNaN(maxBuys) || maxBuys < 1 || maxBuys > 50) {
      setSaveError("Max buy/hari harus 1–50"); return;
    }
    if (isNaN(minLiq) || minLiq < 0 || minLiq > 1_000_000) {
      setSaveError("Min liquidity harus $0–$1,000,000"); return;
    }

    setSaving(true);
    try {
      const res = await apiFetch("/api/clanker/settings", {
        method: "POST",
        body: JSON.stringify({
          fid,
          buyAmountEth: buyAmount,
          slippageBps: bps,
          maxBuysPerDay: maxBuys,
          minLiquidityUsd: minLiq,
          maxTokenAgeMin: maxTokenAge,
        }),
      });
      const data = await res.json();
      if (!res.ok || data.error) { setSaveError(data.error ?? "Gagal menyimpan"); return; }
      setSaveOk(true);
      await loadSettings();
      setTimeout(() => setSaveOk(false), 2500);
    } catch { setSaveError("Koneksi gagal"); }
    finally { setSaving(false); }
  };

  const handleTestPoll = async () => {
    setPollRunning(true);
    setPollResult(null);
    try {
      const res = await apiFetch("/api/clanker/test-poll");
      const data = await res.json();
      if (!data.ok) {
        setPollResult(`❌ ${data.message}`);
      } else {
        const sniperInfo = data.perSniper?.[0];
        if (!sniperInfo) {
          setPollResult(`✅ ${data.tokensFetched} token diambil · Tidak ada sniper aktif`);
        } else {
          const sample = (sniperInfo.liquiditySample ?? [])
            .map((s: { symbol: string; ageMin: number; volumeH1: number; wouldPass: boolean; reason: string }) =>
              `${s.symbol} ${s.ageMin}m $${s.volumeH1} ${s.wouldPass ? "✅" : "❌ " + s.reason}`
            ).join(" | ");
          setPollResult(
            `✅ ${data.tokensFetched} token · Window ${sniperInfo.maxTokenAgeMin}m: ${sniperInfo.recentTokensInWindow} token · Belum di-snipe: ${sniperInfo.notYetSniped}` +
            (sample ? ` · Sample: ${sample}` : "")
          );
        }
      }
    } catch {
      setPollResult("❌ Koneksi gagal");
    } finally {
      setPollRunning(false);
    }
  };

  const handleTestSnipe = async () => {
    const addr = testAddr.trim();
    if (!addr || !/^0x[0-9a-fA-F]{40}$/.test(addr)) {
      setTestLogs(["❌ Address tidak valid — harus format 0x..."]);
      return;
    }
    setTestRunning(true);
    setTestLogs(["🔄 Menjalankan test snipe..."]);
    setTestResult(null);
    try {
      const res = await apiFetch("/api/clanker/test-snipe", {
        method: "POST",
        body: JSON.stringify({ fid, tokenAddress: addr }),
      });
      const data = await res.json();
      setTestLogs(data.logs ?? []);
      if (data.success) {
        setTestResult({ success: true, txHash: data.txHash });
      } else if (data.skipped) {
        setTestResult({ success: false, error: data.reason });
      } else {
        setTestResult({ success: false, error: data.error ?? "Gagal" });
      }
    } catch {
      setTestLogs(["❌ Koneksi gagal"]);
      setTestResult({ success: false, error: "Koneksi gagal" });
    } finally {
      setTestRunning(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col h-full items-center justify-center gap-3">
        <div className="text-3xl animate-pulse">🔫</div>
        <p className="text-white/60 text-sm font-bold">Memuat...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Sub-tab nav */}
      <div className="flex glass-header">
        {(["settings", "history"] as const).map((t) => (
          <button key={t} onClick={() => setView(t)}
            className={`flex-1 py-3 text-xs font-black transition-all relative ${view === t ? "text-white" : "text-white/50 hover:text-white/75"}`}>
            {t === "settings" ? "⚙️ Pengaturan" : "📋 Riwayat Snipe"}
            {view === t && (
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 w-16 rounded-full bg-[#0052FF] shadow-[0_0_6px_rgba(0,82,255,0.8)]" />
            )}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">

        {/* ═══ SETTINGS VIEW ═══ */}
        {view === "settings" && (
          <>
            {/* ON/OFF toggle card */}
            <div className={`glass rounded-2xl p-4 border transition-all ${
              settings?.isEnabled ? "border-[#00ff87]/30 bg-[#00ff87]/5" : "border-white/10"
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-black text-white text-sm">Clanker Auto-Sniper</p>
                  <p className="text-[11px] text-white/55 mt-0.5">
                    {settings?.isEnabled ? "🟢 Aktif — scan token baru setiap menit" : "⭕ Nonaktif"}
                  </p>
                </div>
                <button
                  onClick={handleToggle}
                  disabled={toggling}
                  className={`relative h-7 w-14 rounded-full transition-all disabled:opacity-50 ${
                    settings?.isEnabled ? "bg-[#00ff87]" : "bg-white/15"
                  }`}
                >
                  <div className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow-md transition-transform ${
                    settings?.isEnabled ? "translate-x-8" : "translate-x-1"
                  }`} />
                </button>
              </div>

              {settings?.isEnabled && (
                <div className="mt-3 rounded-xl bg-[#0052FF]/10 border border-[#0052FF]/20 px-3 py-2.5">
                  <p className="text-[11px] text-[#6b9fff] font-bold leading-relaxed">
                    🔫 Cron tiap menit · Token &lt;{settings.maxTokenAgeMin ?? 15}m · Maks {settings.maxBuysPerDay} token/hari
                  </p>
                </div>
              )}
            </div>

            {/* ── Nominal Buy ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-2 block">Nominal Buy per Snipe (ETH)</label>
              <div className="flex gap-1.5 mb-2">
                {["0.0001","0.001","0.005","0.01"].map((v) => (
                  <button key={v} onClick={() => setBuyAmount(v)}
                    className={`flex-1 rounded-lg py-2 text-[11px] font-black transition-all ${
                      buyAmount === v
                        ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.4)]"
                        : "border border-[#0052FF]/20 bg-[#0052FF]/5 text-white/70"
                    }`}>{v}</button>
                ))}
              </div>
              <input
                type="number" value={buyAmount} onChange={e => setBuyAmount(e.target.value)}
                className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#0052FF]/60"
                step="0.0001" min="0.0001" max="1"
              />
            </div>

            {/* ── Slippage ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-1 block">Slippage</label>
              <p className="text-[10px] text-white/50 mb-2">Toleransi harga — lebih tinggi = lebih mudah dieksekusi</p>
              <div className="flex gap-1.5 mb-2">
                {[["1","1%"],["3","3%"],["5","5%"],["10","10%"]].map(([v, label]) => (
                  <button key={v} onClick={() => setSlippagePct(v)}
                    className={`flex-1 rounded-lg py-2 text-[11px] font-black transition-all ${
                      slippagePct === v
                        ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.4)]"
                        : "border border-[#0052FF]/20 bg-[#0052FF]/5 text-white/70"
                    }`}>{label}</button>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number" value={slippagePct} onChange={e => setSlippagePct(e.target.value)}
                  className="flex-1 rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#0052FF]/60"
                  step="0.1" min="0.1" max="50"
                />
                <span className="text-white/50 text-xs font-bold shrink-0">%</span>
              </div>
            </div>

            {/* ── Max Buy per Hari ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-1 block">Max Buy Token / Hari</label>
              <p className="text-[10px] text-white/50 mb-2">Batas snipe per hari (max 50). Reset tiap tengah malam UTC</p>
              <div className="flex gap-1.5 mb-2">
                {["3","5","10","20"].map((v) => (
                  <button key={v} onClick={() => setMaxBuysPerDay(v)}
                    className={`flex-1 rounded-lg py-2 text-[11px] font-black transition-all ${
                      maxBuysPerDay === v
                        ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.4)]"
                        : "border border-[#0052FF]/20 bg-[#0052FF]/5 text-white/70"
                    }`}>{v}</button>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number" value={maxBuysPerDay} onChange={e => setMaxBuysPerDay(e.target.value)}
                  className="flex-1 rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#0052FF]/60"
                  min="1" max="50" step="1"
                />
                <span className="text-white/50 text-xs font-bold shrink-0">token/hari</span>
              </div>
            </div>

            {/* ── Min Liquidity ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-1 block">Min Volume 1 Jam (USD)</label>
              <p className="text-[10px] text-white/50 mb-2">
                Snipe hanya jika volume trading 1 jam ≥ angka ini. "Semua" = snipe semua tanpa filter volume.
              </p>
              <p className="text-[10px] text-yellow-400/60 mb-2">
                ⚡ Volume lebih akurat dari liquidity — muncul lebih cepat dan tidak bisa dipalsukan protocol.
              </p>
              <div className="flex gap-1.5 mb-2">
                {[["0","Semua"],["100","$100"],["500","$500"],["1000","$1K"]].map(([v, label]) => (
                  <button key={v} onClick={() => setMinLiquidity(v)}
                    className={`flex-1 rounded-lg py-2 text-[11px] font-black transition-all ${
                      minLiquidity === v
                        ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.4)]"
                        : "border border-[#0052FF]/20 bg-[#0052FF]/5 text-white/60"
                    }`}>{label}</button>
                ))}
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40 text-sm font-bold">$</span>
                <input
                  type="number" value={minLiquidity} onChange={e => setMinLiquidity(e.target.value)}
                  className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 pl-7 pr-3 py-2 text-sm text-white focus:outline-none focus:border-[#0052FF]/60"
                  min="0" max="1000000" step="100"
                />
              </div>
            </div>

            {/* ── Usia Token Maksimal ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-1 block">Usia Token Maksimal</label>
              <p className="text-[10px] text-white/50 mb-2">
                Hanya snipe token yang baru deploy dalam rentang waktu ini — makin pendek makin fresh.
              </p>
              <div className="flex gap-1.5">
                {([5, 15, 30, 60] as const).map((min) => (
                  <button key={min} onClick={() => setMaxTokenAge(min)}
                    className={`flex-1 rounded-lg py-2.5 text-[11px] font-black transition-all ${
                      maxTokenAge === min
                        ? "bg-[#0052FF] text-white shadow-[0_0_10px_rgba(0,82,255,0.4)]"
                        : "border border-[#0052FF]/20 bg-[#0052FF]/5 text-white/60"
                    }`}>
                    {min === 60 ? "1j" : `${min}m`}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-white/30 mt-2 text-center">
                {maxTokenAge === 5  && "Sangat agresif — hanya token < 5 menit"}
                {maxTokenAge === 15 && "Agresif — token < 15 menit (rekomendasi)"}
                {maxTokenAge === 30 && "Sedang — token < 30 menit"}
                {maxTokenAge === 60 && "Santai — token < 1 jam"}
              </p>
            </div>

            {saveError && (
              <p className="text-xs text-[#ff3b5c] bg-[#ff3b5c]/10 rounded-xl px-3 py-2 font-bold">{saveError}</p>
            )}
            {saveOk && (
              <p className="text-xs text-[#00ff87] bg-[#00ff87]/10 rounded-xl px-3 py-2 font-bold">✅ Pengaturan tersimpan</p>
            )}

            <button
              onClick={handleSave} disabled={saving}
              className="w-full rounded-xl bg-[#0052FF] py-3.5 text-sm font-black text-white shadow-[0_0_20px_rgba(0,82,255,0.4)] hover:bg-[#0047e0] disabled:opacity-50 transition-all"
            >
              {saving ? "Menyimpan..." : "💾 Simpan Pengaturan"}
            </button>

            {/* ── Test Poll Manual ── */}
            <div className="glass rounded-2xl p-4">
              <p className="text-[10px] font-black text-white/70 uppercase tracking-wider mb-1">Test Poll Manual</p>
              <p className="text-[10px] text-white/50 mb-1 leading-relaxed">
                Simulasi cron scan — ambil token dari Clanker, cek filter usia &amp; liquidity. Tidak ada buy.
              </p>
              <p className="text-[10px] text-yellow-400/70 mb-3 leading-relaxed">
                ⚠ Pakai filter yang sudah <span className="font-black">tersimpan di DB</span> — klik &quot;Simpan Pengaturan&quot; dulu kalau baru ubah filter.
              </p>
              <button
                onClick={handleTestPoll}
                disabled={pollRunning}
                className="w-full rounded-xl border border-[#0052FF]/50 bg-[#0052FF]/20 py-2.5 text-sm font-black text-white hover:bg-[#0052FF]/30 transition-all disabled:opacity-50"
              >
                {pollRunning ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    Scanning Clanker...
                  </span>
                ) : "🔍 Test Poll Manual"}
              </button>
              {pollResult && (
                <p className="mt-2 text-[10px] text-white/80 font-semibold bg-white/10 rounded-lg px-3 py-2 leading-relaxed break-words">{pollResult}</p>
              )}
              <p className="mt-2 text-[10px] text-white/30 leading-relaxed">
                Cron otomatis aktif tiap menit setelah app di-publish.
              </p>
            </div>

            {/* ── Test Buy Manual ── */}
            <div className="glass rounded-2xl p-4">
              <p className="text-[10px] font-black text-white/70 uppercase tracking-wider mb-1">Test Buy Manual</p>
              <p className="text-[10px] text-white/50 mb-3 leading-relaxed">
                Input token address untuk test buy — pakai settings aktif kamu. Anti-duplikat tetap berlaku.
              </p>
              <input
                type="text"
                value={testAddr}
                onChange={e => setTestAddr(e.target.value)}
                placeholder="0x... (contract address token)"
                className="w-full rounded-lg border border-[#0052FF]/25 bg-[#0052FF]/10 px-3 py-2 text-xs text-white font-mono placeholder-white/25 focus:outline-none focus:border-[#0052FF]/60 mb-3"
              />
              <button
                onClick={handleTestSnipe}
                disabled={testRunning || !testAddr.trim()}
                className="w-full rounded-xl py-3 text-sm font-black text-white transition-all disabled:opacity-40"
                style={{ background: testRunning ? "rgba(0,82,255,0.4)" : "linear-gradient(135deg,#0052FF,#0047e0)", boxShadow: "0 0 16px rgba(0,82,255,0.35)" }}
              >
                {testRunning ? "⏳ Mengeksekusi..." : "🔫 Test Buy Manual"}
              </button>

              {/* Logs */}
              {testLogs.length > 0 && (
                <div className="mt-3 rounded-xl bg-black/40 border border-white/10 p-3 max-h-40 overflow-y-auto">
                  {testLogs.map((log, i) => (
                    <p key={i} className="text-[10px] font-mono text-white/70 leading-snug">{log}</p>
                  ))}
                </div>
              )}

              {/* Result */}
              {testResult && (
                <div className={`mt-3 rounded-xl px-3 py-2.5 ${testResult.success ? "bg-[#00ff87]/10 border border-[#00ff87]/25" : "bg-[#ff3b5c]/10 border border-[#ff3b5c]/25"}`}>
                  {testResult.success ? (
                    <div>
                      <p className="text-[11px] font-black text-[#00ff87]">✅ Buy berhasil!</p>
                      <a
                        href={`https://basescan.org/tx/${testResult.txHash}`}
                        target="_blank" rel="noopener noreferrer"
                        className="text-[10px] text-[#6b9fff] font-mono underline break-all"
                      >
                        {testResult.txHash}
                      </a>
                    </div>
                  ) : (
                    <p className="text-[11px] font-black text-[#ff3b5c]">❌ {testResult.error}</p>
                  )}
                </div>
              )}
            </div>

            {/* Info cara kerja */}
            <div className="glass rounded-2xl p-4">
              <p className="text-[10px] font-black text-white/70 uppercase tracking-wider mb-2">Cara Kerja</p>
              <div className="flex flex-col gap-2">
                {[
                  ["🔍", "Scan 40 token Clanker terbaru tiap menit via cron"],
                  ["💧", "Filter token fresh sesuai usia & liquidity yang kamu set"],
                  ["⚡", "Beli otomatis via Paraswap → Kyber → LI.FI → Zora SDK"],
                  ["🛡️", "Anti-duplikat: satu token hanya dibeli sekali per akun"],
                  ["📊", "Batas harian reset tiap tengah malam UTC"],
                ].map(([icon, text], i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="text-sm shrink-0">{icon}</span>
                    <p className="text-[10px] text-white/55 leading-snug">{text}</p>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* ═══ HISTORY VIEW ═══ */}
        {view === "history" && (
          <>
            {history.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-4xl mb-3">🔫</div>
                <p className="text-white/75 font-black text-sm">Belum ada snipe</p>
                <p className="text-white/45 text-xs mt-1">Aktifkan Clanker Sniper di tab Pengaturan</p>
              </div>
            ) : (
              <>
                {/* Stats mini */}
                <div className="grid grid-cols-3 gap-2">
                  {[
                    ["Total", history.length],
                    ["Berhasil", history.filter(h => h.status === "success").length],
                    ["Gagal", history.filter(h => h.status === "failed").length],
                  ].map(([label, val]) => (
                    <div key={label} className="glass-cell rounded-xl p-3 text-center">
                      <p className="text-white font-black text-lg leading-none">{val}</p>
                      <p className="text-[10px] text-white/50 mt-0.5 font-bold">{label}</p>
                    </div>
                  ))}
                </div>

                {history.map((log) => {
                  const s = STATUS_MAP[log.status] ?? { label: log.status, cls: "bg-white/5 text-white/50" };
                  return (
                    <div key={log.id} className="glass rounded-xl overflow-hidden">
                      <div className="p-3 flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-white text-sm">
                              {log.tokenSymbol ? `$${log.tokenSymbol}` : log.tokenName ?? `${log.tokenAddress.slice(0, 10)}...`}
                            </span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${s.cls}`}>{s.label}</span>
                          </div>
                          <p className="text-[10px] text-white/40 font-mono mt-0.5 truncate">{log.tokenAddress}</p>
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            <span className="text-[10px] text-white/50">
                              {parseFloat(log.buyAmountEth).toFixed(5)} ETH
                            </span>
                            {log.volumeUsdAtSnipe != null && log.volumeUsdAtSnipe > 0 && (
                              <span className="text-[10px] text-[#6b9fff]">
                                Vol h1: ${log.volumeUsdAtSnipe.toLocaleString()}
                              </span>
                            )}
                            {(log.volumeUsdAtSnipe == null || log.volumeUsdAtSnipe === 0) && (
                              <span className="text-[10px] text-white/30">
                                Vol: -
                              </span>
                            )}
                            <span className="text-[10px] text-white/30">{fmtAge(log.createdAt)}</span>
                          </div>
                          {log.errorMessage && (
                            <p className="text-[10px] text-[#ff3b5c] mt-1 leading-snug">{log.errorMessage.slice(0, 100)}</p>
                          )}
                        </div>
                        {log.txHash && (
                          <a
                            href={`https://basescan.org/tx/${log.txHash}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="shrink-0 text-[10px] font-black text-[#6b9fff] border border-[#0052FF]/25 rounded-lg px-2 py-1 hover:bg-[#0052FF]/15 transition-all"
                          >
                            TX ↗
                          </a>
                        )}
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
