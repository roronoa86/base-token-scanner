"use client";

import { useEffect, useState, useCallback } from "react";
import type { SnipeRecord, SnipeStats } from "@/features/app/types";
import { ShareButton } from "@/neynar-farcaster-sdk/mini";
import { apiFetch } from "@/lib/api-client";

interface HistoryTabProps {
  fid: number;
}

function truncateAddress(addr: string) {
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

function timeAgo(date: Date | string) {
  const d = new Date(date);
  const seconds = Math.floor((Date.now() - d.getTime()) / 1000);
  if (seconds < 60) return `${seconds}s lalu`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m lalu`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}j lalu`;
  return `${Math.floor(hours / 24)}h lalu`;
}

// ─── Per-card token enrichment (logo + name) ─────────────────────────────────

interface TokenMeta {
  imageUrl: string | null;
  name: string | null;
  symbol: string | null;
}

function useTokenMeta(tokenAddress: string, knownName: string | null, knownSymbol: string | null) {
  const [meta, setMeta] = useState<TokenMeta>({
    imageUrl: null,
    name: knownName,
    symbol: knownSymbol,
  });

  useEffect(() => {
    // Only fetch if we're missing the image
    fetch(`/api/trader/lookup?address=${tokenAddress}`)
      .then((r) => r.json())
      .then((d) => {
        if (d && !d.error) {
          setMeta({
            imageUrl: d.imageUrl ?? null,
            name: d.name ?? knownName,
            symbol: d.symbol ?? knownSymbol,
          });
        }
      })
      .catch(() => {});
  // Only run once on mount
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tokenAddress]);

  return meta;
}

// ─── Snipe History Card ───────────────────────────────────────────────────────

function SnipeCard({ snipe }: { snipe: SnipeRecord }) {
  const isSuccess = snipe.status === "success";
  const isFailed = snipe.status === "failed";

  const meta = useTokenMeta(snipe.tokenAddress, snipe.tokenName, snipe.tokenSymbol);

  const displayName = meta.name ?? meta.symbol ?? "Token Baru";
  const zoraUrl = `https://zora.co/coin/base:${snipe.tokenAddress}`;

  return (
    <div className={`glass rounded-xl overflow-hidden border ${
      isSuccess ? "border-[#00ff87]/20" : isFailed ? "border-[#ff3b5c]/20" : "border-yellow-500/20"
    }`}>
      {/* Card header — logo + name + status */}
      <div className="flex items-center gap-3 p-3">
        {/* Token logo */}
        <div className="shrink-0">
          {meta.imageUrl ? (
            <img
              src={meta.imageUrl}
              alt={displayName}
              className="w-10 h-10 rounded-full ring-2 ring-[#0052FF]/25 object-cover"
              onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-[#0052FF]/20 border border-[#0052FF]/30 flex items-center justify-center text-lg">
              🪙
            </div>
          )}
        </div>

        {/* Name + triggered wallet */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-sm font-black text-white leading-tight">
              {displayName}
            </span>
            {meta.symbol && meta.name && meta.symbol !== meta.name && (
              <span className="text-[11px] text-[#6b9fff] font-bold">${meta.symbol}</span>
            )}
          </div>
          <p className="text-[10px] text-white/60 font-medium mt-0.5">
            dari {truncateAddress(snipe.triggeredByWallet)}
          </p>
        </div>

        {/* Status + time */}
        <div className="text-right shrink-0">
          <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full block mb-0.5 ${
            isSuccess ? "bg-[#00ff87]/15 text-[#00ff87]" :
            isFailed  ? "bg-[#ff3b5c]/15 text-[#ff3b5c]" :
                        "bg-yellow-500/15 text-yellow-300"
          }`}>
            {snipe.status}
          </span>
          <p className="text-[10px] text-white/60 font-medium">{timeAgo(snipe.createdAt)}</p>
        </div>
      </div>

      {/* Details row */}
      <div className="px-3 pb-2 flex items-center gap-2 flex-wrap">
        {/* Buy amount */}
        <div className="glass-cell rounded-lg px-2.5 py-1.5 flex items-center gap-1.5">
          <span className="text-[10px] text-white/65 font-semibold">Beli</span>
          <span className="text-[11px] text-white font-black font-mono">{snipe.buyAmountEth} ETH</span>
        </div>

        {/* Token address chip */}
        <div className="glass-cell rounded-lg px-2.5 py-1.5">
          <span className="text-[10px] text-white/60 font-mono font-semibold">
            {truncateAddress(snipe.tokenAddress)}
          </span>
        </div>
      </div>

      {/* Error message */}
      {snipe.errorMessage && (
        <div className="mx-3 mb-2 rounded-lg bg-[#ff3b5c]/10 border border-[#ff3b5c]/20 px-2.5 py-1.5">
          <p className="text-[10px] text-[#ff3b5c] font-semibold break-all leading-relaxed">
            ❌ {snipe.errorMessage}
          </p>
        </div>
      )}

      {/* Action links */}
      <div className="px-3 pb-3 flex items-center gap-2">
        {/* Zora link — always show */}
        <a
          href={zoraUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 rounded-lg bg-[#0052FF]/15 border border-[#0052FF]/30 px-3 py-1.5 text-[11px] font-black text-white hover:bg-[#0052FF]/25 transition-all"
        >
          <span>⚡</span>
          <span>Lihat di Zora</span>
        </a>

        {/* Basescan TX link */}
        {snipe.txHash && (
          <a
            href={`https://basescan.org/tx/${snipe.txHash}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 rounded-lg border border-white/15 px-3 py-1.5 text-[11px] font-bold text-white/80 hover:text-white hover:border-white/30 transition-all"
          >
            <span>TX ↗</span>
          </a>
        )}
      </div>
    </div>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────

export function HistoryTab({ fid }: HistoryTabProps) {
  const [history, setHistory] = useState<SnipeRecord[]>([]);
  const [stats, setStats] = useState<SnipeStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    apiFetch(`/api/sniper/history?fid=${fid}`)
      .then((r) => r.json())
      .then((d) => { setHistory(d.history ?? []); setStats(d.stats ?? null); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [fid]);

  return (
    <div className="flex flex-col gap-4 p-4">
      <p className="text-[11px] text-[#6b9fff] uppercase tracking-widest font-black">Riwayat Snipe</p>

      {/* Stats row */}
      {stats && (
        <div className="flex gap-2">
          <div className="flex-1 glass rounded-xl p-3 text-center">
            <p className="text-xl font-black text-white">{stats.total}</p>
            <p className="text-[11px] text-white font-bold uppercase tracking-wide mt-0.5">Total</p>
          </div>
          <div className="flex-1 glass rounded-xl p-3 text-center border border-[#00ff87]/20">
            <p className="text-xl font-black text-[#00ff87]">{stats.success}</p>
            <p className="text-[11px] text-white font-bold uppercase tracking-wide mt-0.5">Berhasil</p>
          </div>
          <div className="flex-1 glass rounded-xl p-3 text-center border border-[#ff3b5c]/20">
            <p className="text-xl font-black text-[#ff3b5c]">{stats.failed}</p>
            <p className="text-[11px] text-white font-bold uppercase tracking-wide mt-0.5">Gagal</p>
          </div>
        </div>
      )}

      {/* List */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-[#0052FF] border-t-transparent" />
        </div>
      ) : history.length === 0 ? (
        <div className="glass rounded-2xl p-10 text-center border border-dashed border-[#0052FF]/20">
          <p className="text-3xl mb-3">🎯</p>
          <p className="text-sm text-white font-black">Belum ada snipe</p>
          <p className="text-xs text-white/75 font-semibold mt-1">Aktifkan sniper dan tunggu target deploy token</p>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {history.map((snipe) => (
            <SnipeCard key={snipe.id} snipe={snipe} />
          ))}
        </div>
      )}

      <div className="flex justify-center pt-2 pb-1">
        <ShareButton text="Snipe Zora Coins before anyone else 🎯 via Zora Sniper">
          Share Zora Sniper
        </ShareButton>
      </div>
    </div>
  );
}
