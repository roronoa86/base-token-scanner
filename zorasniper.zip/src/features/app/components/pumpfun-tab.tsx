"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { apiFetch } from "@/lib/api-client";

interface PumpfunSettings {
  isEnabled: boolean;
  buyAmountSol: string;
  slippageBps: number;
  maxBuysPerDay: number;
  minVolumeUsd: number;
  maxTokenAgeMin: number;
  solanaWalletAddress: string | null;
}

interface SnipeLog {
  id: string;
  mintAddress: string;
  tokenName: string | null;
  tokenSymbol: string | null;
  volumeUsdAtSnipe: number | null;
  buyAmountSol: string;
  txSignature: string | null;
  status: string;
  errorMessage: string | null;
  createdAt: string;
}

function fmtAge(isoStr: string): string {
  const diffMs = Date.now() - new Date(isoStr).getTime();
  const m = Math.floor(diffMs / 60_000);
  const h = Math.floor(diffMs / 3_600_000);
  const d = Math.floor(diffMs / 86_400_000);
  if (m < 60) return `${m}m lalu`;
  if (h < 24) return `${h}j lalu`;
  return `${d}h lalu`;
}

const STATUS_MAP: Record<string, { label: string; cls: string }> = {
  pending: { label: "Pending",   cls: "bg-yellow-500/10 text-yellow-400" },
  success: { label: "Berhasil",  cls: "bg-[#00ff87]/10 text-[#00ff87]" },
  failed:  { label: "Gagal",     cls: "bg-[#ff3b5c]/10 text-[#ff3b5c]" },
  skipped: { label: "Antrian",   cls: "bg-[#9945FF]/10 text-[#c084fc]" },
};

function bpsToPercent(bps: number): string {
  return (bps / 100).toFixed(1);
}
function percentToBps(pct: string): number {
  return Math.round(parseFloat(pct) * 100);
}

export function PumpfunTab({ fid }: { fid: number }) {
  const [settings, setSettings]   = useState<PumpfunSettings | null>(null);
  const [history, setHistory]     = useState<SnipeLog[]>([]);
  const [loading, setLoading]     = useState(true);
  const [saving, setSaving]       = useState(false);
  const [toggling, setToggling]   = useState(false);
  const [saveError, setSaveError] = useState("");
  const [saveOk, setSaveOk]       = useState(false);
  const [view, setView]           = useState<"settings" | "history">("settings");

  // Test poll
  const [pollRunning, setPollRunning] = useState(false);
  const [pollResult, setPollResult]   = useState<string | null>(null);

  // Wallet Solana
  const [walletKey, setWalletKey]         = useState("");
  const [showKey, setShowKey]             = useState(false);
  const [walletSaving, setWalletSaving]   = useState(false);
  const [walletError, setWalletError]     = useState("");
  const [walletOk, setWalletOk]           = useState(false);
  const [walletDeleting, setWalletDeleting] = useState(false);
  const walletInputRef = useRef<HTMLInputElement>(null);
  const [clearingHistory, setClearingHistory] = useState(false);

  // Form state
  const [buyAmount, setBuyAmount]         = useState("0.01");
  const [slippagePct, setSlippagePct]     = useState("10.0");
  const [maxBuysPerDay, setMaxBuysPerDay] = useState("5");
  const [minVolume, setMinVolume]         = useState("1000");
  const [maxTokenAge, setMaxTokenAge]     = useState(15);

  const loadSettings = useCallback(async () => {
    try {
      const res = await apiFetch(`/api/pumpfun/settings?fid=${fid}`);
      const data = await res.json();
      if (data && !data.error) {
        setSettings(data);
        setBuyAmount(data.buyAmountSol ?? "0.01");
        setSlippagePct(bpsToPercent(data.slippageBps ?? 1000));
        setMaxBuysPerDay(String(data.maxBuysPerDay ?? 5));
        setMinVolume(String(data.minVolumeUsd ?? 1000));
        setMaxTokenAge(data.maxTokenAgeMin ?? 15);
      } else {
        setSettings({
          isEnabled: false,
          buyAmountSol: "0.01",
          slippageBps: 1000,
          maxBuysPerDay: 5,
          minVolumeUsd: 1000,
          maxTokenAgeMin: 15,
          solanaWalletAddress: null,
        });
      }
    } catch { /* silent */ }
    finally { setLoading(false); }
  }, [fid]);

  const loadHistory = useCallback(async () => {
    try {
      const res = await apiFetch(`/api/pumpfun/history?fid=${fid}`);
      const data = await res.json();
      setHistory(data.history ?? []);
    } catch { /* silent */ }
  }, [fid]);

  useEffect(() => {
    loadSettings();
    loadHistory();
  }, [loadSettings, loadHistory]);

  const handleToggle = async () => {
    if (!settings) return;
    setToggling(true);
    try {
      await apiFetch("/api/pumpfun/settings", {
        method: "POST",
        body: JSON.stringify({ fid, isEnabled: !settings.isEnabled }),
      });
      await loadSettings();
    } catch { /* silent */ }
    finally { setToggling(false); }
  };

  const handleSave = async () => {
    setSaveError(""); setSaveOk(false);
    const buyAmt = parseFloat(buyAmount);
    const bps = percentToBps(slippagePct);
    const maxBuys = parseInt(maxBuysPerDay);
    const minVol = parseInt(minVolume);

    if (isNaN(buyAmt) || buyAmt <= 0 || buyAmt > 10) {
      setSaveError("Buy amount harus 0–10 SOL"); return;
    }
    if (isNaN(bps) || bps < 10 || bps > 5000) {
      setSaveError("Slippage harus antara 0.1% – 50%"); return;
    }
    if (isNaN(maxBuys) || maxBuys < 1 || maxBuys > 50) {
      setSaveError("Max buy/hari harus 1–50"); return;
    }
    if (isNaN(minVol) || minVol < 0 || minVol > 10_000_000) {
      setSaveError("Min volume harus $0–$10,000,000"); return;
    }

    setSaving(true);
    try {
      const res = await apiFetch("/api/pumpfun/settings", {
        method: "POST",
        body: JSON.stringify({
          fid,
          buyAmountSol: buyAmount,
          slippageBps: bps,
          maxBuysPerDay: maxBuys,
          minVolumeUsd: minVol,
          maxTokenAgeMin: maxTokenAge,
        }),
      });
      const data = await res.json();
      if (!res.ok || data.error) { setSaveError(data.error ?? "Gagal menyimpan"); return; }
      setSaveOk(true);
      await loadSettings();
      setTimeout(() => setSaveOk(false), 2500);
    } catch { setSaveError("Koneksi gagal"); }
    finally { setSaving(false); }
  };

  const handleSaveWallet = async () => {
    setWalletError(""); setWalletOk(false);
    const key = walletKey.trim();
    if (!key || key.length < 32) {
      setWalletError("Private key terlalu pendek — minimal 32 karakter"); return;
    }
    setWalletSaving(true);
    try {
      const res = await apiFetch("/api/pumpfun/wallet", {
        method: "POST",
        body: JSON.stringify({ fid, privateKey: key }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setWalletError(data.error ?? "Gagal menyimpan wallet"); return;
      }
      setWalletOk(true);
      setWalletKey("");
      setShowKey(false);
      await loadSettings();
      setTimeout(() => setWalletOk(false), 3000);
    } catch { setWalletError("Koneksi gagal"); }
    finally { setWalletSaving(false); }
  };

  const handleClearHistory = async () => {
    if (!confirm("Hapus semua riwayat snipe? Tidak bisa di-undo.")) return;
    setClearingHistory(true);
    try {
      const res = await apiFetch(`/api/pumpfun/history?fid=${fid}`, { method: "DELETE" });
      if (res.ok) { setHistory([]); }
    } catch { /* silent */ }
    finally { setClearingHistory(false); }
  };

  const handleDeleteWallet = async () => {
    if (!confirm("Hapus Solana private key? Buy otomatis akan nonaktif.")) return;
    setWalletDeleting(true);
    try {
      const res = await apiFetch(`/api/pumpfun/wallet?fid=${fid}`, { method: "DELETE" });
      if (res.ok) { await loadSettings(); }
    } catch { /* silent */ }
    finally { setWalletDeleting(false); }
  };

  const handleTestPoll = async () => {
    setPollRunning(true);
    setPollResult(null);
    try {
      const res = await apiFetch("/api/pumpfun/test-poll");
      const data = await res.json();
      if (!data.ok) {
        setPollResult(`❌ ${data.message}`);
      } else {
        const sniperInfo = data.perSniper?.[0];
        if (!sniperInfo) {
          setPollResult(`✅ ${data.tokensFetched} token diambil · Tidak ada sniper aktif`);
        } else {
          const sample = (sniperInfo.volumeSample ?? [])
            .map((s: { symbol: string; ageMin: number; volumeH1: number; wouldPass: boolean; reason: string }) =>
              `${s.symbol} ${s.ageMin}m $${s.volumeH1} ${s.wouldPass ? "✅" : "❌ " + s.reason}`
            ).join(" | ");
          setPollResult(
            `✅ ${data.tokensFetched} token · Window ${sniperInfo.maxTokenAgeMin}m: ${sniperInfo.recentTokensInWindow} token · Belum: ${sniperInfo.notYetSniped}` +
            (sample ? ` · ${sample}` : "")
          );
        }
      }
    } catch {
      setPollResult("❌ Koneksi gagal");
    } finally {
      setPollRunning(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col h-full items-center justify-center gap-3">
        <div className="text-3xl animate-pulse">🚀</div>
        <p className="text-white/60 text-sm font-bold">Memuat...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Sub-tab nav */}
      <div className="flex glass-header">
        {(["settings", "history"] as const).map((t) => (
          <button key={t} onClick={() => setView(t)}
            className={`flex-1 py-3 text-xs font-black transition-all relative ${view === t ? "text-white" : "text-white/50 hover:text-white/75"}`}>
            {t === "settings" ? "⚙️ Pengaturan" : "📋 Riwayat Snipe"}
            {view === t && (
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 w-16 rounded-full bg-[#9945FF] shadow-[0_0_6px_rgba(153,69,255,0.8)]" />
            )}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">

        {/* ═══ SETTINGS VIEW ═══ */}
        {view === "settings" && (
          <>
            {/* ── Wallet Solana ── */}
            <div className={`glass rounded-2xl p-4 border transition-all ${
              settings?.solanaWalletAddress
                ? "border-[#9945FF]/30 bg-[#9945FF]/5"
                : "border-yellow-500/30 bg-yellow-500/5"
            }`}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-xs font-black text-white">Wallet Solana</p>
                  <p className="text-[10px] text-white/50 mt-0.5">Dibutuhkan untuk buy otomatis</p>
                </div>
                {settings?.solanaWalletAddress && (
                  <span className="text-[10px] font-black text-[#00ff87] bg-[#00ff87]/10 px-2 py-1 rounded-full">✅ Aktif</span>
                )}
              </div>

              {settings?.solanaWalletAddress ? (
                /* Wallet sudah di-setup — tampilkan address */
                <div className="flex flex-col gap-2">
                  <div className="rounded-xl bg-[#9945FF]/10 border border-[#9945FF]/20 px-3 py-2.5">
                    <p className="text-[10px] text-white/40 font-bold mb-0.5">Alamat Wallet</p>
                    <p className="text-[11px] font-mono text-[#c084fc] break-all leading-relaxed">
                      {settings.solanaWalletAddress}
                    </p>
                    <a
                      href={`https://solscan.io/account/${settings.solanaWalletAddress}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] text-[#9945FF] font-bold mt-1 inline-block hover:underline"
                    >
                      Lihat di Solscan ↗
                    </a>
                  </div>
                  <button
                    onClick={handleDeleteWallet}
                    disabled={walletDeleting}
                    className="text-[10px] font-black text-[#ff3b5c]/70 hover:text-[#ff3b5c] transition-all disabled:opacity-50 py-1"
                  >
                    {walletDeleting ? "Menghapus..." : "🗑️ Hapus wallet key"}
                  </button>
                </div>
              ) : (
                /* Form input private key */
                <div className="flex flex-col gap-2">
                  <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/20 px-3 py-2 mb-1">
                    <p className="text-[10px] text-yellow-300 font-bold leading-relaxed">
                      ⚠️ Scan & filter tetap aktif, tapi buy otomatis membutuhkan Solana private key.
                      Key dienkripsi AES-256 sebelum disimpan.
                    </p>
                  </div>
                  <label className="text-[10px] font-black text-white/70">Private Key (base58)</label>
                  <div className="relative">
                    <input
                      ref={walletInputRef}
                      type={showKey ? "text" : "password"}
                      value={walletKey}
                      onChange={e => { setWalletKey(e.target.value); setWalletError(""); }}
                      placeholder="Paste Solana private key (base58)..."
                      className="w-full rounded-lg border border-[#9945FF]/25 bg-[#9945FF]/10 px-3 py-2.5 pr-10 text-[11px] text-white placeholder:text-white/30 focus:outline-none focus:border-[#9945FF]/60 font-mono"
                      autoComplete="off"
                      autoCorrect="off"
                      spellCheck={false}
                    />
                    <button
                      type="button"
                      onClick={() => setShowKey(v => !v)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-all text-xs"
                      tabIndex={-1}
                    >
                      {showKey ? "🙈" : "👁️"}
                    </button>
                  </div>
                  <p className="text-[10px] text-white/35 leading-relaxed">
                    Export dari Phantom: Settings → Security & Privacy → Export Private Key.
                    Atau gunakan wallet baru khusus untuk sniper ini.
                  </p>
                  {walletError && (
                    <p className="text-[10px] text-[#ff3b5c] bg-[#ff3b5c]/10 rounded-lg px-2.5 py-1.5 font-bold">{walletError}</p>
                  )}
                  {walletOk && (
                    <p className="text-[10px] text-[#00ff87] bg-[#00ff87]/10 rounded-lg px-2.5 py-1.5 font-bold">✅ Wallet berhasil disimpan!</p>
                  )}
                  <button
                    onClick={handleSaveWallet}
                    disabled={walletSaving || !walletKey.trim()}
                    className="w-full rounded-xl py-2.5 text-xs font-black text-white disabled:opacity-40 transition-all"
                    style={{ background: "linear-gradient(135deg,#9945FF,#7c3aed)", boxShadow: "0 0 14px rgba(153,69,255,0.3)" }}
                  >
                    {walletSaving ? "Menyimpan & verifikasi..." : "🔑 Simpan Private Key"}
                  </button>
                </div>
              )}
            </div>

            {/* ON/OFF toggle */}
            <div className={`glass rounded-2xl p-4 border transition-all ${
              settings?.isEnabled ? "border-[#9945FF]/30 bg-[#9945FF]/5" : "border-white/10"
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-black text-white text-sm">Pump.fun Auto-Sniper</p>
                  <p className="text-[11px] text-white/55 mt-0.5">
                    {settings?.isEnabled ? "🟢 Aktif — scan token baru setiap menit" : "⭕ Nonaktif"}
                  </p>
                </div>
                <button
                  onClick={handleToggle}
                  disabled={toggling}
                  className={`relative h-7 w-14 rounded-full transition-all disabled:opacity-50 ${
                    settings?.isEnabled ? "bg-[#9945FF]" : "bg-white/15"
                  }`}
                >
                  <div className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow-md transition-transform ${
                    settings?.isEnabled ? "translate-x-8" : "translate-x-1"
                  }`} />
                </button>
              </div>
              {settings?.isEnabled && (
                <div className="mt-3 rounded-xl bg-[#9945FF]/10 border border-[#9945FF]/20 px-3 py-2.5">
                  <p className="text-[11px] text-[#c084fc] font-bold leading-relaxed">
                    🚀 Scan tiap menit · Token &lt;{settings.maxTokenAgeMin ?? 15}m · Maks {settings.maxBuysPerDay} token/hari
                  </p>
                  {!settings.solanaWalletAddress && (
                    <p className="text-[10px] text-yellow-400 font-bold mt-1">
                      ⚠️ Buy otomatis nonaktif — tambahkan wallet Solana di atas
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* ── Nominal Buy ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-2 block">Nominal Buy per Snipe (SOL)</label>
              <div className="flex gap-1.5 mb-2">
                {["0.001","0.01","0.05","0.1"].map((v) => (
                  <button key={v} onClick={() => setBuyAmount(v)}
                    className={`flex-1 rounded-lg py-2 text-[11px] font-black transition-all ${
                      buyAmount === v
                        ? "bg-[#9945FF] text-white shadow-[0_0_10px_rgba(153,69,255,0.4)]"
                        : "border border-[#9945FF]/20 bg-[#9945FF]/5 text-white/70"
                    }`}>{v}</button>
                ))}
              </div>
              <input
                type="number" value={buyAmount} onChange={e => setBuyAmount(e.target.value)}
                className="w-full rounded-lg border border-[#9945FF]/25 bg-[#9945FF]/10 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#9945FF]/60"
                step="0.001" min="0.001" max="10"
              />
            </div>

            {/* ── Slippage ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-1 block">Slippage</label>
              <p className="text-[10px] text-white/50 mb-2">Solana membutuhkan slippage lebih tinggi dari EVM</p>
              <div className="flex gap-1.5 mb-2">
                {[["5","5%"],["10","10%"],["15","15%"],["20","20%"]].map(([v, label]) => (
                  <button key={v} onClick={() => setSlippagePct(v)}
                    className={`flex-1 rounded-lg py-2 text-[11px] font-black transition-all ${
                      slippagePct === v
                        ? "bg-[#9945FF] text-white shadow-[0_0_10px_rgba(153,69,255,0.4)]"
                        : "border border-[#9945FF]/20 bg-[#9945FF]/5 text-white/70"
                    }`}>{label}</button>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number" value={slippagePct} onChange={e => setSlippagePct(e.target.value)}
                  className="flex-1 rounded-lg border border-[#9945FF]/25 bg-[#9945FF]/10 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#9945FF]/60"
                  step="0.1" min="0.1" max="50"
                />
                <span className="text-white/50 text-xs font-bold shrink-0">%</span>
              </div>
            </div>

            {/* ── Max Buy per Hari ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-1 block">Max Buy Token / Hari</label>
              <p className="text-[10px] text-white/50 mb-2">Reset tiap tengah malam UTC</p>
              <div className="flex gap-1.5 mb-2">
                {["3","5","10","20"].map((v) => (
                  <button key={v} onClick={() => setMaxBuysPerDay(v)}
                    className={`flex-1 rounded-lg py-2 text-[11px] font-black transition-all ${
                      maxBuysPerDay === v
                        ? "bg-[#9945FF] text-white shadow-[0_0_10px_rgba(153,69,255,0.4)]"
                        : "border border-[#9945FF]/20 bg-[#9945FF]/5 text-white/70"
                    }`}>{v}</button>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number" value={maxBuysPerDay} onChange={e => setMaxBuysPerDay(e.target.value)}
                  className="flex-1 rounded-lg border border-[#9945FF]/25 bg-[#9945FF]/10 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#9945FF]/60"
                  min="1" max="50" step="1"
                />
                <span className="text-white/50 text-xs font-bold shrink-0">token/hari</span>
              </div>
            </div>

            {/* ── Min Market Cap ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-1 block">Min Market Cap (USD)</label>
              <p className="text-[10px] text-white/50 mb-2">
                Snipe hanya jika market cap token ≥ angka ini. <span className="text-white/70 font-bold">Semua = tanpa filter.</span>
              </p>
              <p className="text-[10px] text-yellow-400/60 mb-2">
                ⚡ Data market cap langsung dari Pump.fun API — akurat untuk token di bonding curve.
              </p>
              {/* Preset cepat */}
              <div className="grid grid-cols-4 gap-1.5 mb-2">
                {[["0","Semua"],["3000","$3K"],["5000","$5K"],["7000","$7K"],["9000","$9K"],["10000","$10K"],["25000","$25K"],["50000","$50K"]].map(([v, label]) => (
                  <button key={v} onClick={() => setMinVolume(v)}
                    className={`rounded-lg py-2 text-[10px] font-black transition-all ${
                      minVolume === v
                        ? "bg-[#9945FF] text-white shadow-[0_0_10px_rgba(153,69,255,0.4)]"
                        : "border border-[#9945FF]/20 bg-[#9945FF]/5 text-white/60"
                    }`}>{label}</button>
                ))}
              </div>
              {/* Input custom */}
              <div className="relative mt-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40 text-sm font-bold">$</span>
                <input
                  type="number" value={minVolume} onChange={e => setMinVolume(e.target.value)}
                  placeholder="Custom (contoh: 2500)"
                  className="w-full rounded-lg border border-[#9945FF]/25 bg-[#9945FF]/10 pl-7 pr-3 py-2 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-[#9945FF]/60"
                  min="0" max="10000000" step="100"
                />
              </div>
              <p className="text-[10px] text-white/30 mt-1.5">
                Aktif: <span className="text-[#c084fc] font-bold">{parseInt(minVolume) === 0 ? "Tanpa filter" : `$${parseInt(minVolume).toLocaleString()}`}</span>
                {" · "}Tekan <span className="text-white/50 font-bold">Simpan</span> untuk apply
              </p>
            </div>

            {/* ── Usia Token ── */}
            <div className="glass rounded-2xl p-4">
              <label className="text-xs font-black text-white mb-1 block">Usia Token Maksimal</label>
              <p className="text-[10px] text-white/50 mb-2">
                Hanya snipe token yang baru launch dalam rentang ini.
              </p>
              <div className="flex gap-1.5">
                {([5, 10, 20, 40, 60] as const).map((min) => (
                  <button key={min} onClick={() => setMaxTokenAge(min)}
                    className={`flex-1 rounded-lg py-2.5 text-[10px] font-black transition-all ${
                      maxTokenAge === min
                        ? "bg-[#9945FF] text-white shadow-[0_0_10px_rgba(153,69,255,0.4)]"
                        : "border border-[#9945FF]/20 bg-[#9945FF]/5 text-white/60"
                    }`}>
                    {min === 60 ? "1j" : `${min}m`}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-white/30 mt-2 text-center">
                {maxTokenAge === 5  && "Ultra agresif — hanya token < 5 menit"}
                {maxTokenAge === 10 && "Sangat agresif — token < 10 menit"}
                {maxTokenAge === 20 && "Agresif — token < 20 menit (rekomendasi)"}
                {maxTokenAge === 40 && "Sedang — token < 40 menit"}
                {maxTokenAge === 60 && "Santai — token < 1 jam"}
              </p>
            </div>

            {saveError && (
              <p className="text-xs text-[#ff3b5c] bg-[#ff3b5c]/10 rounded-xl px-3 py-2 font-bold">{saveError}</p>
            )}
            {saveOk && (
              <p className="text-xs text-[#00ff87] bg-[#00ff87]/10 rounded-xl px-3 py-2 font-bold">✅ Pengaturan tersimpan</p>
            )}

            <button
              onClick={handleSave} disabled={saving}
              className="w-full rounded-xl py-3.5 text-sm font-black text-white disabled:opacity-50 transition-all"
              style={{ background: saving ? "rgba(153,69,255,0.4)" : "linear-gradient(135deg,#9945FF,#7c3aed)", boxShadow: "0 0 20px rgba(153,69,255,0.4)" }}
            >
              {saving ? "Menyimpan..." : "💾 Simpan Pengaturan"}
            </button>

            {/* ── Test Poll ── */}
            <div className="glass rounded-2xl p-4">
              <p className="text-[10px] font-black text-white/70 uppercase tracking-wider mb-1">Test Poll Manual</p>
              <p className="text-[10px] text-white/50 mb-1 leading-relaxed">
                Simulasi scan Pump.fun — ambil token, cek filter usia &amp; volume. Tidak ada buy.
              </p>
              <p className="text-[10px] text-yellow-400/70 mb-3 leading-relaxed">
                ⚠ Pakai filter yang sudah <span className="font-black">tersimpan di DB</span> — simpan pengaturan dulu sebelum test.
              </p>
              <button
                onClick={handleTestPoll}
                disabled={pollRunning}
                className="w-full rounded-xl border border-[#9945FF]/50 bg-[#9945FF]/20 py-2.5 text-sm font-black text-white hover:bg-[#9945FF]/30 transition-all disabled:opacity-50"
              >
                {pollRunning ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    Scanning Pump.fun...
                  </span>
                ) : "🔍 Test Poll Manual"}
              </button>
              {pollResult && (
                <p className="mt-2 text-[10px] text-white/80 font-semibold bg-white/10 rounded-lg px-3 py-2 leading-relaxed break-words">{pollResult}</p>
              )}
            </div>

            {/* ── Info cara kerja ── */}
            <div className="glass rounded-2xl p-4">
              <p className="text-[10px] font-black text-white/70 uppercase tracking-wider mb-2">Cara Kerja</p>
              <div className="flex flex-col gap-2">
                {[
                  ["🔍", "Scan 40 token Pump.fun terbaru tiap menit via cron"],
                  ["💧", "Filter token fresh sesuai usia & volume yang kamu set"],
                  ["⚡", "Buy otomatis via Pump.fun bonding curve (setelah wallet aktif)"],
                  ["🛡️", "Anti-duplikat: satu token hanya dibeli sekali per akun"],
                  ["📊", "Batas harian reset tiap tengah malam UTC"],
                ].map(([icon, text], i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="text-sm shrink-0">{icon}</span>
                    <p className="text-[10px] text-white/55 leading-snug">{text}</p>
                  </div>
                ))}
              </div>
              <div className="mt-3 rounded-xl bg-[#9945FF]/10 border border-[#9945FF]/20 px-3 py-2.5">
                <p className="text-[10px] text-[#c084fc] font-bold leading-relaxed">
                  {settings?.solanaWalletAddress
                    ? "✅ Wallet aktif — sniper siap buy otomatis!"
                    : "🔑 Tambahkan Solana private key di atas untuk aktifkan buy otomatis."}
                </p>
              </div>
            </div>
          </>
        )}

        {/* ═══ HISTORY VIEW ═══ */}
        {view === "history" && (
          <>
            {history.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-4xl mb-3">🚀</div>
                <p className="text-white/75 font-black text-sm">Belum ada snipe</p>
                <p className="text-white/45 text-xs mt-1">Aktifkan Pump.fun Sniper di tab Pengaturan</p>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between gap-2">
                  <div className="grid grid-cols-3 gap-2 flex-1">
                    {[
                      ["Total", history.length],
                      ["Berhasil", history.filter(h => h.status === "success").length],
                      ["Gagal", history.filter(h => h.status === "failed").length],
                    ].map(([label, val]) => (
                      <div key={label} className="glass-cell rounded-xl p-3 text-center">
                        <p className="text-white font-black text-lg leading-none">{val}</p>
                        <p className="text-[10px] text-white/50 mt-0.5 font-bold">{label}</p>
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={handleClearHistory}
                    disabled={clearingHistory}
                    className="shrink-0 text-[10px] font-black text-[#ff3b5c]/60 hover:text-[#ff3b5c] border border-[#ff3b5c]/20 rounded-xl px-2.5 py-2 transition-all disabled:opacity-40"
                  >
                    {clearingHistory ? "..." : "🗑️ Hapus"}
                  </button>
                </div>

                {history.map((log) => {
                  const s = STATUS_MAP[log.status] ?? { label: log.status, cls: "bg-white/5 text-white/50" };
                  return (
                    <div key={log.id} className="glass rounded-xl overflow-hidden">
                      <div className="p-3 flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-white text-sm">
                              {log.tokenSymbol ? `$${log.tokenSymbol}` : log.tokenName ?? `${log.mintAddress.slice(0, 8)}...`}
                            </span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${s.cls}`}>{s.label}</span>
                          </div>
                          <p className="text-[10px] text-white/40 font-mono mt-0.5 truncate">{log.mintAddress}</p>
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            <span className="text-[10px] text-white/50">
                              {parseFloat(log.buyAmountSol).toFixed(4)} SOL
                            </span>
                            {log.volumeUsdAtSnipe != null && log.volumeUsdAtSnipe > 0 && (
                              <span className="text-[10px] text-[#c084fc]">
                                Vol h1: ${log.volumeUsdAtSnipe.toLocaleString()}
                              </span>
                            )}
                            {(log.volumeUsdAtSnipe == null || log.volumeUsdAtSnipe === 0) && (
                              <span className="text-[10px] text-white/30">Vol: -</span>
                            )}
                            <span className="text-[10px] text-white/30">{fmtAge(log.createdAt)}</span>
                          </div>
                          {log.errorMessage && (
                            <p className="text-[10px] text-[#ff3b5c] mt-1 leading-snug">{log.errorMessage.slice(0, 100)}</p>
                          )}
                        </div>
                        {log.txSignature && (
                          <a
                            href={`https://solscan.io/tx/${log.txSignature}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="shrink-0 text-[10px] font-black text-[#c084fc] border border-[#9945FF]/25 rounded-lg px-2 py-1 hover:bg-[#9945FF]/15 transition-all"
                          >
                            TX ↗
                          </a>
                        )}
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
