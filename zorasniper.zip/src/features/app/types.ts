export type WatchedWallet = {
  id: string;
  fid: number;
  walletAddress: string;
  label: string | null;
  isActive: boolean;
  // Per-wallet override settings (null = pakai global)
  buyAmountEth: string | null;
  maxBuysPerDay: number | null;
  slippageBps: number | null;
  createdAt: Date;
};

export type SniperSettings = {
  id: string;
  fid: number;
  isEnabled: boolean;
  buyAmountEth: string;
  slippageBps: number;
  minLiquidityUsd: number;
  walletAddress: string | null;
  maxBuysPerDay: number;
  hasPrivateKey: boolean;
  updatedAt: Date;
};

export type SnipeRecord = {
  id: string;
  fid: number;
  triggeredByWallet: string;
  tokenAddress: string;
  tokenName: string | null;
  tokenSymbol: string | null;
  buyAmountEth: string;
  tokensReceived: string | null;
  txHash: string | null;
  status: "pending" | "success" | "failed";
  errorMessage: string | null;
  createdAt: Date;
  updatedAt: Date;
};

export type SnipeStats = {
  total: number;
  success: number;
  failed: number;
  totalSpentEth: number;
};

export type Tab = "sniper" | "watchlist" | "history" | "trader" | "clanker" | "pumpfun";
