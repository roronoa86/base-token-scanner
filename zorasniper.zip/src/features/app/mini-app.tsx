"use client";

import { useState, useEffect, useCallback } from "react";
import { useFarcasterUser } from "@/neynar-farcaster-sdk/mini";
import { apiFetch } from "@/lib/api-client";
import { TabBar } from "@/features/app/components/tab-bar";
import { SniperTab } from "@/features/app/components/sniper-tab";
import { WatchlistTab } from "@/features/app/components/watchlist-tab";
import { HistoryTab } from "@/features/app/components/history-tab";
import { TraderTab } from "@/features/app/components/trader-tab";
import { ClankerTab } from "@/features/app/components/clanker-tab";
import { PumpfunTab } from "@/features/app/components/pumpfun-tab";
import { BackgroundPicker } from "@/features/app/components/background-picker";
import { LogoutConfirmModal } from "@/features/app/components/logout-confirm";
import type { Tab, SniperSettings, WatchedWallet } from "@/features/app/types";

const DEFAULT_BG = "1779667332438.png";

const WEB_FID_KEY     = "zora_sniper_fid";
const WEB_USER_KEY    = "zora_sniper_user";
const WEB_EMAIL_KEY   = "zora_sniper_email";
const WEB_TOKEN_KEY   = "zora_sniper_token";

// Helper: ambil token dari localStorage (web mode only)
export function getWebSessionToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(WEB_TOKEN_KEY);
}

// ─── Email OTP Login Screen ───────────────────────────────────────────────────

type LoginStep = "email" | "otp" | "not_registered";

function EmailLoginScreen({ onLogin }: { onLogin: (fid: number, username: string) => void }) {
  const [step, setStep]       = useState<LoginStep>("email");
  const [email, setEmail]     = useState("");
  const [otp, setOtp]         = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");

  const handleSendOtp = async () => {
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = await res.json();

      if (res.status === 403 && data.notRegistered) {
        setStep("not_registered");
        return;
      }
      if (!res.ok) {
        setError(data.error ?? "Gagal mengirim kode");
        return;
      }
      setStep("otp");
    } catch {
      setError("Gagal terhubung ke server");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), code: otp.trim() }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Kode salah");
        return;
      }

      localStorage.setItem(WEB_FID_KEY, String(data.fid));
      localStorage.setItem(WEB_USER_KEY, data.email);
      localStorage.setItem(WEB_EMAIL_KEY, data.email);
      if (data.token) localStorage.setItem(WEB_TOKEN_KEY, data.token);
      onLogin(data.fid, data.email);
    } catch {
      setError("Gagal terhubung ke server");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="flex h-dvh flex-col items-center justify-center p-6 relative"
      style={{ backgroundImage: "url('/1779667332438.png')", backgroundSize: "cover", backgroundPosition: "center top" }}
    >
      <div className="absolute inset-0 bg-[#00050f]/60" />

      <div className="relative z-10 w-full max-w-xs flex flex-col items-center gap-6">
        {/* Logo */}
        <div className="flex flex-col items-center gap-2">
          <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-[0_0_32px_rgba(0,82,255,0.55)]">
            <img src="/1779613051394.jpg" alt="Zora Sniper" className="w-full h-full object-cover" />
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">Zora Sniper</h1>
          <p className="text-[#6b9fff] font-bold text-xs tracking-widest uppercase">on Base</p>
        </div>

        {/* Card */}
        <div className="w-full rounded-2xl p-5 flex flex-col gap-4"
          style={{ background: "linear-gradient(160deg,rgba(10,30,80,0.75),rgba(4,14,48,0.70))", backdropFilter: "blur(20px)", border: "1px solid rgba(80,130,255,0.25)" }}>

          {/* Step: Email */}
          {step === "email" && (
            <>
              <div>
                <p className="text-white font-black text-base">Masuk dengan Email</p>
                <p className="text-white/50 text-xs mt-0.5">Kode OTP akan dikirim ke emailmu</p>
              </div>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                onKeyDown={e => e.key === "Enter" && email && handleSendOtp()}
                placeholder="email@kamu.com"
                className="w-full rounded-xl px-4 py-3 text-sm font-semibold text-white placeholder-white/30 outline-none"
                style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)" }}
              />
              {error && <p className="text-red-400 text-xs font-semibold">{error}</p>}
              <button
                onClick={handleSendOtp}
                disabled={!email.trim() || loading}
                className="w-full rounded-xl py-3.5 text-sm font-black text-white disabled:opacity-40 transition-all"
                style={{ background: "linear-gradient(135deg,#0052FF,#0040cc)", boxShadow: "0 0 20px rgba(0,82,255,0.4)" }}
              >
                {loading ? "Mengirim..." : "Kirim Kode OTP →"}
              </button>
            </>
          )}

          {/* Step: Email belum terdaftar */}
          {step === "not_registered" && (
            <>
              <div className="text-center">
                <div className="text-4xl mb-3">📱</div>
                <p className="text-white font-black text-base">Belum Punya Akun?</p>
                <p className="text-white/50 text-xs mt-1 leading-relaxed">
                  Untuk menggunakan Zora Sniper di web, kamu perlu daftar dulu lewat Farcaster dan tautkan emailmu di sana.
                </p>
              </div>
              <div className="rounded-xl p-4 text-center"
                style={{ background: "rgba(0,82,255,0.08)", border: "1px solid rgba(0,82,255,0.2)" }}>
                <p className="text-[#6b9fff] text-xs font-bold leading-relaxed">
                  1. Buka app di Farcaster / Warpcast<br/>
                  2. Masuk ke tab Settings<br/>
                  3. Tautkan email kamu<br/>
                  4. Kembali ke sini dan login
                </p>
              </div>
              <button
                onClick={() => { setStep("email"); setError(""); }}
                className="w-full rounded-xl py-3 text-sm font-bold text-white/60 border border-white/10 hover:text-white transition-all"
              >
                ← Coba email lain
              </button>
            </>
          )}

          {/* Step: OTP */}
          {step === "otp" && (
            <>
              <div>
                <p className="text-white font-black text-base">Masukkan Kode OTP</p>
                <p className="text-white/50 text-xs mt-0.5">Cek inbox emailmu, berlaku 10 menit</p>
              </div>
              <div className="rounded-xl px-4 py-2.5 text-xs text-[#6b9fff] font-semibold"
                style={{ background: "rgba(0,82,255,0.1)", border: "1px solid rgba(0,82,255,0.2)" }}>
                📧 {email}
              </div>
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={otp}
                onChange={e => setOtp(e.target.value.replace(/\D/g, ""))}
                onKeyDown={e => e.key === "Enter" && otp.length === 6 && handleVerifyOtp()}
                placeholder="000000"
                className="w-full rounded-xl px-4 py-3 text-center text-2xl font-black text-white placeholder-white/20 tracking-[0.5em] outline-none"
                style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)" }}
              />
              {error && <p className="text-red-400 text-xs font-semibold">{error}</p>}
              <button
                onClick={handleVerifyOtp}
                disabled={otp.length !== 6 || loading}
                className="w-full rounded-xl py-3.5 text-sm font-black text-white disabled:opacity-40 transition-all"
                style={{ background: "linear-gradient(135deg,#00c853,#00897b)", boxShadow: "0 0 20px rgba(0,200,83,0.35)" }}
              >
                {loading ? "Memverifikasi..." : "Masuk →"}
              </button>
              <button onClick={() => { setStep("email"); setOtp(""); setError(""); }}
                className="text-xs text-white/40 hover:text-white/70 transition-colors text-center">
                Kirim ulang kode
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export function MiniApp() {
  const { data: user } = useFarcasterUser();
  const farcasterFid = user?.fid;

  const [webFid, setWebFid]       = useState<number | null>(null);
  const [webUsername, setWebUsername] = useState<string | null>(null);
  const [hydrated, setHydrated]   = useState(false);

  // On mount: restore web session from localStorage
  useEffect(() => {
    const savedFid  = localStorage.getItem(WEB_FID_KEY);
    const savedUser = localStorage.getItem(WEB_USER_KEY);
    if (savedFid) {
      setWebFid(parseInt(savedFid, 10));
      setWebUsername(savedUser);
    }
    setHydrated(true);
  }, []);

  const fid      = farcasterFid ?? webFid;
  const isWebMode = !farcasterFid && !!webFid;

  // Display name for header: prefer Farcaster username, fallback to saved web username
  const displayName = user?.username
    ? `@${user.username}`
    : webUsername
      ? `@${webUsername}`
      : fid ? `FID ${fid}` : null;

  const [activeTab, setActiveTab]     = useState<Tab>("sniper");
  const [settings, setSettings]       = useState<SniperSettings | null>(null);
  const [wallets, setWallets]         = useState<WatchedWallet[]>([]);
  const [isToggling, setIsToggling]   = useState(false);
  const [bgId, setBgId]                   = useState<string>(DEFAULT_BG);
  const [bgDataUrl, setBgDataUrl]         = useState<string | undefined>(undefined);
  const [showBgPicker, setShowBgPicker]   = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const loadSettings = useCallback(async () => {
    if (!fid) return;
    try {
      const res = await apiFetch(`/api/sniper/settings?fid=${fid}`);
      const data = await res.json();
      setSettings(data);
    } catch {/* silent */}
  }, [fid]);

  const loadWallets = useCallback(async () => {
    if (!fid) return;
    try {
      const res = await apiFetch(`/api/sniper/wallets?fid=${fid}`);
      const data = await res.json();
      setWallets(data ?? []);
    } catch {/* silent */}
  }, [fid]);

  // Load background preference from DB (including custom uploaded image)
  useEffect(() => {
    if (!fid) return;
    fetch(`/api/user/background?fid=${fid}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.bgId) setBgId(d.bgId);
        if (d.bgId === "custom" && d.dataUrl) setBgDataUrl(d.dataUrl);
      })
      .catch(() => {});
  }, [fid]);

  useEffect(() => {
    if (fid) { loadSettings(); loadWallets(); }
  }, [fid, loadSettings, loadWallets]);

  const handleToggleSniper = async (enabled: boolean) => {
    if (!fid) return;
    setIsToggling(true);
    try {
      await apiFetch("/api/sniper/settings", {
        method: "POST",
        body: JSON.stringify({ fid, isEnabled: enabled }),
      });
      await loadSettings();
    } catch {/* silent */} finally { setIsToggling(false); }
  };

  const handleLogout = () => {
    const token = localStorage.getItem(WEB_TOKEN_KEY);
    if (token) {
      // Fire-and-forget: hapus session di server
      fetch("/api/auth/logout", { method: "POST", headers: { "Authorization": `Bearer ${token}` } }).catch(() => {});
    }
    localStorage.removeItem(WEB_FID_KEY);
    localStorage.removeItem(WEB_USER_KEY);
    localStorage.removeItem(WEB_EMAIL_KEY);
    localStorage.removeItem(WEB_TOKEN_KEY);
    setWebFid(null);
    setWebUsername(null);
  };

  const handleWebLogin = (newFid: number, username: string) => {
    setWebFid(newFid);
    setWebUsername(username);
  };

  // Loading splash
  if (!hydrated) {
    return (
      <div className="flex h-dvh items-center justify-center relative"
        style={{ backgroundImage: "url('/1779667332438.png')", backgroundSize: "cover", backgroundPosition: "center top" }}>
        <div className="absolute inset-0 bg-[#00050f]/55" />
        <div className="relative flex flex-col items-center gap-3">
          <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-[0_0_32px_rgba(0,82,255,0.55)] animate-pulse">
            <img src="/1779613051394.jpg" alt="Zora Sniper" className="w-full h-full object-cover" />
          </div>
          <p className="text-white font-bold text-sm">Memuat...</p>
        </div>
      </div>
    );
  }

  // Not authenticated → show Email OTP login
  if (!fid) {
    return <EmailLoginScreen onLogin={handleWebLogin} />;
  }

  return (
    <div className="flex h-dvh flex-col relative overflow-hidden">
      {/* Background — changes per user preference (preset or custom upload) */}
      <div className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-all duration-700"
        style={{
          backgroundImage: bgId === "custom" && bgDataUrl
            ? `url('${bgDataUrl}')`
            : `url('/${bgId}')`,
          backgroundPosition: "center top",
        }} />
      <div className="absolute inset-0 bg-[#00050f]/45" />

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between glass-header px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg overflow-hidden shadow-[0_0_12px_rgba(0,82,255,0.5)]">
            <img src="/1779613051394.jpg" alt="Zora Sniper" className="w-full h-full object-cover" />
          </div>
          <div>
            <span className="text-sm font-black text-white tracking-tight leading-none block">Zora Sniper</span>
            <span className="text-[9px] font-semibold text-[#0052FF] leading-none tracking-wider uppercase">on Base</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Sniper status dot */}
          <div className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold transition-all ${
            settings?.isEnabled
              ? "bg-[#00ff87]/10 border border-[#00ff87]/30 text-[#00ff87]"
              : "bg-white/5 border border-white/15 text-white/70"
          }`}>
            <span className={`h-1.5 w-1.5 rounded-full ${settings?.isEnabled ? "bg-[#00ff87] shadow-[0_0_6px_#00ff87]" : "bg-white/30"}`} />
            {settings?.isEnabled ? "LIVE" : "OFF"}
          </div>
          {/* Background picker button */}
          <button
            onClick={() => setShowBgPicker(true)}
            className="flex items-center justify-center w-7 h-7 rounded-lg text-white/50 hover:text-white/90 hover:bg-white/10 transition-all"
            title="Ganti background"
          >
            🎨
          </button>

          {/* Web mode: show username + logout (with confirm) */}
          {isWebMode && displayName && (
            <button onClick={() => setShowLogoutConfirm(true)}
              className="flex items-center gap-1.5 text-[10px] font-bold text-white/85 border border-white/15 rounded-lg px-2 py-1 hover:text-white hover:border-[#0052FF]/40 bg-white/5 backdrop-blur-sm transition-colors">
              <span className="max-w-[80px] truncate">{displayName}</span>
              <span className="opacity-60 shrink-0">↩</span>
            </button>
          )}
        </div>
      </div>

      {/* Tab content */}
      <div className="relative z-10 flex-1 overflow-y-auto">
        {activeTab === "sniper" && (
          <SniperTab fid={fid} settings={settings} wallets={wallets}
            onToggleSniper={handleToggleSniper} isToggling={isToggling}
            onSettingsChange={loadSettings} />
        )}
        {activeTab === "watchlist" && (
          <WatchlistTab fid={fid} wallets={wallets} onWalletsChange={loadWallets}
            globalBuyAmountEth={settings?.buyAmountEth ?? "0.001"}
            globalMaxBuysPerDay={settings?.maxBuysPerDay ?? 10}
            globalSlippageBps={settings?.slippageBps ?? 500} />
        )}
        {activeTab === "history"  && <HistoryTab  fid={fid} />}
        {activeTab === "trader"   && <TraderTab   fid={fid} />}
        {activeTab === "clanker"  && <ClankerTab  fid={fid} />}
        {activeTab === "pumpfun"  && <PumpfunTab  fid={fid} />}
      </div>

      {/* Tab bar */}
      <div className="relative z-10">
        <TabBar activeTab={activeTab} onTabChange={setActiveTab} />
      </div>

      {/* Background picker modal */}
      {showBgPicker && fid && (
        <BackgroundPicker
          fid={fid}
          currentBg={bgId}
          currentDataUrl={bgDataUrl}
          onClose={() => setShowBgPicker(false)}
          onSelect={(id, dataUrl) => {
            setBgId(id);
            setBgDataUrl(id === "custom" ? dataUrl : undefined);
          }}
        />
      )}

      {/* Logout confirm modal */}
      {showLogoutConfirm && (
        <LogoutConfirmModal
          username={displayName ?? "akun ini"}
          onConfirm={() => { setShowLogoutConfirm(false); handleLogout(); }}
          onCancel={() => setShowLogoutConfirm(false)}
        />
      )}
    </div>
  );
}
