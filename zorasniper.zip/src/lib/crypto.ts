/**
 * AES-256-GCM enkripsi/dekripsi untuk private key
 * Pakai Web Crypto API (built-in Node.js, zero dependency)
 *
 * Format ciphertext: base64( iv[12] + authTag[16] + encrypted )
 * Master key dari env var ENCRYPTION_KEY (32 byte hex = 64 karakter)
 */

const ALGO = "AES-GCM";
const KEY_LENGTH = 256;
const IV_LENGTH = 12; // 96-bit IV untuk GCM

function getMasterKeyMaterial(): string {
  // Gunakan ENCRYPTION_KEY dari env, fallback ke kombinasi secrets
  const key = process.env.ENCRYPTION_KEY;
  if (key && key.length >= 32) return key;

  // Fallback: derive dari NEYNAR_API_KEY + deployment ID
  // Ini deterministic sehingga key lama masih bisa di-decrypt
  const fallback = [
    process.env.NEYNAR_API_KEY ?? "",
    process.env.NEXT_PUBLIC_DEPLOYMENT_ID ?? "",
    "zora-sniper-v1",
  ].join("|");

  return fallback;
}

async function getDerivedKey(): Promise<CryptoKey> {
  const material = getMasterKeyMaterial();
  const enc = new TextEncoder();

  // Import raw key material
  const baseKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(material),
    { name: "PBKDF2" },
    false,
    ["deriveKey"],
  );

  // Derive AES-256-GCM key (PBKDF2 dengan salt tetap — deterministic)
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: enc.encode("zora-sniper-salt-v1"),
      iterations: 100_000,
      hash: "SHA-256",
    },
    baseKey,
    { name: ALGO, length: KEY_LENGTH },
    false,
    ["encrypt", "decrypt"],
  );
}

/**
 * Enkripsi string (private key) → ciphertext base64
 */
export async function encrypt(plaintext: string): Promise<string> {
  const key = await getDerivedKey();
  const enc = new TextEncoder();
  const iv = crypto.getRandomValues(new Uint8Array(IV_LENGTH));

  const encrypted = await crypto.subtle.encrypt(
    { name: ALGO, iv },
    key,
    enc.encode(plaintext),
  );

  // Gabungkan: iv + ciphertext (termasuk auth tag 16 byte di akhir)
  const combined = new Uint8Array(iv.byteLength + encrypted.byteLength);
  combined.set(iv, 0);
  combined.set(new Uint8Array(encrypted), iv.byteLength);

  return Buffer.from(combined).toString("base64");
}

/**
 * Dekripsi ciphertext base64 → plaintext
 */
export async function decrypt(ciphertext: string): Promise<string> {
  const key = await getDerivedKey();
  const dec = new TextDecoder();

  const combined = Buffer.from(ciphertext, "base64");
  const iv = combined.subarray(0, IV_LENGTH);
  const data = combined.subarray(IV_LENGTH);

  const decrypted = await crypto.subtle.decrypt(
    { name: ALGO, iv },
    key,
    data,
  );

  return dec.decode(decrypted);
}

/**
 * Cek apakah string adalah ciphertext terenkripsi (bukan raw private key)
 * Raw private key = 0x + 64 hex chars
 * Encrypted = base64 string yang lebih panjang
 */
export function isEncrypted(value: string): boolean {
  // Raw private key: 0x diikuti 64 hex chars (66 total)
  if (/^0x[0-9a-fA-F]{64}$/.test(value)) return false;
  // Raw private key tanpa 0x: 64 hex chars
  if (/^[0-9a-fA-F]{64}$/.test(value)) return false;
  // Selain itu anggap sudah encrypted
  return true;
}
