/**
 * Solana buy helper — beli token Pump.fun via PumpPortal local signing.
 *
 * Flow:
 *   1. Ambil latest blockhash dari RPC
 *   2. Request unsigned transaction dari PumpPortal (kirim publicKey saja — private key TIDAK dikirim)
 *   3. Sign dengan private key user lokal
 *   4. Broadcast signed tx ke Solana via RPC
 *   5. Konfirmasi on-chain
 */

import {
  Connection,
  Keypair,
  VersionedTransaction,
} from "@solana/web3.js";
import bs58 from "bs58";
import { decrypt } from "@/lib/crypto";

function getSolanaConnection(): Connection {
  const rpc = process.env.SOLANA_RPC_URL ?? "https://api.mainnet-beta.solana.com";
  return new Connection(rpc, "confirmed");
}

/**
 * Decrypt + decode keypair dari encrypted base58 yang tersimpan di DB.
 * DB menyimpan: encrypt(base58(64-byte keypair))
 */
async function decryptKeypair(encryptedKey: string): Promise<Keypair> {
  const decrypted = await decrypt(encryptedKey);
  const bytes = bs58.decode(decrypted);
  if (bytes.length === 64) return Keypair.fromSecretKey(bytes);
  if (bytes.length === 32) return Keypair.fromSeed(bytes);
  throw new Error(`Ukuran keypair tidak valid: ${bytes.length} byte`);
}

export interface BuyResult  { success: true;  txSignature: string }
export interface BuyError   { success: false; error: string }

/**
 * Beli token Pump.fun via PumpPortal local signing.
 *
 * @param encryptedPrivateKey  encrypted key dari DB
 * @param mintAddress          Solana mint address token target
 * @param solAmount            jumlah SOL, string (contoh "0.01")
 * @param slippageBps          slippage basis points (1000 = 10%)
 */
export async function buyPumpfunToken(
  encryptedPrivateKey: string,
  mintAddress: string,
  solAmount: string,
  slippageBps: number,
): Promise<BuyResult | BuyError> {
  try {
    const keypair    = await decryptKeypair(encryptedPrivateKey);
    const connection = getSolanaConnection();

    // Slippage: kirim sebagai angka persen integer (10 = 10%)
    const slippageInt = Math.round(slippageBps / 100);

    // ── Step 1: Request unsigned tx dari PumpPortal ──
    // Kita hanya kirim publicKey — private key TIDAK pernah keluar dari server kita
    const tradeRes = await fetch("https://pumpportal.fun/api/trade-local", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        publicKey:        keypair.publicKey.toBase58(),
        action:           "buy",
        mint:             mintAddress,
        denominatedInSol: true,          // boolean, bukan string
        amount:           parseFloat(solAmount),
        slippage:         slippageInt,   // integer persen
        priorityFee:      0.00005,       // SOL — priority fee kecil (~$0.008)
        pool:             "pump",        // bonding curve Pump.fun (bukan raydium)
      }),
    });

    if (!tradeRes.ok) {
      const errText = await tradeRes.text().catch(() => "unknown");
      return { success: false, error: `PumpPortal error ${tradeRes.status}: ${errText.slice(0, 200)}` };
    }

    const txBytes = new Uint8Array(await tradeRes.arrayBuffer());
    if (!txBytes.length) {
      return { success: false, error: "PumpPortal mengembalikan transaksi kosong" };
    }

    // ── Step 2: Ambil blockhash fresh dulu ──
    const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");

    // ── Step 3: Deserialize + sign lokal ──
    const tx = VersionedTransaction.deserialize(txBytes);
    tx.sign([keypair]);

    // ── Step 4: Broadcast dengan skipPreflight=true untuk kecepatan snipe ──
    const signature = await connection.sendRawTransaction(tx.serialize(), {
      skipPreflight:       true,   // skip preflight agar lebih cepat sampai ke validator
      maxRetries:          5,
      preflightCommitment: "confirmed",
    });

    // ── Step 5: Konfirmasi on-chain ──
    const result = await connection.confirmTransaction(
      { signature, blockhash, lastValidBlockHeight },
      "confirmed",
    );

    if (result.value.err) {
      return {
        success: false,
        error: `Tx on-chain gagal: ${JSON.stringify(result.value.err)}`,
      };
    }

    return { success: true, txSignature: signature };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { success: false, error: msg.slice(0, 300) };
  }
}
