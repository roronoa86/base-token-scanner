/**
 * Swap Engine — shared buy/sell routing untuk AutoTrade
 *
 * Routing waterfall (buy & sell):
 *   1. Paraswap  — solver/aggregator, no API key, best rates, Base native
 *   2. KyberSwap — aggregator kuat, cover token exotic (VIRTUAL-quoted, Clanker)
 *   3. LI.FI     — aggregator lintas-DEX (SushiSwap/Uniswap/dll), fallback
 *   4. Zora SDK  — last resort khusus Zora Coins (jika semua aggregator gagal)
 *
 * Catatan: Odos dihapus — API key enterprise-only, selalu 429 tanpa key.
 * 1inch dihapus — butuh KYC untuk dapat API key.
 *
 * Semua aggregator otomatis menemukan rute terbaik termasuk multi-hop.
 * Tidak perlu direct routes — aggregator sudah handle Aerodrome, V3, V4 di dalamnya.
 *
 * MEV Protection:
 * - Private mempool via Flashbots Protect RPC (Base)
 * - Deadline 2 menit untuk minimize sandwich window
 * - Gas cap 2 gwei (Base L2 biasanya < 0.01 gwei)
 * - Nonce fetched tepat sebelum sign (anti-reorg)
 *
 * Security:
 * - Gas buffer 1.5x untuk taxed tokens
 * - Receipt wait dengan timeout — jangan assume success tanpa konfirmasi
 */

import { base } from "viem/chains";
import { privateKeyToAccount } from "viem/accounts";

// ─── Constants ────────────────────────────────────────────────────────────────

export const WETH     = "0x4200000000000000000000000000000000000006";
export const ETH_ADDR = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE";
const PERMIT2         = "0x000000000022D473030F116dDEE9F6B43aC78BA3";

// MEV Protection: Flashbots Protect endpoint for Base
const MEV_RPC    = "https://rpc.flashbots.net/fast?builder=flashbots&builder=rsync&builder=beaverbuild&builder=titan&chain=8453";
const PUBLIC_RPC = "https://mainnet.base.org";
const BACKUP_RPC = "https://base-rpc.publicnode.com";

// Aggregator APIs
const PARASWAP_API = "https://api.paraswap.io";
const KYBER_API    = "https://aggregator-api.kyberswap.com/base/api/v1";
const LIFI_API     = "https://li.quest/v1";


// ─── Types ────────────────────────────────────────────────────────────────────

export type SwapAccount = ReturnType<typeof privateKeyToAccount>;

export interface SwapQuote {
  target: string;
  data: string;
  value: bigint;
  route: string;
  amountOut: string;
  amountOutUsd: number;
}

export interface TxReceipt {
  status: string;
  gasUsed: string;
  logs: Array<{ address: string; topics: string[]; data: string }>;
}

// ─── Raw RPC helpers ──────────────────────────────────────────────────────────

export async function rpcRead(method: string, params: unknown[]): Promise<string | null> {
  for (const rpc of [PUBLIC_RPC, BACKUP_RPC]) {
    try {
      const res = await fetch(rpc, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", method, params, id: 1 }),
      });
      const d = await res.json();
      if (!d.error) return d.result as string;
    } catch { /* try next */ }
  }
  return null;
}

export async function sendRawTx(signed: string): Promise<string> {
  // Try MEV-protected first, fallback to public RPCs if Flashbots unavailable
  let lastError = "";
  for (const rpc of [MEV_RPC, PUBLIC_RPC, BACKUP_RPC]) {
    try {
      const res = await fetch(rpc, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", method: "eth_sendRawTransaction", params: [signed], id: 1 }),
      });
      const d = await res.json();
      if (d.error) {
        lastError = d.error.message ?? JSON.stringify(d.error);
        console.warn(`[swap] RPC ${rpc.slice(0, 30)} error:`, lastError);
        // Jika error adalah revert/execution — tidak perlu retry RPC lain, hasilnya sama
        const isRevert = lastError.toLowerCase().includes("revert") ||
                         lastError.toLowerCase().includes("execution") ||
                         lastError.toLowerCase().includes("insufficient funds") ||
                         lastError.toLowerCase().includes("nonce");
        if (isRevert) throw new Error(`TX rejected: ${lastError}`);
        continue;
      }
      console.log(`[swap] TX sent via ${rpc.includes("flashbots") ? "Flashbots MEV-protected" : rpc.slice(0, 30)}`);
      return d.result as string;
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      lastError = msg.slice(0, 200);
      console.warn("[swap] sendRawTx error on", rpc.slice(0, 30), ":", lastError);
      // Propagate revert errors immediately — no point retrying other RPCs
      if (lastError.includes("TX rejected:") || lastError.includes("revert") || lastError.includes("insufficient funds")) {
        throw new Error(lastError);
      }
    }
  }
  throw new Error(`TX gagal dikirim ke semua RPC. Error terakhir: ${lastError || "unknown"}`);
}

export async function waitReceipt(hash: string, maxMs = 60000): Promise<TxReceipt | null> {
  const deadline = Date.now() + maxMs;
  while (Date.now() < deadline) {
    await new Promise(r => setTimeout(r, 3000));
    for (const rpc of [PUBLIC_RPC, BACKUP_RPC]) {
      try {
        const res = await fetch(rpc, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", method: "eth_getTransactionReceipt", params: [hash], id: 2 }),
        });
        const d = await res.json();
        if (d.result) return d.result as TxReceipt;
      } catch { /* retry */ }
    }
  }
  return null;
}

export async function getTokenBalance(token: string, wallet: string): Promise<bigint> {
  const data = "0x70a08231000000000000000000000000" + wallet.slice(2).toLowerCase();
  const r = await rpcRead("eth_call", [{ to: token, data }, "latest"]);
  return r && r !== "0x" ? BigInt(r) : BigInt(0);
}

export async function getTokenDecimals(token: string): Promise<number> {
  const r = await rpcRead("eth_call", [{ to: token, data: "0x313ce567" }, "latest"]);
  return r && r !== "0x" ? parseInt(r, 16) : 18;
}

export function rawBalanceToFloat(raw: bigint, decimals: number): number {
  const divisor = 10n ** BigInt(decimals);
  const whole = raw / divisor;
  const frac  = raw % divisor;
  return Number(whole) + Number(frac) / Number(divisor);
}

export async function getAllowance(token: string, owner: string, spender: string): Promise<bigint> {
  const data = "0xdd62ed3e" +
    "000000000000000000000000" + owner.slice(2).toLowerCase() +
    "000000000000000000000000" + spender.slice(2).toLowerCase();
  const r = await rpcRead("eth_call", [{ to: token, data }, "latest"]);
  return r && r !== "0x" ? BigInt(r) : BigInt(0);
}

export async function getNonce(addr: string): Promise<number> {
  const r = await rpcRead("eth_getTransactionCount", [addr, "latest"]);
  return r ? parseInt(r, 16) : 0;
}

export async function getGasPrice(multiplier: number = 1.0): Promise<bigint> {
  const r = await rpcRead("eth_gasPrice", []);
  const networkBase = r ? BigInt(r) : BigInt("100000000"); // fallback 0.1 gwei
  const MAX_GAS_WEI = BigInt("2000000000"); // 2 gwei hard cap
  // Apply multiplier: 1.0 = hemat, 1.2 = normal, 1.5 = cepat
  const boosted = BigInt(Math.ceil(Number(networkBase) * multiplier)) + BigInt("10000000"); // +0.01 gwei priority
  return boosted < MAX_GAS_WEI ? boosted : MAX_GAS_WEI;
}

export async function estimateGas(to: string, data: string, value: bigint, from: string): Promise<bigint> {
  const r = await rpcRead("eth_estimateGas", [{ to, data, value: "0x" + value.toString(16), from }]);
  // Base L2: gas estimate akurat, buffer 1.1x cukup (bukan 1.5x)
  return r ? BigInt(Math.ceil(parseInt(r, 16) * 1.1)) : BigInt(500000);
}

// ─── ETH/USD rate ─────────────────────────────────────────────────────────────

export async function fetchEthUsdRate(): Promise<number> {
  try {
    const res = await fetch("https://api.dexscreener.com/latest/dex/tokens/0x4200000000000000000000000000000000000006",
      { next: { revalidate: 60 } });
    const d = await res.json();
    const pairs = (d.pairs ?? []).filter((p: { chainId?: string }) => p.chainId === "base");
    const stable = pairs
      .filter((p: { quoteToken?: { symbol?: string } }) =>
        ["USDC","USDC.E","USDT","DAI"].includes((p.quoteToken?.symbol ?? "").toUpperCase()))
      .sort((a: { liquidity?: { usd?: number } }, b: { liquidity?: { usd?: number } }) =>
        (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0))[0];
    return stable ? parseFloat(stable.priceUsd ?? "0") : 2000;
  } catch { return 2000; }
}

// ─── Transfer event parser ────────────────────────────────────────────────────

const TRANSFER_TOPIC   = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
const WITHDRAWAL_TOPIC = "0x7fcf532c15f0a6db0bd6d0e038bea71d30d808c7d98cb3bf7268a95bf5081b65";

export function parseTokensReceived(receipt: TxReceipt, token: string, recipient: string): string | null {
  const tokenL = token.toLowerCase();
  const recipL = recipient.toLowerCase().replace("0x", "").padStart(64, "0");
  for (const log of receipt.logs) {
    if (
      log.address.toLowerCase() === tokenL &&
      log.topics[0]?.toLowerCase() === TRANSFER_TOPIC &&
      log.topics[2]?.toLowerCase().endsWith(recipL.slice(-40))
    ) {
      try { return BigInt(log.data).toString(); } catch { /* skip */ }
    }
  }
  return null;
}

export function parseEthReceived(receipt: TxReceipt, recipient: string): number | null {
  const walletL = recipient.toLowerCase().replace("0x", "");
  const wethL   = WETH.toLowerCase();
  const weiToEth = (hex: string) => {
    const raw = BigInt(hex);
    return Number(raw / BigInt("1000000000000000000")) + Number(raw % BigInt("1000000000000000000")) / 1e18;
  };

  for (const log of receipt.logs) {
    if (log.address.toLowerCase() === wethL &&
        log.topics[0]?.toLowerCase() === WITHDRAWAL_TOPIC &&
        log.topics[1]?.toLowerCase().endsWith(walletL)) {
      try { return weiToEth(log.data); } catch { /* skip */ }
    }
  }
  for (const log of receipt.logs) {
    if (log.address.toLowerCase() === wethL &&
        log.topics[0]?.toLowerCase() === TRANSFER_TOPIC &&
        log.topics[2]?.toLowerCase().endsWith(walletL)) {
      try { return weiToEth(log.data); } catch { /* skip */ }
    }
  }
  let maxW = 0;
  for (const log of receipt.logs) {
    if (log.address.toLowerCase() === wethL && log.topics[0]?.toLowerCase() === WITHDRAWAL_TOPIC) {
      try { const a = weiToEth(log.data); if (a > maxW) maxW = a; } catch { /* skip */ }
    }
  }
  return maxW > 0 ? maxW : null;
}

// ─── ERC-20 Approval helper ────────────────────────────────────────────────────

export async function ensureERC20Approval(
  token: string,
  spender: string,
  amount: bigint,
  account: SwapAccount,
): Promise<void> {
  const allowance = await getAllowance(token, account.address, spender);
  if (allowance >= amount) return;

  const { encodeFunctionData } = await import("viem");
  const data = encodeFunctionData({
    abi: [{ name: "approve", type: "function", inputs: [
      { name: "spender", type: "address" }, { name: "amount", type: "uint256" }
    ], outputs: [{ name: "", type: "bool" }] }],
    functionName: "approve",
    args: [spender as `0x${string}`, BigInt("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff")],
  });

  const [nonce, gasPrice] = await Promise.all([getNonce(account.address), getGasPrice()]);
  let gas: bigint;
  try {
    gas = await estimateGas(token, data, BigInt(0), account.address);
  } catch {
    gas = BigInt(100000);
  }

  const signed = await account.signTransaction({
    chainId: base.id, to: token as `0x${string}`, data, value: BigInt(0),
    nonce, gas, maxFeePerGas: gasPrice, maxPriorityFeePerGas: gasPrice / BigInt(10) < gasPrice ? gasPrice / BigInt(10) : gasPrice, type: "eip1559",
  });

  const txHash = await sendRawTx(signed);
  const approvalReceipt = await waitReceipt(txHash, 60000);
  if (!approvalReceipt) {
    throw new Error(`Approval TX timeout — hash: ${txHash}. Coba lagi.`);
  }
  if (approvalReceipt.status === "0x0") {
    throw new Error(`Approval TX reverted on-chain — hash: ${txHash}`);
  }
  console.log("[swap] ERC-20 approval confirmed:", txHash);
}

// ─── Aggregator 1: Paraswap ───────────────────────────────────────────────────
// Solver + aggregator, no API key, covers Uniswap/Aerodrome/Curve on Base
// Two-step: /prices → /transactions/{chainId}

async function getParaswapQuote(params: {
  tokenIn: string;
  tokenOut: string;
  amountIn: bigint;
  slippageBps: number;
  sender: string;
  decimalsIn: number;
  decimalsOut: number;
}): Promise<SwapQuote | null> {
  try {
    const srcToken  = params.tokenIn.toLowerCase() === ETH_ADDR.toLowerCase()
      ? "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE"
      : params.tokenIn;
    const destToken = params.tokenOut.toLowerCase() === ETH_ADDR.toLowerCase()
      ? "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE"
      : params.tokenOut;

    // Step 1: Get price route
    const priceUrl = new URL(`${PARASWAP_API}/prices`);
    priceUrl.searchParams.set("srcToken", srcToken);
    priceUrl.searchParams.set("destToken", destToken);
    priceUrl.searchParams.set("amount", params.amountIn.toString());
    priceUrl.searchParams.set("srcDecimals", params.decimalsIn.toString());
    priceUrl.searchParams.set("destDecimals", params.decimalsOut.toString());
    priceUrl.searchParams.set("side", "SELL");
    priceUrl.searchParams.set("network", base.id.toString());
    priceUrl.searchParams.set("version", "6.2");
    priceUrl.searchParams.set("partner", "zora-sniper");

    const priceRes = await fetch(priceUrl.toString());
    if (!priceRes.ok) {
      const body = await priceRes.text().catch(() => "");
      console.warn("[paraswap] prices failed:", priceRes.status, body.slice(0, 150));
      return null;
    }

    const priceData = await priceRes.json();
    const priceRoute = priceData.priceRoute;
    if (!priceRoute?.destAmount) {
      console.warn("[paraswap] no priceRoute — error:", priceData.error, "| keys:", Object.keys(priceData).join(","));
      return null;
    }

    const amountOut: string = priceRoute.destAmount;

    // Step 2: Build transaction
    // For SELL: provide srcAmount + slippage (NOT destAmount — that's for BUY side)
    // srcDecimals/destDecimals required when using raw addresses (not symbols)
    const txRes = await fetch(`${PARASWAP_API}/transactions/${base.id}?ignoreChecks=true`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        srcToken,
        destToken,
        srcAmount: params.amountIn.toString(),
        srcDecimals: params.decimalsIn,
        destDecimals: params.decimalsOut,
        slippage: params.slippageBps,   // bps, alternative to destAmount for SELL
        priceRoute,
        userAddress: params.sender,
        partner: "zora-sniper",
      }),
    });

    if (!txRes.ok) {
      const body = await txRes.text().catch(() => "");
      console.warn("[paraswap] tx build failed:", txRes.status, body.slice(0, 200));
      return null;
    }

    const txData = await txRes.json();
    if (!txData.to || !txData.data) {
      console.warn("[paraswap] no tx fields — got:", JSON.stringify(txData).slice(0, 200));
      return null;
    }

    const amountOutUsd: number = parseFloat(priceRoute.destUSD ?? "0");
    console.log("[swap] Paraswap OK — out:", amountOut, "USD:", amountOutUsd.toFixed(4));
    return {
      target: txData.to,
      data: txData.data,
      value: BigInt(txData.value ?? "0"),
      route: "paraswap",
      amountOut,
      amountOutUsd,
    };
  } catch (e) {
    console.error("[paraswap] error:", e instanceof Error ? e.message.slice(0, 100) : e);
    return null;
  }
}

// ─── Aggregator 3: KyberSwap ──────────────────────────────────────────────────
// Strong coverage of exotic tokens (VIRTUAL-quoted, Clanker, etc.)
// Two-step: get route → build TX

async function getKyberQuote(params: {
  tokenIn: string;   // ETH_ADDR or ERC-20 address
  tokenOut: string;
  amountIn: bigint;
  slippageBps: number;
  sender: string;
}): Promise<SwapQuote | null> {
  try {
    // Step 1: Get route summary
    const routeRes = await fetch(
      `${KYBER_API}/routes?tokenIn=${params.tokenIn}&tokenOut=${params.tokenOut}&amountIn=${params.amountIn.toString()}`,
      { headers: { "x-client-id": "zora-sniper" } },
    );
    if (!routeRes.ok) {
      console.warn("[kyber] route failed:", routeRes.status);
      return null;
    }

    const routeData = await routeRes.json();
    if (routeData.code !== 0 || !routeData.data?.routeSummary) {
      console.warn("[kyber] no route:", routeData.message?.slice(0, 60));
      return null;
    }

    const routeSummary = routeData.data.routeSummary;
    const amountOut: string = routeSummary.amountOut ?? "0";

    // Step 2: Build TX calldata
    const buildRes = await fetch(`${KYBER_API}/route/build`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-client-id": "zora-sniper" },
      body: JSON.stringify({
        routeSummary,
        sender: params.sender,
        recipient: params.sender,
        slippageTolerance: params.slippageBps, // Kyber uses bps directly
        deadline: Math.floor(Date.now() / 1000) + 120,
        source: "zora-sniper",
      }),
    });

    if (!buildRes.ok) {
      console.warn("[kyber] build failed:", buildRes.status);
      return null;
    }

    const buildData = await buildRes.json();
    if (buildData.code !== 0 || !buildData.data?.data || !buildData.data?.routerAddress) {
      console.warn("[kyber] build error:", buildData.message?.slice(0, 60));
      return null;
    }

    // ETH swaps: value = amountIn, ERC-20 swaps: value = 0
    const isEthIn = params.tokenIn.toLowerCase() === ETH_ADDR.toLowerCase();
    const value = isEthIn ? params.amountIn : BigInt(0);

    console.log("[swap] KyberSwap OK — amountOut:", amountOut);
    return {
      target: buildData.data.routerAddress,
      data: buildData.data.data,
      value,
      route: "kyber",
      amountOut,
      amountOutUsd: 0, // Kyber doesn't return USD value directly
    };
  } catch (e) {
    console.error("[kyber] error:", e instanceof Error ? e.message.slice(0, 100) : e);
    return null;
  }
}

// ─── Aggregator 4: LI.FI ──────────────────────────────────────────────────────
// Cross-DEX aggregator — SushiSwap, Uniswap, BaseSwap, etc.
// Best as final fallback before Zora SDK

async function getLiFiQuote(params: {
  tokenIn: string;   // "ETH" or ERC-20 address
  tokenOut: string;
  amountIn: bigint;
  slippageBps: number;
  sender: string;
}): Promise<SwapQuote | null> {
  try {
    // LI.FI uses "ETH" for native, not ETH_ADDR
    const fromToken = params.tokenIn.toLowerCase() === ETH_ADDR.toLowerCase() ? "ETH" : params.tokenIn;

    const url = new URL(`${LIFI_API}/quote`);
    url.searchParams.set("fromChain", "8453");
    url.searchParams.set("toChain", "8453");
    url.searchParams.set("fromToken", fromToken);
    url.searchParams.set("toToken", params.tokenOut);
    url.searchParams.set("fromAmount", params.amountIn.toString());
    url.searchParams.set("fromAddress", params.sender);
    url.searchParams.set("slippage", (params.slippageBps / 10000).toString());

    const res = await fetch(url.toString(), { headers: { "x-lifi-api-key": "" } });
    if (!res.ok) {
      console.warn("[lifi] quote failed:", res.status);
      return null;
    }

    const data = await res.json();
    if (!data.transactionRequest?.to || !data.transactionRequest?.data) {
      console.warn("[lifi] no tx:", data.message?.slice(0, 60));
      return null;
    }

    const tx = data.transactionRequest;
    const amountOut: string = data.estimate?.toAmount ?? "0";

    console.log("[swap] LI.FI OK — tool:", data.tool, "amountOut:", amountOut);
    return {
      target: tx.to,
      data: tx.data,
      value: BigInt(tx.value ?? "0"),
      route: `lifi_${data.tool ?? "unknown"}`,
      amountOut,
      amountOutUsd: parseFloat(data.estimate?.toAmountUSD ?? "0"),
    };
  } catch (e) {
    console.error("[lifi] error:", e instanceof Error ? e.message.slice(0, 100) : e);
    return null;
  }
}

// ─── ERC-20 approval for aggregators that need it (Kyber sell, LiFi sell) ─────

async function ensureApprovalForAggregator(
  token: string,
  spender: string,
  amount: bigint,
  account: SwapAccount,
): Promise<void> {
  await ensureERC20Approval(token, spender, amount, account);
}

// ─── Buy Quote (ETH → Token) ──────────────────────────────────────────────────

export async function getBuyQuote(params: {
  tokenAddress: string;
  buyAmountWei: bigint;
  slippageBps: number;
  senderAddress: string;
}): Promise<SwapQuote | null> {

  // Route 1: Paraswap — solver + aggregator, no API key, best rates on Base
  const decimalsOut = await getTokenDecimals(params.tokenAddress);
  const paraswap = await getParaswapQuote({
    tokenIn: ETH_ADDR,
    tokenOut: params.tokenAddress,
    amountIn: params.buyAmountWei,
    slippageBps: params.slippageBps,
    sender: params.senderAddress,
    decimalsIn: 18,
    decimalsOut,
  });
  if (paraswap) return paraswap;

  // Route 2: KyberSwap — strong on exotic tokens (VIRTUAL-quoted, Clanker)
  const kyber = await getKyberQuote({
    tokenIn: ETH_ADDR,
    tokenOut: params.tokenAddress,
    amountIn: params.buyAmountWei,
    slippageBps: params.slippageBps,
    sender: params.senderAddress,
  });
  if (kyber) return kyber;

  // Route 3: LI.FI — SushiSwap/BaseSwap/Uniswap cross-aggregator fallback
  const lifi = await getLiFiQuote({
    tokenIn: ETH_ADDR,
    tokenOut: params.tokenAddress,
    amountIn: params.buyAmountWei,
    slippageBps: params.slippageBps,
    sender: params.senderAddress,
  });
  if (lifi) return lifi;

  // Route 4: Zora SDK — last resort, specifically for Zora Coins
  try {
    const { createTradeCall } = await import("@zoralabs/coins-sdk");
    const q = await createTradeCall({
      sell: { type: "eth" as const },
      buy: { type: "erc20" as const, address: params.tokenAddress as `0x${string}` },
      amountIn: params.buyAmountWei,
      slippage: params.slippageBps / 10000,
      sender: params.senderAddress as `0x${string}`,
      recipient: params.senderAddress as `0x${string}`,
    });
    if (q.call?.target && q.call?.data) {
      console.log("[swap] Zora SDK buy route");
      return {
        target: q.call.target, data: q.call.data,
        value: BigInt(q.call.value ?? "0"),
        route: "zora", amountOut: "0", amountOutUsd: 0,
      };
    }
  } catch (e) {
    console.error("[swap] Zora buy error:", e instanceof Error ? e.message.slice(0, 80) : e);
  }

  return null;
}

// ─── Sell Quote (Token → ETH) ─────────────────────────────────────────────────

export async function getSellQuote(params: {
  tokenAddress: string;
  sellAmount: bigint;
  slippageBps: number;
  senderAddress: string;
  account: SwapAccount;
}): Promise<SwapQuote | null> {

  // Route 1: Paraswap sell — approve Augustus spender, then swap
  const decimalsToken = await getTokenDecimals(params.tokenAddress);
  const paraswapSell = await getParaswapQuote({
    tokenIn: params.tokenAddress,
    tokenOut: ETH_ADDR,
    amountIn: params.sellAmount,
    slippageBps: params.slippageBps,
    sender: params.senderAddress,
    decimalsIn: decimalsToken,
    decimalsOut: 18,
  });
  if (paraswapSell) {
    // Approve actual router address from response (not hardcoded spender)
    // Paraswap V6 may return different router contracts depending on the route
    await ensureApprovalForAggregator(params.tokenAddress, paraswapSell.target, params.sellAmount, params.account);
    return paraswapSell;
  }

  // Route 2: KyberSwap sell — needs ERC-20 approval for Kyber router
  const kyberSell = await getKyberQuote({
    tokenIn: params.tokenAddress,
    tokenOut: ETH_ADDR,
    amountIn: params.sellAmount,
    slippageBps: params.slippageBps,
    sender: params.senderAddress,
  });
  if (kyberSell) {
    await ensureApprovalForAggregator(params.tokenAddress, kyberSell.target, params.sellAmount, params.account);
    return kyberSell;
  }

  // Route 3: LI.FI sell — needs ERC-20 approval for LiFi router
  const lifiSell = await getLiFiQuote({
    tokenIn: params.tokenAddress,
    tokenOut: ETH_ADDR,
    amountIn: params.sellAmount,
    slippageBps: params.slippageBps,
    sender: params.senderAddress,
  });
  if (lifiSell) {
    await ensureApprovalForAggregator(params.tokenAddress, lifiSell.target, params.sellAmount, params.account);
    return lifiSell;
  }

  // Route 4: Zora SDK sell — last resort
  try {
    const { createTradeCall } = await import("@zoralabs/coins-sdk");
    const initial = await createTradeCall({
      sell: { type: "erc20" as const, address: params.tokenAddress as `0x${string}` },
      buy: { type: "eth" as const },
      amountIn: params.sellAmount,
      slippage: params.slippageBps / 10000,
      sender: params.senderAddress as `0x${string}`,
      recipient: params.senderAddress as `0x${string}`,
    });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const signatures: any[] = [];
    if (initial.permits && initial.permits.length > 0) {
      await ensureERC20Approval(params.tokenAddress, PERMIT2, params.sellAmount, params.account);
      for (const pe of initial.permits) {
        const p = pe.permit;
        const nonceData = "0x927da105" +
          "000000000000000000000000" + params.senderAddress.slice(2).toLowerCase() +
          "000000000000000000000000" + p.details.token.slice(2).toLowerCase() +
          "000000000000000000000000" + p.spender.slice(2).toLowerCase();
        const nonceR = await rpcRead("eth_call", [{ to: PERMIT2, data: nonceData }, "latest"]);
        const hex = nonceR?.replace("0x", "") ?? "";
        const onchainNonce = hex.length >= 192 ? parseInt(hex.slice(128, 192), 16) : 0;
        const sig = await params.account.signTypedData({
          domain: { name: "Permit2", chainId: base.id, verifyingContract: PERMIT2 as `0x${string}` },
          types: {
            PermitDetails: [
              { name: "token", type: "address" }, { name: "amount", type: "uint160" },
              { name: "expiration", type: "uint48" }, { name: "nonce", type: "uint48" },
            ],
            PermitSingle: [
              { name: "details", type: "PermitDetails" }, { name: "spender", type: "address" },
              { name: "sigDeadline", type: "uint256" },
            ],
          },
          primaryType: "PermitSingle",
          message: {
            details: { token: p.details.token as `0x${string}`, amount: BigInt(p.details.amount),
              expiration: Number(p.details.expiration), nonce: onchainNonce },
            spender: p.spender as `0x${string}`,
            sigDeadline: BigInt(p.sigDeadline),
          },
        });
        signatures.push({ signature: sig, permit: {
          details: { token: p.details.token, amount: p.details.amount.toString(),
            expiration: Number(p.details.expiration), nonce: onchainNonce },
          spender: p.spender, sigDeadline: p.sigDeadline.toString(),
        }});
      }
    }
    const clean = await createTradeCall(signatures.length > 0
      ? { sell: { type: "erc20" as const, address: params.tokenAddress as `0x${string}` },
          buy: { type: "eth" as const }, amountIn: params.sellAmount,
          slippage: params.slippageBps / 10000,
          sender: params.senderAddress as `0x${string}`, recipient: params.senderAddress as `0x${string}`,
          signatures }
      : { sell: { type: "erc20" as const, address: params.tokenAddress as `0x${string}` },
          buy: { type: "eth" as const }, amountIn: params.sellAmount,
          slippage: params.slippageBps / 10000,
          sender: params.senderAddress as `0x${string}`, recipient: params.senderAddress as `0x${string}` });
    if (clean.call?.target && clean.call?.data && !clean.call.data.includes("REPLACE_WITH_PERMIT_SIGNATURE_")) {
      console.log("[swap] Zora SDK sell route");
      return { target: clean.call.target, data: clean.call.data,
        value: BigInt(clean.call.value ?? "0"), route: "zora", amountOut: "0", amountOutUsd: 0 };
    }
  } catch (e) {
    console.error("[swap] Zora sell error:", e instanceof Error ? e.message.slice(0, 80) : e);
  }

  return null;
}

// ─── Sign & Send TX ───────────────────────────────────────────────────────────

export async function signAndSend(params: {
  account: SwapAccount;
  to: string;
  data: string;
  value: bigint;
  gasTier?: "slow" | "normal" | "fast"; // default = normal
}): Promise<string> {
  const multiplier = params.gasTier === "slow" ? 1.0 : params.gasTier === "fast" ? 1.5 : 1.2;
  const [nonce, gasPrice] = await Promise.all([getNonce(params.account.address), getGasPrice(multiplier)]);

  let gas: bigint;
  try {
    gas = await estimateGas(params.to, params.data, params.value, params.account.address);
  } catch (e) {
    const msg = e instanceof Error ? e.message.slice(0, 200) : String(e);
    if (msg.toLowerCase().includes("revert") || msg.toLowerCase().includes("execution")) {
      throw new Error(`Swap simulation gagal — token mungkin tidak bisa dibeli via rute ini: ${msg}`);
    }
    console.warn("[swap] estimateGas failed, using fallback gas:", msg);
    gas = BigInt(500000);
  }

  // maxPriorityFeePerGas HARUS <= maxFeePerGas — Base L2 gas sangat murah
  // Pakai 10% dari gasPrice sebagai priority tip, minimum 1000 wei, maximum = gasPrice
  const priorityFee = gasPrice / BigInt(10) < BigInt("1000") ? BigInt("1000") : gasPrice / BigInt(10);
  const maxPriority = priorityFee < gasPrice ? priorityFee : gasPrice;

  const signed = await params.account.signTransaction({
    chainId: base.id,
    to: params.to as `0x${string}`,
    data: params.data as `0x${string}`,
    value: params.value,
    nonce, gas,
    maxFeePerGas: gasPrice,
    maxPriorityFeePerGas: maxPriority,
    type: "eip1559",
  });

  return sendRawTx(signed);
}
