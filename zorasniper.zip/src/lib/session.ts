/**
 * Session management — buat, verifikasi, hapus session token
 * Token: crypto-random 32 byte (64 hex chars), simpan di DB
 * TTL: 30 hari
 */

import { db } from "@/neynar-db-sdk/db";
import { sessionTokens } from "@/db/schema";
import { eq, and, gt } from "drizzle-orm";

const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 hari

export async function createSession(fid: number, email: string): Promise<string> {
  // Generate token acak 32 byte
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const token = Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");

  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);

  // Hapus session lama untuk email ini (max 1 session aktif per email)
  await db.delete(sessionTokens).where(eq(sessionTokens.email, email));

  await db.insert(sessionTokens).values({ token, fid, email, expiresAt });

  return token;
}

export async function verifySession(token: string | null | undefined): Promise<{ fid: number; email: string } | null> {
  if (!token || token.length !== 64) return null;

  const now = new Date();
  const rows = await db
    .select({ fid: sessionTokens.fid, email: sessionTokens.email })
    .from(sessionTokens)
    .where(and(eq(sessionTokens.token, token), gt(sessionTokens.expiresAt, now)))
    .limit(1);

  return rows[0] ?? null;
}

export async function deleteSession(token: string): Promise<void> {
  await db.delete(sessionTokens).where(eq(sessionTokens.token, token));
}

/**
 * Ambil token dari Authorization header: "Bearer <token>"
 */
export function extractBearerToken(request: Request): string | null {
  const auth = request.headers.get("Authorization");
  if (!auth?.startsWith("Bearer ")) return null;
  return auth.slice(7).trim() || null;
}
