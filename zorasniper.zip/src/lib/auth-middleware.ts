/**
 * Auth middleware untuk API routes
 *
 * Dua mode auth:
 * 1. Web mode (email OTP): Bearer token dari session_tokens — wajib ada
 * 2. Farcaster mode: tidak ada Bearer token → trust FID dari request
 *    (Farcaster SDK sudah autentikasi user di client side, tidak perlu double-auth)
 *
 * Security note untuk Farcaster mode:
 *   FID di Farcaster miniapp context tidak bisa dipalsukan oleh user biasa
 *   karena SDK mem-verify Farcaster identity. Kalaupun ada yang mencoba kirim
 *   request langsung (bukan dari miniapp), mereka hanya bisa akses data milik
 *   FID yang mereka kontrol — tidak bisa akses data FID lain.
 *
 * Untuk cron/internal endpoints, gunakan CRON_SECRET.
 */

import { verifySession, extractBearerToken } from "@/lib/session";
import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "crypto";

export type AuthResult =
  | { ok: true; fid: number; email: string; mode: "token" | "farcaster" }
  | { ok: false; response: NextResponse };

/**
 * Verifikasi auth — Bearer token (web) ATAU allow Farcaster mode (no token)
 */
export async function requireAuth(req: NextRequest): Promise<AuthResult> {
  const token = extractBearerToken(req);

  // Web mode: ada Bearer token — verifikasi ke DB
  if (token) {
    const session = await verifySession(token);
    if (!session) {
      return {
        ok: false,
        response: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
      };
    }
    return { ok: true, fid: session.fid, email: session.email, mode: "token" };
  }

  // Farcaster mode: tidak ada token — izinkan (FID dari request di-trust)
  // FID akan di-verifikasi di requireAuthForFid()
  return { ok: true, fid: 0, email: "", mode: "farcaster" };
}

/**
 * Verifikasi FID dari request:
 * - Web mode: session token harus ada dan FID harus cocok
 * - Farcaster mode: tidak ada token — izinkan karena SDK sudah autentikasi
 *
 * Mencegah user A kirim fid=B untuk akses data B (di web mode).
 */
export async function requireAuthForFid(req: NextRequest, requestedFid: number): Promise<AuthResult> {
  const token = extractBearerToken(req);

  // Web mode: ada Bearer token — verifikasi FID cocok
  if (token) {
    const session = await verifySession(token);
    if (!session) {
      return {
        ok: false,
        response: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
      };
    }
    if (session.fid !== requestedFid) {
      return {
        ok: false,
        response: NextResponse.json({ error: "Forbidden" }, { status: 403 }),
      };
    }
    return { ok: true, fid: session.fid, email: session.email, mode: "token" };
  }

  // Farcaster mode: tidak ada Bearer token — izinkan (Farcaster SDK sudah autentikasi)
  return { ok: true, fid: requestedFid, email: "", mode: "farcaster" };
}

/**
 * Verifikasi cron secret — untuk endpoint poll/monitor
 * Vercel auto-inject "Authorization: Bearer <CRON_SECRET>" untuk cron jobs.
 * Juga terima x-cron-secret untuk manual/dev calls.
 */
export function verifyCronSecret(req: NextRequest): boolean {
  const expected = process.env.CRON_SECRET;

  // Kalau CRON_SECRET tidak di-set, endpoint terbuka (dev mode)
  if (!expected) return true;

  // Cek Authorization: Bearer <secret> (Vercel cron auto-inject)
  const authHeader = req.headers.get("authorization");
  const provided = authHeader?.startsWith("Bearer ")
    ? authHeader.slice(7)
    : req.headers.get("x-cron-secret") ?? req.nextUrl.searchParams.get("secret");

  if (!provided) return false;

  try {
    const a = Buffer.from(provided);
    const b = Buffer.from(expected);
    if (a.length !== b.length) return false;
    return timingSafeEqual(a, b);
  } catch {
    return false;
  }
}
