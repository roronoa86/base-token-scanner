import { NextRequest, NextResponse } from "next/server";
import { verifyOtp, getEmailSession } from "@/db/actions/auth-actions";
import { createSession } from "@/lib/session";

export async function POST(req: NextRequest) {
  try {
    const { email, code } = await req.json();

    if (!email || !code) {
      return NextResponse.json({ error: "Email dan kode wajib diisi" }, { status: 400 });
    }

    const emailLower = email.toLowerCase().trim();
    const valid = await verifyOtp(emailLower, String(code).trim());

    if (!valid) {
      return NextResponse.json({ error: "Kode salah atau sudah expired" }, { status: 401 });
    }

    // Ambil FID dari mapping email — sudah terdaftar dari Farcaster
    const session = await getEmailSession(emailLower);
    if (!session?.fid) {
      return NextResponse.json({ error: "Email tidak terdaftar" }, { status: 403 });
    }

    // Buat session token — ini yang akan dipakai untuk auth semua request
    const token = await createSession(session.fid, emailLower);

    return NextResponse.json({ success: true, fid: session.fid, email: emailLower, token });
  } catch (e) {
    console.error("verify-otp error:", e);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
