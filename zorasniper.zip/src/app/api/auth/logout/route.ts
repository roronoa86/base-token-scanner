import { NextRequest, NextResponse } from "next/server";
import { deleteSession, extractBearerToken } from "@/lib/session";

export async function POST(req: NextRequest) {
  const token = extractBearerToken(req);
  if (token) {
    await deleteSession(token).catch(() => {});
  }
  return NextResponse.json({ success: true });
}
