import { NextRequest, NextResponse } from "next/server";
import { db } from "@/neynar-db-sdk/db";
import { emailSessions } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const fid = req.nextUrl.searchParams.get("fid");
  if (!fid) return NextResponse.json({ email: null });

  try {
    const rows = await db
      .select({ email: emailSessions.email })
      .from(emailSessions)
      .where(eq(emailSessions.fid, Number(fid)))
      .limit(1);

    return NextResponse.json({ email: rows[0]?.email ?? null });
  } catch {
    return NextResponse.json({ email: null });
  }
}
