import { NextRequest, NextResponse } from "next/server";
import { createOtp, verifyOtp, upsertEmailSession, getEmailSession } from "@/db/actions/auth-actions";

const RESEND_KEY = process.env.RESEND_API_KEY;

export async function POST(req: NextRequest) {
  try {
    const { fid, email, code, step } = await req.json();

    if (!fid || !email) {
      return NextResponse.json({ error: "FID dan email wajib diisi" }, { status: 400 });
    }

    const emailLower = email.toLowerCase().trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailLower)) {
      return NextResponse.json({ error: "Format email tidak valid" }, { status: 400 });
    }

    // Cek apakah email sudah dipakai FID lain
    const existing = await getEmailSession(emailLower);
    if (existing && existing.fid !== Number(fid)) {
      return NextResponse.json(
        { error: "Email ini sudah digunakan akun lain" },
        { status: 409 }
      );
    }

    if (step === "send") {
      if (!RESEND_KEY) {
        console.error("RESEND_API_KEY not configured");
        return NextResponse.json({ error: "Email service tidak dikonfigurasi" }, { status: 503 });
      }

      // Kirim OTP ke email
      const otp = await createOtp(emailLower);

      const emailRes = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${RESEND_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: "Zora Sniper <onboarding@resend.dev>",
          to: [emailLower],
          subject: "Verifikasi email Zora Sniper",
          html: `
            <div style="font-family:sans-serif;max-width:400px;margin:0 auto;padding:32px;background:#0a0f1e;color:#fff;border-radius:16px;">
              <div style="text-align:center;margin-bottom:24px;">
                <div style="font-size:48px;">&#127919;</div>
                <h1 style="font-size:22px;font-weight:900;color:#fff;margin:8px 0 4px;">Zora Sniper</h1>
              </div>
              <p style="color:#a0b4d0;font-size:13px;margin:0 0 16px;">Verifikasi email untuk akses web browser:</p>
              <div style="background:rgba(0,82,255,0.12);border:1px solid rgba(0,82,255,0.3);border-radius:12px;padding:24px;text-align:center;margin-bottom:20px;">
                <div style="font-size:40px;font-weight:900;letter-spacing:8px;color:#fff;">${otp}</div>
                <p style="color:#6b9fff;font-size:11px;margin:12px 0 0;">Berlaku 10 menit</p>
              </div>
              <p style="color:#4a5568;font-size:11px;text-align:center;">Kalau kamu tidak meminta ini, abaikan email ini.</p>
            </div>
          `,
        }),
      });

      if (!emailRes.ok) {
        return NextResponse.json({ error: "Gagal mengirim email" }, { status: 500 });
      }

      return NextResponse.json({ success: true });
    }

    if (step === "verify") {
      if (!code) {
        return NextResponse.json({ error: "Kode OTP wajib diisi" }, { status: 400 });
      }

      const valid = await verifyOtp(emailLower, String(code).trim());
      if (!valid) {
        return NextResponse.json({ error: "Kode salah atau sudah expired" }, { status: 401 });
      }

      // Tautkan email ke FID
      await upsertEmailSession(emailLower, Number(fid));

      return NextResponse.json({ success: true, email: emailLower });
    }

    return NextResponse.json({ error: "Step tidak valid" }, { status: 400 });
  } catch (e) {
    console.error("link-email error:", e);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
