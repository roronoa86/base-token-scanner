import { NextResponse } from "next/server";
import { db } from "@/neynar-db-sdk/db";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    // Buat tabel email_sessions kalau belum ada
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS email_sessions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        email TEXT NOT NULL UNIQUE,
        fid INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    // Buat tabel otp_codes kalau belum ada
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS otp_codes (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        email TEXT NOT NULL,
        code TEXT NOT NULL,
        expires_at TIMESTAMP NOT NULL,
        used BOOLEAN DEFAULT FALSE NOT NULL,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    return NextResponse.json({ success: true, message: "Tabel berhasil dibuat" });
  } catch (e) {
    console.error("setup error:", e);
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
