import { NextRequest, NextResponse } from "next/server";
import { createOtp, getEmailSession } from "@/db/actions/auth-actions";

const RESEND_KEY = process.env.RESEND_API_KEY;

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json();

    if (!email || typeof email !== "string") {
      return NextResponse.json({ error: "Email tidak valid" }, { status: 400 });
    }

    const emailLower = email.toLowerCase().trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailLower)) {
      return NextResponse.json({ error: "Format email tidak valid" }, { status: 400 });
    }

    // Hanya email yang sudah ditautkan dari Farcaster yang boleh login
    const existing = await getEmailSession(emailLower);
    if (!existing) {
      return NextResponse.json(
        { error: "Email belum terdaftar. Buka app di Farcaster dan tautkan email kamu dulu.", notRegistered: true },
        { status: 403 }
      );
    }

    if (!RESEND_KEY) {
      console.error("RESEND_API_KEY not configured");
      return NextResponse.json({ error: "Email service tidak dikonfigurasi" }, { status: 503 });
    }

    const code = await createOtp(emailLower);

    const emailRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Zora Sniper <onboarding@resend.dev>",
        to: [emailLower],
        subject: "Kode login Zora Sniper",
        html: `
          <div style="font-family:sans-serif;max-width:400px;margin:0 auto;padding:32px;background:#0a0f1e;color:#fff;border-radius:16px;">
            <div style="text-align:center;margin-bottom:24px;">
              <div style="font-size:48px;">&#127919;</div>
              <h1 style="font-size:22px;font-weight:900;color:#fff;margin:8px 0 4px;">Zora Sniper</h1>
              <p style="color:#6b9fff;font-size:12px;font-weight:700;letter-spacing:2px;text-transform:uppercase;margin:0;">on Base</p>
            </div>
            <div style="background:rgba(0,82,255,0.12);border:1px solid rgba(0,82,255,0.3);border-radius:12px;padding:24px;text-align:center;margin-bottom:20px;">
              <p style="color:#a0b4d0;font-size:13px;margin:0 0 12px;">Kode login kamu:</p>
              <div style="font-size:40px;font-weight:900;letter-spacing:8px;color:#fff;">${code}</div>
              <p style="color:#6b9fff;font-size:11px;margin:12px 0 0;">Berlaku 10 menit</p>
            </div>
            <p style="color:#4a5568;font-size:11px;text-align:center;margin:0;">
              Kalau kamu tidak meminta kode ini, abaikan email ini.
            </p>
          </div>
        `,
      }),
    });

    if (!emailRes.ok) {
      const err = await emailRes.text();
      console.error("Resend error:", err);
      return NextResponse.json({ error: "Gagal mengirim email" }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("send-otp error:", e);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
