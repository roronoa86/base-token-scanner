import { NextRequest } from "next/server";
import { publicConfig } from "@/config/public-config";
import { getShareImageResponse } from "@/neynar-farcaster-sdk/nextjs";

// Cache for 1 hour - query strings create separate cache entries
export const revalidate = 3600;

const { appEnv, heroImageUrl, imageUrl } = publicConfig;

const showDevWarning = appEnv !== "production";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ type: string }> },
) {
  const { type } = await params;

  return getShareImageResponse(
    { type, heroImageUrl, imageUrl, showDevWarning },
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "flex-end",
        width: "100%",
        height: "100%",
        padding: 48,
        backgroundImage: "linear-gradient(160deg, #080d1a 0%, #0d1630 60%, #080d1a 100%)",
      }}
    >
      {/* Blue accent top border strip */}
      <div
        style={{
          display: "flex",
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          height: 4,
          backgroundImage: "linear-gradient(90deg, #0052FF 0%, #00d4ff 100%)",
        }}
      />

      {/* Card */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 16,
          backgroundColor: "rgba(13, 22, 48, 0.92)",
          borderRadius: 20,
          padding: "32px 40px",
          border: "1px solid rgba(0, 82, 255, 0.35)",
          boxShadow: "0 0 40px rgba(0, 82, 255, 0.2), 0 8px 32px rgba(0, 0, 0, 0.6)",
        }}
      >
        {/* Title row */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 16,
          }}
        >
          <div
            style={{
              display: "flex",
              fontSize: 52,
              fontWeight: "bold",
              color: "white",
              letterSpacing: -1,
            }}
          >
            🎯 ZORA SNIPER
          </div>
        </div>

        {/* Blue accent divider */}
        <div
          style={{
            display: "flex",
            height: 2,
            width: 80,
            backgroundColor: "#0052FF",
            borderRadius: 2,
          }}
        />

        {/* Subtitle */}
        <div
          style={{
            display: "flex",
            fontSize: 24,
            color: "rgba(168, 184, 216, 0.9)",
            fontWeight: 400,
            letterSpacing: 0.5,
          }}
        >
          Auto-snipe new Zora Coins on Base
        </div>

        {/* Tagline */}
        <div
          style={{
            display: "flex",
            fontSize: 20,
            fontWeight: "bold",
            color: "#00d4ff",
            textTransform: "uppercase",
            letterSpacing: 3,
          }}
        >
          Be first. Every time.
        </div>
      </div>
    </div>,
  );
}
