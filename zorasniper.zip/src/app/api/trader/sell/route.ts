/**
 * POST /api/trader/sell  { fid, positionId }
 * Manual market sell — full token balance at market price.
 *
 * Routing: Paraswap → KyberSwap → LI.FI → Zora SDK
 * MEV Protection: Flashbots Protect RPC
 */
import { NextRequest, NextResponse } from "next/server";
import { privateKeyToAccount } from "viem/accounts";
import { decrypt, isEncrypted } from "@/lib/crypto";
import { getSniperSettings } from "@/db/actions/sniper-actions";
import { getPositionById, closePosition } from "@/db/actions/trader-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";
import {
  getSellQuote,
  signAndSend,
  waitReceipt,
  getTokenBalance,
  getTokenDecimals,
  rawBalanceToFloat,
  parseEthReceived,
} from "@/lib/swap-engine";

export async function POST(request: NextRequest) {
  try {
    const { fid, positionId, confirmLoss = false } = await request.json();
    if (!fid || !positionId) {
      return NextResponse.json({ error: "fid dan positionId wajib" }, { status: 400 });
    }

    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    const position = await getPositionById(positionId);
    if (!position || position.fid !== fid) {
      return NextResponse.json({ error: "Posisi tidak ditemukan" }, { status: 404 });
    }
    if (position.status !== "active") {
      return NextResponse.json({ error: `Posisi tidak aktif (status: ${position.status})` }, { status: 400 });
    }

    const settings = await getSniperSettings(fid);
    if (!settings?.privateKeyEncrypted) {
      return NextResponse.json({ error: "Private key belum diset" }, { status: 400 });
    }

    const rawKey = isEncrypted(settings.privateKeyEncrypted)
      ? await decrypt(settings.privateKeyEncrypted)
      : settings.privateKeyEncrypted;
    const pk = (rawKey.startsWith("0x") ? rawKey : "0x" + rawKey) as `0x${string}`;
    const account = privateKeyToAccount(pk);

    const balance = await getTokenBalance(position.tokenAddress, account.address);
    if (balance === BigInt(0)) {
      await closePosition(positionId, {
        sellTxHash: position.sellTxHash ?? "0x0000000000000000000000000000000000000000000000000000000000000000",
        sellPriceUsd: "0",
        sellAmountEth: position.buyAmountEth,
        pnlEth: "0",
        pnlPct: "0",
        closeReason: "manual_sell",
      });
      return NextResponse.json({ success: true, status: "already_sold", message: "Token sudah terjual, posisi ditutup" });
    }

    // Sell exactly the amount received at buy (or full balance if not recorded)
    let sellAmount: bigint;
    if (position.tokensReceived) {
      try {
        const recorded = BigInt(position.tokensReceived);
        sellAmount = recorded < balance ? recorded : balance;
      } catch { sellAmount = balance; }
    } else {
      sellAmount = balance;
    }

    const slippageBps = settings.slippageBps ?? 500;
    const quote = await getSellQuote({
      tokenAddress: position.tokenAddress,
      sellAmount,
      slippageBps,
      senderAddress: account.address,
      account,
    });

    if (!quote) {
      return NextResponse.json({ error: "Tidak ada quote untuk sell token ini" }, { status: 400 });
    }

    // ── Loss protection: block accidental sell at a loss ─────────────────────
    // Require confirmLoss=true before executing any sell at a loss.
    // Source priority for loss estimate:
    //   1. Aggregator amountOut (wei) — exact if Paraswap/Kyber was used as route
    //   2. DexScreener price vs buyPriceUsd from DB — reliable fallback (always works)
    // Auto-sells via monitor cron (TP/SL) always pass confirmLoss=true implicitly.
    if (!confirmLoss) {
      const buyEthSpent = parseFloat(position.buyAmountEth);
      let lossPct: number | null = null;
      let lossEth: number | null = null;

      // Method 1: Aggregator quote returned exact amountOut in wei (ETH received)
      // Paraswap & Kyber return real amountOut. LI.FI & Zora set amountOut="0" — skip.
      const hasExactOut = quote.amountOut !== "0" && quote.route !== "zora";
      if (hasExactOut) {
        const estimatedOutEth = parseFloat(quote.amountOut) / 1e18;
        if (estimatedOutEth > 0 && buyEthSpent > 0 && estimatedOutEth < buyEthSpent) {
          lossEth = buyEthSpent - estimatedOutEth;
          lossPct = (lossEth / buyEthSpent) * 100;
        }
      }

      // Method 2: DexScreener price vs DB buyPriceUsd — works for all routes
      if (lossPct === null && position.buyPriceUsd) {
        try {
          const priceRes = await fetch(
            `https://api.dexscreener.com/latest/dex/tokens/${position.tokenAddress}`,
            { next: { revalidate: 0 } },
          );
          const priceData = await priceRes.json();
          const pairs = (priceData.pairs ?? []).filter((p: { chainId?: string }) => p.chainId === "base");
          if (pairs.length > 0) {
            const best = (pairs as Array<{ liquidity?: { usd?: number }; priceUsd?: string }>)
              .sort((a, b) => (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0))[0];
            const currentPriceUsd = parseFloat(best.priceUsd ?? "0");
            const buyPriceUsd = parseFloat(position.buyPriceUsd);
            if (currentPriceUsd > 0 && buyPriceUsd > 0 && currentPriceUsd < buyPriceUsd) {
              lossPct = ((buyPriceUsd - currentPriceUsd) / buyPriceUsd) * 100;
            }
          }
        } catch { /* best-effort — if price fetch fails, allow sell */ }
      }

      if (lossPct !== null && lossPct > 0) {
        return NextResponse.json({
          error: `Posisi sedang rugi ${lossPct.toFixed(1)}%${lossEth !== null ? ` (~${lossEth.toFixed(6)} ETH)` : ""}. Kirim confirmLoss=true untuk konfirmasi cut loss.`,
          lossConfirmRequired: true,
          lossPct: lossPct.toFixed(2),
          ...(lossEth !== null && { lossEth: lossEth.toFixed(6) }),
        }, { status: 422 });
      }
    }

    let txHash: string;
    try {
      txHash = await signAndSend({ account, to: quote.target, data: quote.data, value: quote.value });
    } catch (e) {
      const msg = e instanceof Error ? e.message.slice(0, 200) : "TX send failed";
      return NextResponse.json({ error: msg }, { status: 500 });
    }

    console.log("[sell] TX sent:", txHash, "route:", quote.route);

    const receipt = await waitReceipt(txHash, 45000);
    if (!receipt) {
      return NextResponse.json({ success: true, txHash, status: "pending", route: quote.route });
    }
    if (receipt.status === "0x0") {
      return NextResponse.json({ error: "Sell TX reverted on-chain", txHash }, { status: 500 });
    }

    // ── Accurate PnL from receipt ─────────────────────────────────────────────
    const ethReceived = parseEthReceived(receipt, account.address);
    const buyEthSpent = parseFloat(position.buyAmountEth);

    let sellPriceUsd = "0";
    let pnlEth = "0";
    let pnlPct = "0";
    let sellAmountEth = position.buyAmountEth;

    // Get current token price for reference
    try {
      const priceRes = await fetch(
        `https://api.dexscreener.com/latest/dex/tokens/${position.tokenAddress}`,
        { next: { revalidate: 0 } },
      );
      const priceData = await priceRes.json();
      const pairs = (priceData.pairs ?? []).filter((p: { chainId?: string }) => p.chainId === "base");
      if (pairs.length > 0) {
        const best = pairs.sort((a: { liquidity?: { usd?: number } }, b: { liquidity?: { usd?: number } }) =>
          (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0))[0];
        sellPriceUsd = (best as { priceUsd?: string }).priceUsd ?? "0";
      }
    } catch { /* best-effort */ }

    if (ethReceived !== null && ethReceived > 0) {
      sellAmountEth = ethReceived.toFixed(8);
      const pnlEthNum = ethReceived - buyEthSpent;
      pnlEth = pnlEthNum.toFixed(8);
      pnlPct = buyEthSpent > 0 ? ((pnlEthNum / buyEthSpent) * 100).toFixed(2) : "0";
    } else {
      // Fallback: estimate from price if receipt parse failed
      // Use actual token decimals (not hardcoded 1e18) — safe for 6-decimal tokens too
      const tokenDecimals = await getTokenDecimals(position.tokenAddress);
      const tokensFloat = (() => {
        try {
          return rawBalanceToFloat(BigInt(sellAmount.toString()), tokenDecimals);
        } catch { return rawBalanceToFloat(balance, tokenDecimals); }
      })();
      const bestPair = await fetch(
        `https://api.dexscreener.com/latest/dex/tokens/${position.tokenAddress}`,
        { next: { revalidate: 0 } },
      ).then(r => r.json()).catch(() => null);
      if (bestPair?.pairs?.length) {
        const ETH_SYMS = ["ETH", "WETH"];
        const sorted = [...bestPair.pairs]
          .filter((p: { chainId?: string }) => p.chainId === "base")
          .sort((a: { liquidity?: { usd?: number } }, b: { liquidity?: { usd?: number } }) =>
            (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0));
        // Only use priceNative if best ETH/WETH pair with ≥$5K liquidity exists
        // For tokens quoted in USDC/VIRTUAL, priceNative would be wrong
        const ethPair = sorted.find((p: { quoteToken?: { symbol?: string }; liquidity?: { usd?: number } }) =>
          ETH_SYMS.includes((p.quoteToken?.symbol ?? "").toUpperCase()) &&
          (p.liquidity?.usd ?? 0) >= 5000
        );
        const priceNative = ethPair
          ? parseFloat((ethPair as { priceNative?: string }).priceNative ?? "0")
          : 0;
        if (priceNative > 0 && tokensFloat > 0) {
          const sellEth = priceNative * tokensFloat;
          sellAmountEth = sellEth.toFixed(8);
          const pnlEthNum = sellEth - buyEthSpent;
          pnlEth = pnlEthNum.toFixed(8);
          pnlPct = buyEthSpent > 0 ? ((pnlEthNum / buyEthSpent) * 100).toFixed(2) : "0";
        }
      }
    }

    await closePosition(positionId, {
      sellTxHash: txHash,
      sellPriceUsd,
      sellAmountEth,
      pnlEth,
      pnlPct,
      closeReason: "manual_sell",
    });

    return NextResponse.json({ success: true, txHash, status: receipt.status, route: quote.route, pnlPct });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message.slice(0, 300) : "Unknown" }, { status: 500 });
  }
}
