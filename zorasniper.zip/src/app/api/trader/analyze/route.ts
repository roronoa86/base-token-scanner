/**
 * GET /api/trader/analyze?address=0x...
 *
 * Full token security analysis — combines ALL available data sources:
 *   1. GoPlus Security API  — honeypot, buy/sell tax, contract risks, LP holders
 *   2. Zora Coin onchain fingerprint — EIP-1167 proxy + 1B supply (100% reliable)
 *   3. DexScreener — pairs, liquidity, DEX list, pool type labels
 *   4. Clanker detection — 2-layer: factory address + locker address
 *
 * V4 Pool Fix:
 *   Uniswap V4 uses singleton PoolManager — no LP ERC-20/ERC-721 tokens exist.
 *   GoPlus cannot detect LP holders for V4 pools. When a token's only pool is V4
 *   and GoPlus returns empty lp_holders, we treat it as UNLOCKED (not "unverified"),
 *   because there is no on-chain mechanism to verify a lock exists.
 *
 * Clanker Detection (2-layer, any one signal = confirmed Clanker):
 *   Layer 1 — Factory: GoPlus creator_address matches a known Clanker factory address
 *   Layer 2 — Locker:  Any LP holder address matches a known Clanker protocol locker
 *             (GoPlus returns the Clanker locker contract as LP holder for all v4 tokens)
 *
 *   Verified from Clanker's registry (691k+ tokens sampled):
 *   - Active factory: 0xE85A59c628F7d27878ACeB4bf3b35733630083a9
 *   - Active locker:  0x63D2DfEA64b3433F4071A98665bcD7Ca14d93496
 *   The locker-based detection is the most reliable signal since GoPlus always
 *   returns it as the LP holder, regardless of whether creator_address is present.
 */
import { NextRequest, NextResponse } from "next/server";

const BASE_RPC = process.env.BASE_RPC_URL ?? "https://base-rpc.publicnode.com";

// --- Zora Coin fingerprint ---------------------------------------------------
const ZORA_EIP1167_PREFIX = "363d3d373d3d3d363d73";
const ZORA_SUPPLY_BIG     = BigInt("1000000000") * (10n ** 18n);

// --- Clanker detection -------------------------------------------------------
// ALL verified Clanker factory addresses on Base.
// Source: live data from api.clanker.world (691k+ tokens sampled).
const CLANKER_FACTORIES = new Set([
  // v1 (legacy)
  "0x250c9fb2b411b48c74a76e1e05adb7e857ae4a44",
  // v2 (legacy)
  "0x1bc488e09e94af4f3b42c13826a50c47f8a2bbef",
  // v4 — the ONLY active factory as of 2025-2026 (all 691k+ tokens use this)
  "0xe85a59c628f7d27878aceb4bf3b35733630083a9",
]);

// ALL verified Clanker protocol locker addresses on Base.
// These appear as LP holders in GoPlus data — if ANY LP holder is this address,
// the token is Clanker protocol-locked regardless of is_locked flag.
const CLANKER_LOCKERS = new Set([
  // v4 locker — used by ALL active Clanker v4 tokens
  "0x63d2dfea64b3433f4071a98665bcd7ca14d93496",
]);

async function rpcCall(method: string, params: unknown[]): Promise<string | null> {
  try {
    const res = await fetch(BASE_RPC, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", method, params, id: 1 }),
    });
    const d = await res.json();
    return d.error ? null : (d.result as string);
  } catch { return null; }
}

async function isZoraCoin(address: string): Promise<boolean> {
  try {
    const [bytecode, supplyHex, decimalsHex] = await Promise.all([
      rpcCall("eth_getCode", [address, "latest"]),
      rpcCall("eth_call", [{ to: address, data: "0x18160ddd" }, "latest"]),
      rpcCall("eth_call", [{ to: address, data: "0x313ce567" }, "latest"]),
    ]);
    const code = (bytecode ?? "").toLowerCase().replace("0x", "");
    if (!code.startsWith(ZORA_EIP1167_PREFIX) || code.length !== 90) return false;
    if (!supplyHex || supplyHex === "0x") return false;
    if (BigInt(supplyHex) !== ZORA_SUPPLY_BIG) return false;
    if (!decimalsHex || decimalsHex === "0x") return false;
    if (parseInt(decimalsHex, 16) !== 18) return false;

    // Validate impl contract size — Zora Coin impls are ~19,049 or ~19,118 bytes.
    // Other protocols (e.g. SUPPOK at 13,804 bytes) also use EIP-1167 + 1B supply,
    // so we must confirm the impl is actually the Zora Coin implementation.
    const implAddr = "0x" + code.slice(20, 60);
    const implCode = await rpcCall("eth_getCode", [implAddr, "latest"]);
    const implSize = implCode ? (implCode.length - 2) / 2 : 0;
    if (implSize < 18800 || implSize > 19400) return false;

    return true;
  } catch { return false; }
}

// --- Onchain helpers ---------------------------------------------------------

async function isContract(address: string): Promise<boolean> {
  try {
    const code = await rpcCall("eth_getCode", [address, "latest"]);
    return !!code && code !== "0x" && code.length > 4;
  } catch { return false; }
}

// ALL known Position Manager / NonfungiblePositionManager contracts on Base
// that issue NFT LP positions (ERC-721 ownerOf interface).
// Uniswap V3 and any fork that uses the same NFT position model.
const NFT_POSITION_MANAGERS = [
  "0x03a520b32C04BF3bEEf7BEb72E919cf822Ed34f1", // Uniswap V3 on Base
  "0x827922686190790b37229fd06084350E74485b72", // PancakeSwap V3 on Base
  "0xDe151D5c92BfAA288Db4B67c21CD55d5826bCc93", // SushiSwap V3 on Base
];

// CONSERVATIVE APPROACH: We do NOT maintain a list of "known locker" addresses.
// Reason: locker addresses are hard to verify onchain — fabricated addresses cause
// false "SAFE" ratings which is far more dangerous than false "UNVERIFIED" ratings.
//
// Instead, we rely solely on GoPlus is_locked=1 flag (which GoPlus verifies via
// their own locker database) for the "locked" verdict.
//
// For ERC-20 LP tokens (Uniswap V2, Aerodrome, BaseSwap, etc.):
//   - GoPlus returns LP holder with is_locked=1 if it detects a known locker contract
//   - If holder is a contract but GoPlus doesn't confirm lock → "unknown_contract" = unverified
//   - If holder is an EOA → "eoa" = unlocked (dev can withdraw)
//
// For NFT LP positions (Uniswap V3 style):
//   - We query ownerOf(tokenId) from known NPM contracts
//   - Then check if owner is contract or EOA

async function getNftOwner(nftId: string): Promise<string | null> {
  // Try all known position managers — return first non-null result
  const tokenHex = BigInt(nftId).toString(16).padStart(64, "0");
  for (const npm of NFT_POSITION_MANAGERS) {
    try {
      const result = await rpcCall("eth_call", [
        { to: npm, data: `0x6352211e${tokenHex}` },
        "latest",
      ]);
      if (result && result !== "0x" && result.length >= 42) {
        return "0x" + result.slice(-40);
      }
    } catch { /* try next */ }
  }
  return null;
}

// Returns: "unknown_contract" | "eoa" | null (error/not found)
// We no longer distinguish "known_locker" — GoPlus is_locked=1 is the only trusted source.
async function classifyNftOwner(nftId: string): Promise<"unknown_contract" | "eoa" | null> {
  try {
    const owner = await getNftOwner(nftId);
    if (!owner) return null;
    const isC = await isContract(owner);
    return isC ? "unknown_contract" : "eoa";
  } catch { return null; }
}

// For ERC-20 LP holders (V2, Aerodrome, Curve, BaseSwap, etc.) — no NFT_list
// Just check if the holder address is a contract or EOA.
async function classifyErc20LpHolder(address: string): Promise<"unknown_contract" | "eoa"> {
  try {
    const isC = await isContract(address);
    return isC ? "unknown_contract" : "eoa";
  } catch { return "eoa"; }
}

// --- GoPlus Security API -----------------------------------------------------
interface GoPlusData {
  is_honeypot?: string;
  buy_tax?: string;
  sell_tax?: string;
  is_open_source?: string;
  is_proxy?: string;
  is_mintable?: string;
  can_take_back_ownership?: string;
  owner_change_balance?: string;
  hidden_owner?: string;
  selfdestruct?: string;
  external_call?: string;
  is_blacklisted?: string;
  is_whitelisted?: string;
  is_anti_whale?: string;
  trading_cooldown?: string;
  transfer_pausable?: string;
  owner_address?: string;
  creator_address?: string;
  holder_count?: string;
  lp_holder_count?: string;
  lp_total_supply?: string;
  holders?: Array<{
    address: string; tag?: string; is_contract?: number;
    balance?: string; percent?: string; is_locked?: number;
  }>;
  lp_holders?: Array<{
    address: string; tag?: string; value?: string; is_contract?: number;
    balance?: string; percent?: string; is_locked?: number;
    NFT_list?: Array<{ NFT_id?: string; amount?: string; value?: string; in_effect?: string; NFT_percentage?: string }>;
  }>;
}

async function fetchGoPlus(address: string): Promise<GoPlusData | null> {
  try {
    const res = await fetch(
      `https://api.gopluslabs.io/api/v1/token_security/8453?contract_addresses=${address}`,
      { next: { revalidate: 0 } }
    );
    const d = await res.json();
    const vals = Object.values(d?.result ?? {});
    return vals.length ? (vals[0] as GoPlusData) : null;
  } catch { return null; }
}

// --- DexScreener -------------------------------------------------------------
interface DexPair {
  pairAddress?: string; dexId?: string; labels?: string[];
  quoteToken?: { symbol?: string; address?: string };
  liquidity?: { usd?: number };
  priceUsd?: string; priceNative?: string;
  volume?: { h24?: number; h6?: number; h1?: number; m5?: number };
  txns?: { h24?: { buys?: number; sells?: number } };
  pairCreatedAt?: number;
}

async function fetchDexScreener(address: string): Promise<DexPair[]> {
  try {
    const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${address}`, { next: { revalidate: 0 } });
    const d = await res.json();
    return ((d.pairs ?? []) as DexPair[]).filter(p => (p as { chainId?: string }).chainId === "base");
  } catch { return []; }
}

// --- Main Handler ------------------------------------------------------------
export async function GET(request: NextRequest) {
  const address = request.nextUrl.searchParams.get("address")?.toLowerCase();
  if (!address || !/^0x[0-9a-f]{40}$/.test(address)) {
    return NextResponse.json({ error: "address tidak valid" }, { status: 400 });
  }

  const [zoraCoin, gp, dexPairs] = await Promise.all([
    isZoraCoin(address),
    fetchGoPlus(address),
    fetchDexScreener(address),
  ]);

  // Platform detection — 2-layer Clanker check (any one = confirmed Clanker)
  const creatorLower = (gp?.creator_address ?? "").toLowerCase();
  const lpHoldersRaw = gp?.lp_holders ?? [];

  // Layer 1: GoPlus creator_address matches a known Clanker factory address
  const isClankerByFactory = creatorLower ? CLANKER_FACTORIES.has(creatorLower) : false;

  // Layer 2: Any LP holder is a known Clanker protocol locker
  // GoPlus returns the Clanker locker contract (0x63d2...) as the LP holder for ALL Clanker v4 tokens.
  // This is the PRIMARY signal since creator_address is often missing or is a user wallet (not factory).
  const isClankerByLocker = lpHoldersRaw.some(
    h => CLANKER_LOCKERS.has((h.address ?? "").toLowerCase())
  );

  const isClanker  = isClankerByFactory || isClankerByLocker;
  const isProtocol = zoraCoin || isClanker;
  const platform   = zoraCoin ? "Zora Coins" : isClanker ? "Clanker" : "Other";

  // Clanker locker address detected for this token (for UI display)
  const clankerLockerAddr = isClankerByLocker
    ? lpHoldersRaw.find(h => CLANKER_LOCKERS.has((h.address ?? "").toLowerCase()))?.address
    : undefined;

  // Pool type detection via DexScreener labels
  // V4 = Uniswap V4 PoolManager (singleton) — GoPlus completely blind to LP holders
  const sortedPairs    = [...dexPairs].sort((a, b) => (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0));
  const hasV4Pool      = sortedPairs.some(p => (p.labels ?? []).map(l => l.toLowerCase()).includes("v4"));
  const hasV3Pool      = sortedPairs.some(p => (p.labels ?? []).map(l => l.toLowerCase()).includes("v3"));
  const onlyV4         = hasV4Pool && !hasV3Pool; // GoPlus LP data completely blind for these
  const totalLiquidity = sortedPairs.reduce((s, p) => s + (p.liquidity?.usd ?? 0), 0);

  // Token age (from earliest pair creation timestamp)
  const pairCreatedAt = sortedPairs.reduce<number | null>((min, p) => {
    const ts = p.pairCreatedAt ?? null;
    if (ts === null) return min;
    return min === null ? ts : Math.min(min, ts);
  }, null);
  const tokenAgeMs = pairCreatedAt ? Date.now() - pairCreatedAt : null;
  const tokenAgeH  = tokenAgeMs ? tokenAgeMs / 1000 / 3600 : null;
  const isNewToken = tokenAgeH !== null && tokenAgeH < 24;

  // Volume pattern: pump & dump signal = high 6h vol but zero 1h vol
  const vol1h  = sortedPairs.reduce((s, p) => s + (p.volume?.h1  ?? 0), 0);
  const vol6h  = sortedPairs.reduce((s, p) => s + (p.volume?.h6  ?? 0), 0);
  const vol24h = sortedPairs.reduce((s, p) => s + (p.volume?.h24 ?? 0), 0);
  const volumeDead   = vol6h > 500 && vol1h === 0;
  const pumpDumpFlag = volumeDead && isNewToken;

  // LP holders from GoPlus
  // Note: lpHoldersRaw is already declared above for Clanker locker detection
  const lpHolders     = lpHoldersRaw;
  const lpTotalSupply = parseFloat(gp?.lp_total_supply ?? "0");

  // Detect LP position type:
  // - NFT positions (Uniswap V3 style): GoPlus returns NFT_list with NFT_id
  // - ERC-20 LP tokens (V2, Aerodrome, BaseSwap, Curve, etc.): GoPlus returns balance/percent only
  const hasNftPositions = lpHolders.some(h => (h.NFT_list?.length ?? 0) > 0);
  const hasErc20Lp      = lpHolders.some(h => (h.NFT_list?.length ?? 0) === 0 && h.percent);

  const goplusLockedPct = lpHolders
    .filter(h => h.is_locked === 1)
    .reduce((s, h) => s + parseFloat(h.percent ?? "0") * 100, 0);

  // Onchain classification for ALL LP holders:
  // "goplus"           = GoPlus is_locked=1 — trusted, verified by GoPlus locker database
  // "unknown_contract" = contract holder but NOT GoPlus-verified — treat as UNVERIFIED
  //                      (could be a locker, could be admin-withdrawable — we don't know)
  // "eoa"              = regular wallet — dev can withdraw anytime = UNLOCKED
  // "none"             = classification skipped (protocol token)
  let onchainUnknownContractPct = 0;
  let onchainEoaPct = 0;
  type NftClass = "unknown_contract" | "eoa" | "goplus" | "none";
  const holderNftClass: NftClass[] = new Array(lpHolders.length).fill("none");

  if (!isProtocol && lpHolders.length > 0) {
    const checks = await Promise.all(
      lpHolders.map(async (h): Promise<NftClass> => {
        // GoPlus already verified this is locked — trust it
        if (h.is_locked === 1) return "goplus";

        const nftIds = (h.NFT_list ?? []).map(n => n.NFT_id).filter(Boolean) as string[];

        if (nftIds.length > 0) {
          // NFT position (V3-style): query ownerOf from all known NPMs
          const cls = await classifyNftOwner(nftIds[0]);
          return cls ?? "eoa"; // if lookup fails, conservative = eoa (unlocked)
        } else if (h.percent) {
          // ERC-20 LP token (V2, Aerodrome, BaseSwap, Curve, etc.)
          // Check if holder is a contract — if so, mark unverified (might be a locker GoPlus missed)
          return await classifyErc20LpHolder(h.address);
        }
        return "none";
      })
    );

    checks.forEach((cls, i) => { holderNftClass[i] = cls; });

    onchainUnknownContractPct = lpHolders.reduce((s, h, i) => {
      return holderNftClass[i] === "unknown_contract" ? s + parseFloat(h.percent ?? "0") * 100 : s;
    }, 0);
    onchainEoaPct = lpHolders.reduce((s, h, i) => {
      return holderNftClass[i] === "eoa" ? s + parseFloat(h.percent ?? "0") * 100 : s;
    }, 0);
  }

  // Only GoPlus is_locked=1 counts as verified locked — no guessing from onchain
  const lpLockedPct = goplusLockedPct;

  // Lock status logic
  // Single source of truth for "locked": GoPlus is_locked=1 flag.
  // Onchain contract check is supplementary info only (unknown_contract = unverified).
  type LockStatus = "protocol" | "locked" | "partial" | "unlocked" | "unverified";
  let lockStatus: LockStatus;
  let lockDetail: string;

  if (isProtocol) {
    // Zora Coins & Clanker: LP locked permanently by protocol — 100% safe from rugpull
    lockStatus = "protocol";
    const lockerInfo = clankerLockerAddr ? ` Locker: ${clankerLockerAddr}` : "";
    lockDetail = zoraCoin
      ? "Zora Coin — liquidity dikunci permanen oleh protokol. Tidak bisa di-rugpull."
      : `Clanker — liquidity dikunci permanen oleh protokol Clanker. Dev tidak bisa tarik likuiditas.${lockerInfo}`;

  } else if (lpHolders.length > 0) {
    // GoPlus returned LP holder data — applies to ALL pool types:
    // Uniswap V2, V3, Aerodrome, BaseSwap, SushiSwap, Curve, PancakeSwap, etc.
    // GoPlus is_locked=1 = satu-satunya sumber terpercaya untuk "terkunci"

    if (goplusLockedPct >= 80) {
      lockStatus = "locked";
      lockDetail = `${goplusLockedPct.toFixed(1)}% LP terkunci oleh locker resmi (GoPlus verified) — dev TIDAK bisa tarik likuiditas.`;

    } else if (goplusLockedPct >= 40) {
      lockStatus = "partial";
      lockDetail = `${goplusLockedPct.toFixed(1)}% LP terkunci, ${(100 - goplusLockedPct).toFixed(1)}% sisanya TIDAK terkunci dan bisa ditarik dev kapan saja.`;

    } else if (onchainUnknownContractPct >= 50) {
      // Mayoritas LP di contract yang tidak dikenal GoPlus.
      // BISA jadi locker yang GoPlus belum daftarkan — tapi BISA juga contract dengan fungsi admin withdraw.
      // Status: TIDAK TERVERIFIKASI — jangan anggap aman.
      lockStatus = "unverified";
      lockDetail = `${onchainUnknownContractPct.toFixed(1)}% LP dipegang smart contract yang TIDAK terverifikasi sebagai locker. Bisa jadi locker pihak ketiga ATAU contract dengan fungsi admin withdraw. GoPlus tidak konfirmasi lock resmi. Cek di BaseScan sebelum invest.`;

    } else if (goplusLockedPct > 0 || onchainUnknownContractPct > 0) {
      // Ada sebagian lock atau contract tapi tidak dominan
      lockStatus = "partial";
      lockDetail = `Hanya ${(goplusLockedPct + onchainUnknownContractPct).toFixed(1)}% LP yang terkunci/di-contract. Sebagian besar (${onchainEoaPct.toFixed(1)}%) dipegang EOA wallet — dev bisa rugpull sebagian besar likuiditas.`;

    } else {
      // Semua LP dipegang EOA atau tidak ada lock sama sekali
      const poolType = hasNftPositions ? "NFT position (V3-style)" : hasErc20Lp ? "ERC-20 LP token" : "LP token";
      lockStatus = "unlocked";
      lockDetail = `LP tidak terkunci — dipegang wallet biasa (${poolType}). Dev bisa remove likuiditas kapan saja. RISIKO RUGPULL TINGGI.`;
    }

  } else if (onlyV4 && !isProtocol) {
    // V4-only pool: GoPlus sepenuhnya buta terhadap V4 LP holders.
    // Tidak ada locker yang support V4 saat ini. Harus dianggap TIDAK AMAN.
    lockStatus = "unlocked";
    lockDetail = "Pool Uniswap V4 — GoPlus tidak bisa mendeteksi LP holder V4 sama sekali. Tidak ada locker yang support V4. Anggap dev bisa tarik likuiditas kapan saja.";

  } else if (hasV4Pool) {
    // Pool campuran V3+V4 — data tidak lengkap
    lockStatus = "unverified";
    lockDetail = "Pool campuran (V3 + V4) — data LP tidak lengkap karena GoPlus buta terhadap V4 portion. Cek manual di DexScreener/BaseScan.";

  } else {
    // Tidak ada data LP dari GoPlus sama sekali (token sangat baru, atau DEX tidak dikenal GoPlus)
    lockStatus = "unverified";
    lockDetail = "Tidak ada data LP dari GoPlus — token mungkin terlalu baru atau menggunakan DEX yang tidak dikenal GoPlus. Anggap tidak aman sampai terbukti sebaliknya.";
  }

  const lockStatusLabel =
    lockStatus === "protocol"   ? `LP Aman — Terkunci Protokol (${platform})` :
    lockStatus === "locked"     ? `LP Aman — ${lpLockedPct.toFixed(0)}% Terkunci di Contract ✓` :
    lockStatus === "partial"    ? `LP Sebagian Aman — ${lpLockedPct.toFixed(0)}% Terkunci, ${(100 - lpLockedPct).toFixed(0)}% Bebas` :
    lockStatus === "unverified" ? "LP Tidak Terverifikasi ❓ — Anggap Tidak Aman" :
                                  "LP TIDAK Aman ⚠️ — Dev Bisa Rugpull";

  const lpHolderRows = isProtocol
    ? [{ address: platform + " Protocol", tag: platform, percent: "100.00", locked: true,
         lockedSource: "protocol" as const, nftClass: "goplus" as const,
         value: totalLiquidity.toFixed(2), nftIds: [] as string[] }]
    : lpHolders.slice(0, 5).map((h, i) => {
        const cls = holderNftClass[i] ?? "none";
        // ONLY GoPlus is_locked=1 = verified locked
        const isVerifiedLocked = h.is_locked === 1;
        return {
          address: h.address,
          tag: h.tag ?? "",
          percent: (parseFloat(h.percent ?? "0") * 100).toFixed(4),
          locked: isVerifiedLocked,
          lockedSource: h.is_locked === 1 ? "goplus"
            : cls === "unknown_contract"  ? "unknown_contract"
            : "eoa",
          nftClass: cls,
          value: h.value ? parseFloat(h.value).toFixed(2) : "0",
          nftIds: (h.NFT_list ?? []).map(n => n.NFT_id ?? "").filter(Boolean),
        };
      });

  // Contract security checks
  const bool = (v?: string) => v === "1";
  const contractChecks = {
    sourceVerified:        bool(gp?.is_open_source),
    isProxy:               bool(gp?.is_proxy),
    isMintable:            bool(gp?.is_mintable),
    canTakeBackOwnership:  bool(gp?.can_take_back_ownership),
    ownerCanChangeBalance: bool(gp?.owner_change_balance),
    hasHiddenOwner:        bool(gp?.hidden_owner),
    canSelfDestruct:       bool(gp?.selfdestruct),
    hasExternalCall:       bool(gp?.external_call),
    hasBlacklist:          bool(gp?.is_blacklisted),
    hasWhitelist:          bool(gp?.is_whitelisted),
    hasAntiWhale:          bool(gp?.is_anti_whale),
    hasTradingCooldown:    bool(gp?.trading_cooldown),
    canPauseTrading:       bool(gp?.transfer_pausable),
  };

  const isHoneypot = bool(gp?.is_honeypot);
  const _buyTaxRaw  = parseFloat(gp?.buy_tax  ?? "");
  const _sellTaxRaw = parseFloat(gp?.sell_tax ?? "");
  // GoPlus tidak selalu return tax untuk V4 tokens — return null jika tidak tersedia (bukan 0)
  const buyTax:  number | null = isNaN(_buyTaxRaw)  ? null : _buyTaxRaw  * 100;
  const sellTax: number | null = isNaN(_sellTaxRaw) ? null : _sellTaxRaw * 100;

  const holderCount   = gp?.holder_count    ? parseInt(gp.holder_count)    : null;
  const lpHolderCount = gp?.lp_holder_count ? parseInt(gp.lp_holder_count) : null;
  const top10Holders  = (gp?.holders ?? []).slice(0, 10).map(h => ({
    address: h.address,
    tag: h.tag ?? "",
    percent: (parseFloat(h.percent ?? "0") * 100).toFixed(4),
    balance: parseFloat(h.balance ?? "0").toLocaleString("en", { maximumFractionDigits: 0 }),
    isContract: h.is_contract === 1,
    isLocked: h.is_locked === 1,
  }));
  const top10HolderPct = top10Holders.reduce((s, h) => s + parseFloat(h.percent), 0);

  const dexList = sortedPairs.slice(0, 6).map(p => ({
    pairAddress: p.pairAddress ?? "",
    dex: p.dexId ?? "?",
    labels: p.labels ?? [],
    quoteSymbol: p.quoteToken?.symbol ?? "?",
    liqUsd: p.liquidity?.usd ?? 0,
  }));

  const ownerAddress   = gp?.owner_address   || null;
  const creatorAddress = gp?.creator_address || null;
  const ownerRenounced = isProtocol || !ownerAddress || ownerAddress === "0x0000000000000000000000000000000000000000";

  // Risk score
  // 0-20 = safe, 21-50 = caution, 51+ = danger
  let riskScore = 0;

  if (isHoneypot)                              riskScore += 60;

  if ((sellTax ?? 0) > 10)                     riskScore += 20;
  else if ((sellTax ?? 0) > 5)                 riskScore += 10;
  else if ((sellTax ?? 0) > 0)                 riskScore += 5;
  if ((buyTax ?? 0) > 10)                      riskScore += 10;
  else if ((buyTax ?? 0) > 5)                  riskScore += 5;

  // LP lock — applies to ALL pool types (V2, V3, V4, Aerodrome, etc.)
  if (lockStatus === "unlocked" && !isProtocol) riskScore += 25; // flat penalty: unlocked is unlocked regardless of pool type
  else if (lockStatus === "partial")            riskScore += Math.round((1 - lpLockedPct / 100) * 20);
  else if (lockStatus === "unverified")         riskScore += 12;

  // Extra penalty for V4-only (LP completely untraceable even by GoPlus)
  if (onlyV4 && !isProtocol)                   riskScore += 10;

  // Token age penalty: < 24h = pump & dump window
  if (isNewToken)                               riskScore += 15;

  // Pump & dump pattern: volume stopped after initial spike
  if (pumpDumpFlag)                             riskScore += 15;

  // Ownership
  if (contractChecks.hasHiddenOwner)            riskScore += 20;
  if (contractChecks.ownerCanChangeBalance)     riskScore += 20;
  if (contractChecks.canTakeBackOwnership)      riskScore += 15;
  if (!ownerRenounced)                          riskScore += 8;

  // Contract risks
  if (contractChecks.isMintable)               riskScore += 10;
  if (contractChecks.isProxy)                  riskScore += 8;
  if (contractChecks.canSelfDestruct)          riskScore += 10;
  if (contractChecks.canPauseTrading)          riskScore += 8;
  if (!contractChecks.sourceVerified)          riskScore += 8;
  if (contractChecks.hasBlacklist)             riskScore += 5;
  if (contractChecks.hasExternalCall)          riskScore += 5;

  // Liquidity depth
  if (totalLiquidity < 1000)                   riskScore += 15;
  else if (totalLiquidity < 5000)              riskScore += 5;

  if (isProtocol) riskScore = 0;

  const riskLevel: "safe" | "caution" | "danger" =
    riskScore <= 20 ? "safe" : riskScore <= 50 ? "caution" : "danger";

  // Human-readable warnings for UI
  const riskWarnings: string[] = [];
  if (isHoneypot)
    riskWarnings.push("HONEYPOT — token tidak bisa dijual kembali!");
  if (onlyV4 && !isProtocol)
    riskWarnings.push("Pool Uniswap V4 — GoPlus buta terhadap LP holder V4. Tidak ada locker yang support V4. Anggap tidak aman.");
  if (lockStatus === "unlocked" && !isProtocol)
    riskWarnings.push("LP TIDAK TERKUNCI — dev bisa remove likuiditas kapan saja. RISIKO RUGPULL.");
  if (lockStatus === "unverified")
    riskWarnings.push("Status lock tidak terverifikasi — anggap tidak terkunci sampai terbukti di BaseScan.");
  if (isNewToken && tokenAgeH !== null)
    riskWarnings.push(`Token baru (${tokenAgeH < 1 ? `${Math.round(tokenAgeH * 60)} menit` : `${tokenAgeH.toFixed(1)} jam`}) — risiko tinggi, belum teruji.`);
  if (pumpDumpFlag)
    riskWarnings.push("Pola pump & dump terdeteksi — volume berhenti tiba-tiba setelah lonjakan awal.");
  if (sellTax !== null && sellTax > 10)
    riskWarnings.push(`Sell tax sangat tinggi: ${sellTax.toFixed(0)}%`);
  if (contractChecks.hasHiddenOwner)
    riskWarnings.push("Hidden owner — kontrak punya owner tersembunyi.");
  if (contractChecks.ownerCanChangeBalance)
    riskWarnings.push("Owner bisa ubah balance — sangat berbahaya.");
  if (contractChecks.isMintable)
    riskWarnings.push("Token mintable — supply bisa dilute kapan saja.");

  return NextResponse.json({
    address,
    platform,
    isProtocol,
    // Clanker detection signals (for debugging/transparency)
    clankerDetection: isClanker ? {
      byFactory: isClankerByFactory,
      byLocker: isClankerByLocker,
      lockerAddress: clankerLockerAddr ?? null,
    } : null,

    isHoneypot,
    buyTax,
    sellTax,

    lockStatus,
    lockStatusLabel,
    lockDetail,
    lpLockedPct,
    lpTotalSupply,
    lpHolderCount,
    lpHolderRows,

    hasV4Pool,
    hasV3Pool,
    hasErc20Lp,
    onlyV4,

    pairCreatedAt,
    tokenAgeH: tokenAgeH !== null ? Math.round(tokenAgeH * 10) / 10 : null,
    isNewToken,

    vol1h,
    vol6h,
    vol24h,
    volumeDead,
    pumpDumpFlag,

    contractChecks,
    ownerAddress,
    creatorAddress,
    ownerRenounced,

    holderCount,
    top10Holders,
    top10HolderPct,

    totalLiquidity,
    dexList,

    riskScore: Math.min(riskScore, 100),
    riskLevel,
    riskWarnings,
  });
}
