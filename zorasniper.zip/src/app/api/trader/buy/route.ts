/**
 * POST /api/trader/buy
 * Execute buy or create pending-buy order.
 *
 * Routing: Paraswap → KyberSwap → LI.FI → Zora SDK
 * MEV Protection: Flashbots Protect RPC
 */
import { NextRequest, NextResponse } from "next/server";
import { privateKeyToAccount } from "viem/accounts";
import { parseUnits } from "viem";
import { decrypt, isEncrypted } from "@/lib/crypto";
import { getSniperSettings } from "@/db/actions/sniper-actions";
import { createPosition, updatePositionBuy } from "@/db/actions/trader-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";
import {
  getBuyQuote,
  signAndSend,
  waitReceipt,
  fetchEthUsdRate,
  parseTokensReceived,
} from "@/lib/swap-engine";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      fid, tokenAddress, buyAmountEth,
      tokenName, tokenSymbol, tokenPriceUsd, tokenPriceNative, tokenImageUrl,
      buyTriggerPriceUsd, sellTargetPriceUsd,
      takeProfitPct, stopLossPct,
      gasTier,
    } = body;

    if (!fid || !tokenAddress || !buyAmountEth) {
      return NextResponse.json({ error: "fid, tokenAddress, buyAmountEth wajib" }, { status: 400 });
    }

    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    const settings = await getSniperSettings(fid);
    if (!settings?.privateKeyEncrypted || !settings.walletAddress) {
      return NextResponse.json({ error: "Private key belum diset di Settings" }, { status: 400 });
    }

    // Create position record first
    const position = await createPosition({
      fid, tokenAddress, tokenName, tokenSymbol,
      tokenPriceUsd: tokenPriceUsd ?? null,
      tokenImageUrl: tokenImageUrl ?? null,
      buyAmountEth,
      buyTriggerPriceUsd: buyTriggerPriceUsd ?? null,
      sellTargetPriceUsd: sellTargetPriceUsd ?? null,
      takeProfitPct: takeProfitPct?.toString() ?? null,
      stopLossPct: stopLossPct?.toString() ?? null,
    });

    // ── Minimum liquidity guard ───────────────────────────────────────────────
    // Cek total likuiditas token di DexScreener sebelum beli.
    // Jika di bawah threshold user, tolak beli untuk hindari rug/low-liq tokens.
    const minLiqUsd = settings.minLiquidityUsd ?? 5000;
    if (minLiqUsd > 0) {
      try {
        const liqRes = await fetch(
          `https://api.dexscreener.com/latest/dex/tokens/${tokenAddress.toLowerCase()}`,
          { next: { revalidate: 0 } },
        );
        if (liqRes.ok) {
          const liqData = await liqRes.json();
          const basePairs: Array<{ chainId?: string; liquidity?: { usd?: number } }> =
            (liqData.pairs ?? []).filter((p: { chainId?: string }) => p.chainId === "base");
          // Sum liquidity across all Base pairs for this token
          const totalLiqUsd = basePairs.reduce((sum, p) => sum + (p.liquidity?.usd ?? 0), 0);
          if (totalLiqUsd > 0 && totalLiqUsd < minLiqUsd) {
            const liqMsg = `Token ditolak: likuiditas terlalu rendah ($${totalLiqUsd.toFixed(0)} < minimum $${minLiqUsd}). Ubah pengaturan Min Liquidity di Settings jika ingin tetap beli.`;
            await updatePositionBuy(position.id, { status: "buy_failed", errorMessage: liqMsg });
            return NextResponse.json({ error: liqMsg }, { status: 400 });
          }
        }
      } catch {
        // Best-effort — if DexScreener is down, allow the buy to proceed
      }
    }

    // If there's a trigger price, save and wait for monitor cron
    if (buyTriggerPriceUsd) {
      return NextResponse.json({
        success: true,
        positionId: position.id,
        status: "pending_buy",
        message: `Order dibuat. Akan beli otomatis ketika harga ≤ $${buyTriggerPriceUsd}`,
      });
    }

    // Decrypt private key and create account
    const rawKey = isEncrypted(settings.privateKeyEncrypted)
      ? await decrypt(settings.privateKeyEncrypted)
      : settings.privateKeyEncrypted;
    const pk = rawKey.startsWith("0x") ? (rawKey as `0x${string}`) : (`0x${rawKey}` as `0x${string}`);
    const account = privateKeyToAccount(pk);
    const buyAmountWei = parseUnits(buyAmountEth, 18);

    const [quote, ethUsdRate] = await Promise.all([
      getBuyQuote({
        tokenAddress: tokenAddress.toLowerCase(),
        buyAmountWei,
        slippageBps: settings.slippageBps ?? 500,
        senderAddress: account.address,
      }),
      fetchEthUsdRate(),
    ]);

    if (!quote) {
      const noRouteMsg = "Token ini tidak bisa dibeli otomatis — semua aggregator gagal (Paraswap, KyberSwap, LI.FI, Zora SDK). Kemungkinan token ini terlalu baru atau belum punya pool yang dikenali. Coba beli manual di Zora.co.";
      await updatePositionBuy(position.id, { status: "buy_failed", errorMessage: noRouteMsg });
      return NextResponse.json({ error: noRouteMsg }, { status: 400 });
    }

    let txHash: string;
    try {
      txHash = await signAndSend({ account, to: quote.target, data: quote.data, value: quote.value, gasTier: gasTier ?? "normal" });
    } catch (e) {
      const msg = e instanceof Error ? e.message.slice(0, 200) : "TX send failed";
      await updatePositionBuy(position.id, { status: "buy_failed", errorMessage: msg });
      return NextResponse.json({ error: msg }, { status: 400 });
    }

    console.log("[buy] TX sent:", txHash, "route:", quote.route);

    const receipt = await waitReceipt(txHash, 45000);
    if (!receipt) {
      await updatePositionBuy(position.id, {
        buyTxHash: txHash,
        buyPriceUsd: tokenPriceUsd ?? undefined,
        ethUsdAtBuy: ethUsdRate.toFixed(2),
        status: "active",
      });
      return NextResponse.json({ success: true, positionId: position.id, txHash, route: quote.route, status: "pending" });
    }

    if (receipt.status === "0x0") {
      await updatePositionBuy(position.id, {
        buyTxHash: txHash, status: "buy_failed", errorMessage: "TX reverted on-chain",
      });
      return NextResponse.json({ error: "Buy TX reverted on-chain", txHash }, { status: 400 });
    }

    const tokensReceived = parseTokensReceived(receipt, tokenAddress.toLowerCase(), account.address);

    await updatePositionBuy(position.id, {
      buyTxHash: txHash,
      buyPriceUsd: tokenPriceUsd ?? undefined,
      buyPriceEth: tokenPriceNative ?? undefined,
      ethUsdAtBuy: ethUsdRate.toFixed(2),
      tokensReceived: tokensReceived ?? undefined,
      status: "active",
    });

    return NextResponse.json({ success: true, positionId: position.id, txHash, route: quote.route, status: "confirmed" });
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message.slice(0, 300) : "Unknown" }, { status: 500 });
  }
}
