import { NextRequest, NextResponse } from "next/server";
import { getActivePositions, getPositionHistory, cancelPosition, updatePositionTargets } from "@/db/actions/trader-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";

export async function GET(request: NextRequest) {
  const fid = parseInt(request.nextUrl.searchParams.get("fid") ?? "0");
  const type = request.nextUrl.searchParams.get("type") ?? "active";

  if (!fid) return NextResponse.json({ error: "fid wajib" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  if (type === "history") {
    const history = await getPositionHistory(fid, 50);
    return NextResponse.json({ positions: history });
  }

  const positions = await getActivePositions(fid);
  return NextResponse.json({ positions });
}

export async function PATCH(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  const { fid, positionId, takeProfitPct, stopLossPct, sellTargetPriceUsd } = body;

  if (!fid || !positionId) return NextResponse.json({ error: "fid dan positionId wajib" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  await updatePositionTargets(positionId, fid, {
    takeProfitPct: takeProfitPct !== undefined ? (takeProfitPct === null ? null : String(takeProfitPct)) : undefined,
    stopLossPct: stopLossPct !== undefined ? (stopLossPct === null ? null : String(stopLossPct)) : undefined,
    sellTargetPriceUsd: sellTargetPriceUsd !== undefined ? (sellTargetPriceUsd === null ? null : String(sellTargetPriceUsd)) : undefined,
  });

  return NextResponse.json({ success: true });
}

export async function DELETE(request: NextRequest) {
  const fid = parseInt(request.nextUrl.searchParams.get("fid") ?? "0");
  const id = request.nextUrl.searchParams.get("id");

  if (!fid || !id) return NextResponse.json({ error: "fid dan id wajib" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  await cancelPosition(id, fid);
  return NextResponse.json({ success: true });
}
