import { NextRequest, NextResponse } from "next/server";
import { base } from "viem/chains";

// ─── ETH/USD rate — cached 60s ────────────────────────────────────────────────
let _ethUsdCache: { rate: number; ts: number } | null = null;

async function getEthUsdRate(): Promise<number> {
  if (_ethUsdCache && Date.now() - _ethUsdCache.ts < 60_000) return _ethUsdCache.rate;
  try {
    const WETH_BASE = "0x4200000000000000000000000000000000000006";
    const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${WETH_BASE}`, {
      next: { revalidate: 60 },
    });
    const d = await res.json();
    const pairs: Array<{ quoteToken?: { symbol?: string }; priceUsd?: string; liquidity?: { usd?: number } }> =
      (d.pairs ?? []).filter((p: { chainId?: string }) => p.chainId === "base");
    const stablePair = pairs
      .filter(p => ["USDC", "USDC.E", "USDT", "DAI"].includes((p.quoteToken?.symbol ?? "").toUpperCase()))
      .sort((a, b) => (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0))[0];
    const rate = stablePair ? parseFloat(stablePair.priceUsd ?? "0") : 2000;
    _ethUsdCache = { rate, ts: Date.now() };
    return rate;
  } catch {
    return 2000; // safe fallback
  }
}

const RPC_URL = "https://base-rpc.publicnode.com";

// ─── On-chain balance (real token qty) ───────────────────────────────────────

async function getOnChainBalance(token: string, wallet: string): Promise<bigint> {
  try {
    const data = "0x70a08231000000000000000000000000" + wallet.slice(2).toLowerCase();
    const res = await fetch(RPC_URL, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", method: "eth_call", params: [{ to: token, data }, "latest"], id: 1 }),
      next: { revalidate: 0 },
    });
    const d = await res.json();
    return d.result && d.result !== "0x" ? BigInt(d.result) : BigInt(0);
  } catch { return BigInt(0); }
}

// ─── ERC-20 decimals ──────────────────────────────────────────────────────────

async function getDecimals(token: string): Promise<number> {
  try {
    const res = await fetch(RPC_URL, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", method: "eth_call", params: [{ to: token, data: "0x313ce567" }, "latest"], id: 2 }),
      next: { revalidate: 3600 },
    });
    const d = await res.json();
    return d.result && d.result !== "0x" ? parseInt(d.result, 16) : 18;
  } catch { return 18; }
}

// ─── ERC-20 total supply ──────────────────────────────────────────────────────

async function getTotalSupply(token: string): Promise<bigint> {
  try {
    const res = await fetch(RPC_URL, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", method: "eth_call", params: [{ to: token, data: "0x18160ddd" }, "latest"], id: 3 }),
      next: { revalidate: 60 },
    });
    const d = await res.json();
    return d.result && d.result !== "0x" ? BigInt(d.result) : BigInt(0);
  } catch { return BigInt(0); }
}

// ─── DexScreener: best pair + aggregated volume ───────────────────────────────

interface DexPair {
  chainId?: string;
  dexId?: string;
  pairAddress?: string;
  pairCreatedAt?: number; // unix ms
  baseToken?: { name?: string; symbol?: string; address?: string };
  quoteToken?: { name?: string; symbol?: string; address?: string };
  priceUsd?: string;
  priceNative?: string;
  liquidity?: { usd?: number };
  volume?: { h24?: number; h6?: number; h1?: number; m5?: number };
  priceChange?: { h24?: number; h6?: number; h1?: number; m5?: number };
  txns?: {
    h24?: { buys?: number; sells?: number };
    h6?: { buys?: number; sells?: number };
    h1?: { buys?: number; sells?: number };
    m5?: { buys?: number; sells?: number };
  };
  fdv?: number;
  marketCap?: number;
  info?: { imageUrl?: string };
}

async function getDexData(address: string): Promise<{
  pairs: DexPair[];
  best: DexPair | null;
  totalVol24h: number;
  totalVol6h: number;
  totalVol1h: number;
  totalLiquidity: number;
  pairCreatedAt: number | null;
}> {
  const res = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${address}`, {
    next: { revalidate: 0 }, // always fresh
  });
  if (!res.ok) throw new Error("DexScreener error");
  const data = await res.json();
  const pairs: DexPair[] = (data.pairs ?? []).filter((p: DexPair) => p.chainId === "base");
  if (!pairs.length) return { pairs: [], best: null, totalVol24h: 0, totalVol6h: 0, totalVol1h: 0, totalLiquidity: 0, pairCreatedAt: null };

  // Best pair = highest liquidity (most accurate price)
  const sorted = [...pairs].sort((a, b) => (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0));
  const best = sorted[0];

  // For priceNative we MUST use an ETH/WETH pair — otherwise priceNative is in USDC/VIRTUAL/etc.
  // Validation rules to reject unreliable ETH pairs:
  //   1. Liquidity >= $5,000 (low-liq pairs have manipulated/stale prices)
  //   2. priceUsd from ETH pair must be within 30% of best pair's priceUsd
  //      (if ETH pair's USD price is way off from USDC pair, it's unreliable)
  const ETH_SYMBOLS = ["ETH", "WETH"];
  const bestPriceUsd = parseFloat(best?.priceUsd ?? "0");
  const ethPair = sorted.find(p => {
    if (!ETH_SYMBOLS.includes(p.quoteToken?.symbol?.toUpperCase() ?? "")) return false;
    const liq = p.liquidity?.usd ?? 0;
    if (liq < 5000) return false; // too low liquidity — price unreliable
    const ethPairUsd = parseFloat(p.priceUsd ?? "0");
    if (bestPriceUsd > 0 && ethPairUsd > 0) {
      const deviation = Math.abs(ethPairUsd - bestPriceUsd) / bestPriceUsd;
      if (deviation > 0.30) return false; // price deviates >30% from reference — skip
    }
    return true;
  });
  if (ethPair && best) {
    best.priceNative = ethPair.priceNative;
  } else if (best) {
    // No reliable ETH pair — use USD-only PnL method
    best.priceNative = "0";
  }

  // Aggregate volume and liquidity across all pairs (some tokens have multiple pools)
  const totalVol24h = pairs.reduce((s, p) => s + (p.volume?.h24 ?? 0), 0);
  const totalVol6h  = pairs.reduce((s, p) => s + (p.volume?.h6  ?? 0), 0);
  const totalVol1h  = pairs.reduce((s, p) => s + (p.volume?.h1  ?? 0), 0);
  const totalLiquidity = pairs.reduce((s, p) => s + (p.liquidity?.usd ?? 0), 0);

  // Earliest pair creation time = token's first pool (oldest pair)
  const pairCreatedAt = pairs.reduce<number | null>((min, p) => {
    const ts = p.pairCreatedAt ?? null;
    if (ts === null) return min;
    return min === null ? ts : Math.min(min, ts);
  }, null);

  return { pairs, best, totalVol24h, totalVol6h, totalVol1h, totalLiquidity, pairCreatedAt };
}

// ─── Tradability check ────────────────────────────────────────────────────────

async function checkTradeable(address: string): Promise<{ tradeable: boolean; route: string; reason?: string }> {
  // Route 1: Zora SDK
  try {
    const { createTradeCall } = await import("@zoralabs/coins-sdk");
    const q = await createTradeCall({
      sell: { type: "eth" as const },
      buy: { type: "erc20" as const, address: address as `0x${string}` },
      amountIn: BigInt("100000000000000"),
      slippage: 0.05,
      sender: "0x0000000000000000000000000000000000000001" as `0x${string}`,
      recipient: "0x0000000000000000000000000000000000000001" as `0x${string}`,
    });
    if (q.call?.target && q.call?.data) return { tradeable: true, route: "zora" };
  } catch { /* fallback */ }

  // Route 2: Uniswap V3 quoter
  try {
    const WETH = "0x4200000000000000000000000000000000000006";
    const V3_QUOTER = "0x3d4e44Eb1374240CE5F1B136588d6eBEd2259B1";
    const { encodeFunctionData } = await import("viem");
    const calldata = encodeFunctionData({
      abi: [{ name: "quoteExactInputSingle", type: "function", inputs: [{ name: "params", type: "tuple", components: [
        { name: "tokenIn", type: "address" }, { name: "tokenOut", type: "address" },
        { name: "amountIn", type: "uint256" }, { name: "fee", type: "uint24" },
        { name: "sqrtPriceLimitX96", type: "uint160" },
      ]}], outputs: [
        { name: "amountOut", type: "uint256" }, { name: "sqrtPriceX96After", type: "uint160" },
        { name: "initializedTicksCrossed", type: "uint32" }, { name: "gasEstimate", type: "uint256" },
      ] }],
      functionName: "quoteExactInputSingle",
      args: [{ tokenIn: WETH as `0x${string}`, tokenOut: address as `0x${string}`, amountIn: BigInt("100000000000000"), fee: 10000, sqrtPriceLimitX96: BigInt(0) }],
    });
    const res = await fetch(RPC_URL, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", method: "eth_call", params: [{ to: V3_QUOTER, data: calldata }, "latest"], id: 1 }),
    });
    const d = await res.json();
    if (d.result && d.result !== "0x") {
      const { decodeFunctionResult } = await import("viem");
      const decoded = decodeFunctionResult({
        abi: [{ name: "quoteExactInputSingle", type: "function", outputs: [
          { name: "amountOut", type: "uint256" }, { name: "sqrtPriceX96After", type: "uint160" },
          { name: "initializedTicksCrossed", type: "uint32" }, { name: "gasEstimate", type: "uint256" },
        ]}],
        functionName: "quoteExactInputSingle", data: d.result,
      }) as readonly [bigint, bigint, number, bigint];
      if (decoded[0] > BigInt(0)) return { tradeable: true, route: "uniswap_v3" };
    }
  } catch { /* fallback */ }

  // Route 3: Uniswap Trading API (handles V4, mixed, Clanker)
  try {
    const UNISWAP_TRADING_API = "https://trading-api-labs.interface.gateway.uniswap.org/v1";
    // Uniswap public demo key — safe to use but can be overridden via env var
    const UNISWAP_API_KEY = process.env.UNISWAP_API_KEY ?? "JoyCGj29tT4pymvhaGciK4r1aIPvqW6W53xT1fwo";
    const res = await fetch(`${UNISWAP_TRADING_API}/quote`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": UNISWAP_API_KEY },
      body: JSON.stringify({
        type: "EXACT_INPUT", amount: "100000000000000",
        tokenInChainId: base.id, tokenOutChainId: base.id,
        tokenIn: "0x0000000000000000000000000000000000000000",
        tokenOut: address,
        swapper: "0x0000000000000000000000000000000000000001",
        slippageTolerance: 5,
      }),
    });
    if (res.ok) {
      const d = await res.json();
      if (d.quote?.output?.amount && BigInt(d.quote.output.amount) > BigInt(0)) {
        return { tradeable: true, route: "uniswap" };
      }
    }
  } catch { /* not tradeable */ }

  return { tradeable: false, route: "none", reason: "Token ini tidak bisa diperdagangkan saat ini." };
}

// ─── Main GET handler ─────────────────────────────────────────────────────────

export async function GET(request: Request) {
  const url = new URL(request.url);
  const address = url.searchParams.get("address")?.toLowerCase();
  const walletAddress = url.searchParams.get("wallet")?.toLowerCase(); // optional

  if (!address || !/^0x[0-9a-f]{40}$/.test(address)) {
    return NextResponse.json({ error: "Contract address tidak valid" }, { status: 400 });
  }

  try {
    // Run all fetches in parallel for speed
    const [dex, tradeCheck, totalSupplyRaw, decimals, walletBalanceRaw, ethUsdRate] = await Promise.all([
      getDexData(address),
      checkTradeable(address),
      getTotalSupply(address),
      getDecimals(address),
      walletAddress ? getOnChainBalance(address, walletAddress) : Promise.resolve(null as bigint | null),
      getEthUsdRate(),
    ]);

    if (!dex.best) {
      return NextResponse.json({
        error: "Token tidak ditemukan di Base. Pastikan address benar dan token sudah ada pair-nya.",
      }, { status: 404 });
    }

    const best = dex.best;

    // Price: use DexScreener's best pair (highest liquidity = most accurate)
    const priceUsd = best.priceUsd ?? "0";
    const priceNative = best.priceNative ?? "0";
    const priceUsdNum = parseFloat(priceUsd);

    // Market cap: prefer DexScreener's circulating marketCap, fall back to FDV
    // DexScreener provides marketCap (circulating) separately from fdv (fully diluted)
    const marketCap = best.marketCap ?? best.fdv ?? 0;
    const fdv = best.fdv ?? 0;

    // Compute accurate marketCap from on-chain supply if DexScreener doesn't provide it
    let accurateMarketCap = marketCap;
    if (!best.marketCap && totalSupplyRaw > BigInt(0) && priceUsdNum > 0) {
      // Safe BigInt → float: use 10n ** BigInt(decimals) NOT BigInt(10 ** decimals)
      // because 10 ** 18 as JS Number loses float64 precision → wrong divisor
      const divisor = 10n ** BigInt(decimals);
      const w = totalSupplyRaw / divisor;
      const f = totalSupplyRaw % divisor;
      const supplyFloat = Number(w) + Number(f) / Number(divisor);
      accurateMarketCap = supplyFloat * priceUsdNum;
    }

    // Volume: sum across all pools on Base for this token
    const volume24h = dex.totalVol24h;
    // Liquidity: sum across all pools
    const liquidity = dex.totalLiquidity;

    // Price change percentages (from best/highest-liquidity pair)
    const priceChange24h = best.priceChange?.h24 ?? 0;
    const priceChange6h  = best.priceChange?.h6  ?? 0;
    const priceChange1h  = best.priceChange?.h1  ?? 0;
    const priceChange5m  = best.priceChange?.m5  ?? 0;

    // Transaction counts (24h from best pair)
    const txns24h = best.txns?.h24;
    const buys24h = txns24h?.buys ?? 0;
    const sells24h = txns24h?.sells ?? 0;
    const txns6h = best.txns?.h6;
    const buys6h = txns6h?.buys ?? 0;
    const sells6h = txns6h?.sells ?? 0;

    // Volume breakdown
    const volume6h = dex.totalVol6h;
    const volume1h = dex.totalVol1h;

    // Token age: from earliest pair creation time
    const pairCreatedAt = dex.pairCreatedAt ?? null;

    // Holders: DexScreener doesn't expose this directly, but we can try
    // from the info field if ever populated. Leave null for now.
    const holders: number | null = null;

    // Wallet-specific data (on-chain, always accurate)
    let walletBalance: string | null = null;
    let walletBalanceUsd: number | null = null;
    if (walletAddress && walletBalanceRaw !== null) {
      const raw = walletBalanceRaw as bigint;
      // Safe BigInt → float: avoid Number() overflow on large token amounts (> 2^53)
      // Divide by 10^decimals using BigInt first, then convert remainder
      const divisor = 10n ** BigInt(decimals);
      const wholePart = raw / divisor;
      const fracPart  = raw % divisor;
      const balanceFloat = Number(wholePart) + Number(fracPart) / Number(divisor);
      walletBalance = balanceFloat.toFixed(decimals > 6 ? 6 : decimals);
      walletBalanceUsd = balanceFloat * priceUsdNum;
    }

    return NextResponse.json({
      found: true,
      address,
      name: best.baseToken?.name ?? "",
      symbol: best.baseToken?.symbol ?? "",

      // Price data
      priceUsd,
      priceNative,
      priceChange5m,
      priceChange1h,
      priceChange6h,
      priceChange24h,

      // Market data
      liquidity,          // total across all pools
      volume24h,          // total across all pools
      volume6h,
      volume1h,
      marketCap: accurateMarketCap,
      fdv,

      // Token age
      pairCreatedAt,      // unix ms of earliest pool creation

      // On-chain supply (safe BigInt division)
      totalSupply: totalSupplyRaw > BigInt(0)
        ? (() => {
            const div = 10n ** BigInt(decimals);
            const w = totalSupplyRaw / div;
            const f = totalSupplyRaw % div;
            return (Number(w) + Number(f) / Number(div)).toFixed(0);
          })()
        : null,
      decimals,

      // Trading activity
      buys24h,
      sells24h,
      buys6h,
      sells6h,

      // Holders (null until source available)
      holders,

      // Image
      imageUrl: best.info?.imageUrl ?? null,
      dex: best.dexId ?? "unknown",
      pairAddress: best.pairAddress ?? null,

      // Wallet balance (only if wallet param provided)
      walletBalance,
      walletBalanceUsd,

      // Tradability
      tradeable: tradeCheck.tradeable,
      tradeRoute: tradeCheck.route,
      tradeWarning: tradeCheck.tradeable ? null : tradeCheck.reason,

      // ETH/USD rate (for PnL calculation when token has no ETH pair)
      ethUsdRate,
    });
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Unknown" }, { status: 500 });
  }
}
