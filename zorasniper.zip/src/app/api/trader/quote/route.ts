/**
 * GET /api/trader/quote?tokenAddress=0x...&buyAmountEth=0.001
 *
 * Pre-trade simulation: estimate swap output + safety warnings.
 * Queries Paraswap + KyberSwap in parallel for best estimate.
 * noRoute = true hanya jika SEMUA aggregator gagal (jarang terjadi).
 */
import { NextRequest, NextResponse } from "next/server";
import { base } from "viem/chains";

const PARASWAP_API = "https://api.paraswap.io";
const KYBER_API    = "https://aggregator-api.kyberswap.com/base/api/v1";
const ETH_ADDR     = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE";
// Simulation address — aggregators reject address(0), use a valid-looking address
const DUMMY_ADDR   = "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045"; // vitalik.eth

export async function GET(req: NextRequest) {
  try {
    const tokenAddress = req.nextUrl.searchParams.get("tokenAddress");
    const buyAmountEth = req.nextUrl.searchParams.get("buyAmountEth");

    if (!tokenAddress || !buyAmountEth) {
      return NextResponse.json({ error: "tokenAddress dan buyAmountEth wajib" }, { status: 400 });
    }

    const amountInWei = BigInt(Math.round(parseFloat(buyAmountEth) * 1e18)).toString();

    // Fetch token decimals for Paraswap (needed for srcDecimals/destDecimals params)
    let tokenDecimals = 18;
    try {
      const decRes = await fetch(
        `https://base-rpc.publicnode.com`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", method: "eth_call", params: [{ to: tokenAddress, data: "0x313ce567" }, "latest"], id: 1 }),
        },
      );
      const decData = await decRes.json();
      if (decData.result && decData.result !== "0x") {
        tokenDecimals = parseInt(decData.result, 16);
      }
    } catch { /* use default 18 */ }

    // ── Run all fetches in parallel ───────────────────────────────────────────
    const [dsResult, paraswapResult, kyberResult, ethRateResult] = await Promise.allSettled([
      // 1. DexScreener liquidity data
      fetch(`https://api.dexscreener.com/latest/dex/tokens/${tokenAddress}`, { next: { revalidate: 0 } })
        .then(r => r.json()),

      // 2. Paraswap /prices quote (read-only, no API key needed)
      fetch(
        `${PARASWAP_API}/prices?srcToken=${ETH_ADDR}&destToken=${tokenAddress}&amount=${amountInWei}&srcDecimals=18&destDecimals=${tokenDecimals}&side=SELL&network=${base.id}&version=6.2&userAddress=${DUMMY_ADDR}&partner=zora-sniper`,
      ).then(r => r.json()),

      // 3. KyberSwap quote (just route, no build needed for estimation)
      fetch(`${KYBER_API}/routes?tokenIn=${ETH_ADDR}&tokenOut=${tokenAddress}&amountIn=${amountInWei}`,
        { headers: { "x-client-id": "zora-sniper" } })
        .then(r => r.json()),

      // 4. ETH/USD rate
      fetch("https://api.dexscreener.com/latest/dex/tokens/0x4200000000000000000000000000000000000006",
        { next: { revalidate: 60 } })
        .then(r => r.json()),
    ]);

    // ── Parse DexScreener ─────────────────────────────────────────────────────
    let totalLiqUsd = 0;
    let bestPriceUsd = 0;
    let worstPriceUsd = 0;
    let priceInconsistent = false;

    if (dsResult.status === "fulfilled") {
      const pairs = (dsResult.value.pairs ?? []).filter(
        (p: { chainId?: string }) => p.chainId === "base",
      );
      if (pairs.length > 0) {
        const sorted = [...pairs].sort(
          (a: { liquidity?: { usd?: number } }, b: { liquidity?: { usd?: number } }) =>
            (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0),
        );
        totalLiqUsd   = sorted.reduce((s: number, p: { liquidity?: { usd?: number } }) => s + (p.liquidity?.usd ?? 0), 0);
        bestPriceUsd  = parseFloat((sorted[0] as { priceUsd?: string }).priceUsd ?? "0");
        worstPriceUsd = parseFloat((sorted[sorted.length - 1] as { priceUsd?: string }).priceUsd ?? "0");
        if (bestPriceUsd > 0 && worstPriceUsd > 0) {
          const deviation = Math.abs(bestPriceUsd - worstPriceUsd) / bestPriceUsd;
          if (deviation > 0.5) priceInconsistent = true;
        }
      }
    }

    // ── Parse ETH/USD rate ────────────────────────────────────────────────────
    let ethUsdRate = 2000;
    if (ethRateResult.status === "fulfilled") {
      const stable = (ethRateResult.value.pairs ?? [])
        .filter((p: { chainId?: string; quoteToken?: { symbol?: string } }) =>
          p.chainId === "base" &&
          ["USDC","USDC.E","USDT","DAI"].includes((p.quoteToken?.symbol ?? "").toUpperCase()))
        .sort((a: { liquidity?: { usd?: number } }, b: { liquidity?: { usd?: number } }) =>
          (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0))[0];
      if (stable?.priceUsd) ethUsdRate = parseFloat(stable.priceUsd);
    }

    // ── Parse Paraswap quote ──────────────────────────────────────────────────
    let paraswapAmountOut = "0";
    let paraswapAmountOutUsd = 0;
    let paraswapOk = false;

    if (paraswapResult.status === "fulfilled") {
      const pd = paraswapResult.value;
      if (pd.priceRoute?.destAmount && !pd.error) {
        paraswapAmountOut    = pd.priceRoute.destAmount;
        paraswapAmountOutUsd = parseFloat(pd.priceRoute.destUSD ?? "0");
        paraswapOk = true;
      }
    }

    // ── Parse Kyber quote ─────────────────────────────────────────────────────
    let kyberAmountOut = "0";
    let kyberOk = false;

    if (kyberResult.status === "fulfilled") {
      const kd = kyberResult.value;
      if (kd.code === 0 && kd.data?.routeSummary?.amountOut) {
        kyberAmountOut = kd.data.routeSummary.amountOut;
        kyberOk = true;
      }
    }

    // ── Best estimate: prefer Paraswap (has USD value), fallback to Kyber ─────
    const anyRouteOk = paraswapOk || kyberOk;
    const estimatedTokenOut = paraswapOk ? paraswapAmountOut : kyberAmountOut;
    const estimatedUsdOut   = paraswapOk ? paraswapAmountOutUsd : 0;

    // ── Price impact ──────────────────────────────────────────────────────────
    const buyAmountUsd = parseFloat(buyAmountEth) * ethUsdRate;
    let priceImpactPct = 0;

    if (paraswapOk && paraswapAmountOutUsd > 0 && buyAmountUsd > 0) {
      priceImpactPct = ((buyAmountUsd - paraswapAmountOutUsd) / buyAmountUsd) * 100;
    } else if (totalLiqUsd > 0 && buyAmountUsd > 0) {
      // Rough x*y=k estimate when no USD output available
      priceImpactPct = (buyAmountUsd / (totalLiqUsd + buyAmountUsd)) * 100;
    }

    // ── Warnings ──────────────────────────────────────────────────────────────
    const warnings: string[] = [];

    if (totalLiqUsd > 0 && totalLiqUsd < 1000) {
      warnings.push(`⚠️ Likuiditas sangat rendah ($${totalLiqUsd.toFixed(0)}) — swap bisa dapat jauh lebih sedikit dari harga pasar`);
    } else if (totalLiqUsd > 0 && totalLiqUsd < 5000) {
      warnings.push(`⚠️ Likuiditas rendah ($${totalLiqUsd.toFixed(0)}) — ada risiko price impact besar`);
    }

    if (priceImpactPct > 50) {
      warnings.push(`🚨 Price impact sangat tinggi (~${priceImpactPct.toFixed(0)}%) — kamu akan rugi sebagian besar modal`);
    } else if (priceImpactPct > 10) {
      warnings.push(`⚠️ Price impact tinggi (~${priceImpactPct.toFixed(0)}%) — pertimbangkan beli jumlah lebih kecil`);
    }

    if (priceInconsistent) {
      warnings.push(`⚠️ Harga tidak konsisten antar pool — kemungkinan ada manipulasi atau pool lama yang tidak dipakai`);
    }

    // Hanya warn noRoute kalau SEMUA aggregator gagal
    if (!anyRouteOk) {
      warnings.push(`⚠️ Estimasi swap tidak tersedia — sistem tetap akan coba beli saat eksekusi (Paraswap → Kyber → LI.FI → Zora)`);
    }

    return NextResponse.json({
      tokenAddress,
      buyAmountEth,
      totalLiqUsd,
      paraswapOk,
      kyberOk,
      // noRoute = true hanya jika semua aggregator gagal memberikan estimasi
      noRoute: !anyRouteOk,
      estimatedTokenOut,
      estimatedUsdOut,
      priceImpactPct: parseFloat(priceImpactPct.toFixed(2)),
      priceInconsistent,
      warnings,
      safe: warnings.length === 0,
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message.slice(0, 200) : "Unknown" },
      { status: 500 },
    );
  }
}
