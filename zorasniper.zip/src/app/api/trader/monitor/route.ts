/**
 * GET /api/trader/monitor
 * Cron: check all active/pending positions and auto-sell on TP/SL.
 *
 * Routing: Paraswap → KyberSwap → LI.FI → Zora SDK
 * MEV Protection: Flashbots Protect RPC
 */
import { NextResponse } from "next/server";
import { privateKeyToAccount } from "viem/accounts";
import { parseUnits } from "viem";
import { decrypt, isEncrypted } from "@/lib/crypto";
import { getSniperSettings } from "@/db/actions/sniper-actions";
import {
  getAllMonitorablePositions,
  updatePositionBuy,
  closePosition,
} from "@/db/actions/trader-actions";
import {
  getBuyQuote,
  getSellQuote,
  signAndSend,
  waitReceipt,
  fetchEthUsdRate,
  parseTokensReceived,
  parseEthReceived,
  getTokenBalance,
  getTokenDecimals,
  rawBalanceToFloat,
} from "@/lib/swap-engine";

// ─── Token price from DexScreener ────────────────────────────────────────────

async function getTokenPriceUsd(tokenAddress: string): Promise<{ priceUsd: number; priceNative: number } | null> {
  try {
    const res = await fetch(
      `https://api.dexscreener.com/latest/dex/tokens/${tokenAddress}`,
      { next: { revalidate: 0 } },
    );
    if (!res.ok) return null;
    const data = await res.json();
    const pairs: Array<{
      chainId?: string;
      liquidity?: { usd?: number };
      priceUsd?: string;
      priceNative?: string;
      quoteToken?: { symbol?: string };
    }> = (data.pairs ?? []).filter((p: { chainId?: string }) => p.chainId === "base");
    if (!pairs.length) return null;

    const sorted = [...pairs].sort((a, b) => (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0));
    const best = sorted[0];
    const bestPriceUsd = parseFloat(best.priceUsd ?? "0");

    // priceNative only from a reliable ETH/WETH pair (liq >= $5K, price within 30% of best)
    const ETH_SYMS = ["ETH", "WETH"];
    const reliableEthPair = sorted.find(p => {
      if (!ETH_SYMS.includes((p.quoteToken?.symbol ?? "").toUpperCase())) return false;
      if ((p.liquidity?.usd ?? 0) < 5000) return false;
      const ethPairUsd = parseFloat(p.priceUsd ?? "0");
      if (bestPriceUsd > 0 && ethPairUsd > 0) {
        const deviation = Math.abs(ethPairUsd - bestPriceUsd) / bestPriceUsd;
        if (deviation > 0.30) return false;
      }
      return true;
    });
    const priceNative = reliableEthPair ? parseFloat(reliableEthPair.priceNative ?? "0") : 0;

    return { priceUsd: bestPriceUsd, priceNative };
  } catch { return null; }
}

// ─── Main Handler ─────────────────────────────────────────────────────────────

export async function GET(request: Request) {
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = request.headers.get("authorization");
    if (auth !== `Bearer ${secret}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  try {
    const positions = await getAllMonitorablePositions();
    if (!positions.length) return NextResponse.json({ checked: 0, triggered: 0 });

    console.log("[monitor] positions:", positions.length, positions.map(p => ({
      id: p.id, sym: p.tokenSymbol, status: p.status,
    })));

    let triggered = 0;
    const results: object[] = [];

    // Group by FID to share decoded key within each user's loop
    const byFid = new Map<number, typeof positions>();
    for (const pos of positions) {
      if (!byFid.has(pos.fid)) byFid.set(pos.fid, []);
      byFid.get(pos.fid)!.push(pos);
    }

    for (const [fid, fidPositions] of byFid) {
      const settings = await getSniperSettings(fid);
      if (!settings?.privateKeyEncrypted) continue;

      const rawKey = isEncrypted(settings.privateKeyEncrypted)
        ? await decrypt(settings.privateKeyEncrypted)
        : settings.privateKeyEncrypted;
      const pk = rawKey.startsWith("0x") ? (rawKey as `0x${string}`) : (`0x${rawKey}` as `0x${string}`);
      const account = privateKeyToAccount(pk);
      const slippageBps = settings.slippageBps ?? 500;

      for (const pos of fidPositions) {
        const price = await getTokenPriceUsd(pos.tokenAddress);
        if (!price) {
          results.push({ id: pos.id, token: pos.tokenSymbol, status: "no_price" });
          continue;
        }
        const currentPriceUsd = price.priceUsd;

        // ── PENDING_BUY: hanya eksekusi jika ada trigger price ───────────────
        // Tanpa trigger price = direct buy — sudah dieksekusi oleh buy/route.ts,
        // jangan ikut beli lagi dari sini (cegah double buy).
        if (pos.status === "pending_buy") {
          const triggerPrice = pos.buyTriggerPriceUsd ? parseFloat(pos.buyTriggerPriceUsd) : null;
          if (triggerPrice === null) {
            results.push({ id: pos.id, token: pos.tokenSymbol, status: "pending_no_trigger_skip" });
            continue;
          }
          if (currentPriceUsd > triggerPrice) {
            results.push({ id: pos.id, token: pos.tokenSymbol, status: "waiting_buy", currentPriceUsd, triggerPrice });
            continue;
          }

          const buyAmountWei = parseUnits(pos.buyAmountEth, 18);
          const buyQuote = await getBuyQuote({
            tokenAddress: pos.tokenAddress,
            buyAmountWei,
            slippageBps,
            senderAddress: account.address,
          });
          if (!buyQuote) {
            results.push({ id: pos.id, token: pos.tokenSymbol, status: "no_buy_quote" });
            continue;
          }

          try {
            const txHash = await signAndSend({
              account,
              to: buyQuote.target,
              data: buyQuote.data,
              value: buyQuote.value,
            });

            const buyReceipt = await waitReceipt(txHash, 45000);
            const tokensReceived = buyReceipt
              ? parseTokensReceived(buyReceipt, pos.tokenAddress, account.address)
              : null;
            const ethUsdAtBuy = await fetchEthUsdRate();

            await updatePositionBuy(pos.id, {
              buyTxHash: txHash,
              buyPriceUsd: currentPriceUsd.toString(),
              buyPriceEth: price.priceNative.toString(),
              ethUsdAtBuy: ethUsdAtBuy.toFixed(2),
              tokensReceived: tokensReceived ?? undefined,
              status: "active",
            });
            triggered++;
            results.push({ id: pos.id, token: pos.tokenSymbol, status: "bought", txHash, route: buyQuote.route });
          } catch (e) {
            const msg = e instanceof Error ? e.message.slice(0, 200) : "Buy failed";
            await updatePositionBuy(pos.id, { status: "buy_failed", errorMessage: msg });
            results.push({ id: pos.id, token: pos.tokenSymbol, status: "buy_failed", error: msg });
          }
          continue;
        }

        // ── ACTIVE: monitor TP/SL ─────────────────────────────────────────────
        if (pos.status !== "active") continue;

        const buyEth = parseFloat(pos.buyAmountEth);

        // Fetch on-chain balance + decimals in parallel (once per position)
        // Using actual decimals prevents 10^12x error for 6-decimal tokens (USDC etc.)
        const [balance, decimals] = await Promise.all([
          getTokenBalance(pos.tokenAddress, account.address),
          getTokenDecimals(pos.tokenAddress),
        ]);

        // Determine how many tokens we hold
        // Priority: on-chain balance (always accurate) > DB tokensReceived (fallback)
        let tokensHeld = 0;
        if (balance > BigInt(0)) {
          tokensHeld = rawBalanceToFloat(balance, decimals);
        } else if (pos.tokensReceived) {
          try {
            const rawBig = BigInt(pos.tokensReceived);
            if (rawBig > BigInt(0)) {
              tokensHeld = rawBalanceToFloat(rawBig, decimals);
            }
          } catch { /* fall through */ }
        }

        if (tokensHeld === 0 || buyEth === 0) {
          results.push({ id: pos.id, token: pos.tokenSymbol, status: "no_data", note: `tokensHeld=${tokensHeld} buyEth=${buyEth}` });
          continue;
        }

        // ── PnL calculation ───────────────────────────────────────────────────
        // Primary (ETH-based): priceNative > 0 = verified ETH/WETH pair from DexScreener
        //   ethNow = tokensHeld × priceNative
        //   pnlPct = (ethNow − buyEth) / buyEth × 100
        //
        // Fallback (USD-based): token hanya punya USDC/VIRTUAL pair
        //   pnlPct = (tokensHeld × priceUsd − buyEth × ethUsdAtBuy) / (buyEth × ethUsdAtBuy) × 100
        let ethNow: number;
        let pricePct: number;

        if (price.priceNative > 0) {
          ethNow = tokensHeld * price.priceNative;
          pricePct = ((ethNow - buyEth) / buyEth) * 100;
        } else if (price.priceUsd > 0) {
          // One call for current ETH/USD — reused for both cost basis (if missing from DB)
          // and converting currentValueUsd back to ETH
          const currentEthUsd = await fetchEthUsdRate();
          const ethUsdAtBuy = pos.ethUsdAtBuy ? parseFloat(pos.ethUsdAtBuy) : currentEthUsd;
          const currentValueUsd = tokensHeld * price.priceUsd;
          const buyValueUsd = buyEth * ethUsdAtBuy;
          pricePct = buyValueUsd > 0 ? ((currentValueUsd - buyValueUsd) / buyValueUsd) * 100 : 0;
          ethNow = currentEthUsd > 0 ? currentValueUsd / currentEthUsd : buyEth;
        } else {
          results.push({ id: pos.id, token: pos.tokenSymbol, status: "no_data", note: "no price data" });
          continue;
        }

        // Zero balance = token already sold externally (e.g. via wallet app)
        if (balance === BigInt(0)) {
          await closePosition(pos.id, {
            sellTxHash: pos.sellTxHash ?? "0x0000000000000000000000000000000000000000000000000000000000000000",
            sellPriceUsd: currentPriceUsd.toString(),
            sellAmountEth: ethNow.toFixed(8),
            pnlEth: (ethNow - buyEth).toFixed(8),
            pnlPct: pricePct.toFixed(2),
            closeReason: "manual_sell",
          });
          triggered++;
          results.push({ id: pos.id, token: pos.tokenSymbol, status: "closed_zero_balance", pnlPct: pricePct.toFixed(2) });
          continue;
        }

        const tp = pos.takeProfitPct ? parseFloat(pos.takeProfitPct) : null;
        const sl = pos.stopLossPct ? parseFloat(pos.stopLossPct) : null;
        const tpPrice = pos.sellTargetPriceUsd ? parseFloat(pos.sellTargetPriceUsd) : null;

        const shouldTP = (tp !== null && pricePct >= tp) || (tpPrice !== null && currentPriceUsd >= tpPrice);
        const shouldSL = sl !== null && pricePct <= -sl;

        results.push({
          id: pos.id, token: pos.tokenSymbol,
          ethSpent: buyEth, ethNow: ethNow.toFixed(8),
          changePct: pricePct.toFixed(2), tp, sl, tpPrice,
          trigger: shouldTP ? "take_profit" : shouldSL ? "stop_loss" : "hold",
        });

        if (!shouldTP && !shouldSL) continue;
        const reason = shouldTP ? "take_profit" : "stop_loss";

        // Sell only the amount we bought
        let sellAmount: bigint;
        if (pos.tokensReceived) {
          try {
            const recorded = BigInt(pos.tokensReceived);
            sellAmount = recorded < balance ? recorded : balance;
          } catch { sellAmount = balance; }
        } else {
          sellAmount = balance;
        }

        const sellQuote = await getSellQuote({
          tokenAddress: pos.tokenAddress,
          sellAmount,
          slippageBps,
          senderAddress: account.address,
          account,
        });
        if (!sellQuote) {
          results[results.length - 1] = { ...results[results.length - 1], status: "no_sell_quote" };
          continue;
        }

        try {
          const sellTxHash = await signAndSend({
            account,
            to: sellQuote.target,
            data: sellQuote.data,
            value: sellQuote.value,
          });

          const receipt = await waitReceipt(sellTxHash, 50000);
          if (!receipt) {
            results[results.length - 1] = { ...results[results.length - 1], status: "sell_pending", sellTxHash };
            continue;
          }
          if (receipt.status === "0x0") {
            results[results.length - 1] = { ...results[results.length - 1], status: "sell_reverted", sellTxHash };
            continue;
          }

          // Parse actual ETH received from receipt
          const ethReceived = parseEthReceived(receipt, account.address);
          const buyEthSpent = parseFloat(pos.buyAmountEth);
          let sellAmountEth: string;
          let pnlEth: string;
          let finalPnlPct: string;

          if (ethReceived !== null && ethReceived > 0) {
            sellAmountEth = ethReceived.toFixed(8);
            pnlEth = (ethReceived - buyEthSpent).toFixed(8);
            finalPnlPct = buyEthSpent > 0
              ? (((ethReceived - buyEthSpent) / buyEthSpent) * 100).toFixed(2)
              : pricePct.toFixed(2);
          } else {
            // Fallback to price-based estimate
            sellAmountEth = (buyEthSpent + (buyEthSpent * pricePct / 100)).toFixed(8);
            pnlEth = (parseFloat(sellAmountEth) - buyEthSpent).toFixed(8);
            finalPnlPct = pricePct.toFixed(2);
          }

          await closePosition(pos.id, {
            sellTxHash,
            sellPriceUsd: currentPriceUsd.toString(),
            sellAmountEth,
            pnlEth,
            pnlPct: finalPnlPct,
            closeReason: reason,
          });
          triggered++;
          results[results.length - 1] = {
            ...results[results.length - 1],
            status: "sold", sellTxHash, route: sellQuote.route,
          };
        } catch (e) {
          const msg = e instanceof Error ? e.message.slice(0, 200) : "Sell failed";
          results[results.length - 1] = { ...results[results.length - 1], status: "sell_failed", error: msg };
        }
      }
    }

    return NextResponse.json({ checked: positions.length, triggered, results });
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message : "Unknown" }, { status: 500 });
  }
}
