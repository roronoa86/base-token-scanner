/**
 * GET /api/trader/balance?fid=X&tokenAddress=Y
 *
 * Returns the SNIPER WALLET's on-chain token balance for a given token.
 * This is the "wallet crypto" approach — reads directly from Base chain,
 * not from DB receipts. Always accurate regardless of transfer/slippage.
 *
 * Used by the UI to get the real token quantity for PnL calculation.
 */
import { NextRequest, NextResponse } from "next/server";
import { requireAuthForFid } from "@/lib/auth-middleware";
import { getSniperSettings } from "@/db/actions/sniper-actions";
import { decrypt, isEncrypted } from "@/lib/crypto";
import { privateKeyToAccount } from "viem/accounts";

const RPC_URL = process.env.BASE_RPC_URL || "https://base-rpc.publicnode.com";

async function getOnChainBalance(token: string, wallet: string): Promise<bigint> {
  try {
    const data = "0x70a08231000000000000000000000000" + wallet.slice(2).toLowerCase();
    const res = await fetch(RPC_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", method: "eth_call", params: [{ to: token, data }, "latest"], id: 1 }),
      next: { revalidate: 0 },
    });
    const d = await res.json();
    return d.result && d.result !== "0x" ? BigInt(d.result) : BigInt(0);
  } catch { return BigInt(0); }
}

async function getDecimals(token: string): Promise<number> {
  try {
    const res = await fetch(RPC_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", method: "eth_call", params: [{ to: token, data: "0x313ce567" }, "latest"], id: 2 }),
      next: { revalidate: 3600 },
    });
    const d = await res.json();
    return d.result && d.result !== "0x" ? parseInt(d.result, 16) : 18;
  } catch { return 18; }
}

export async function GET(request: NextRequest) {
  const fid = parseInt(request.nextUrl.searchParams.get("fid") ?? "0");
  const tokenAddress = request.nextUrl.searchParams.get("tokenAddress")?.toLowerCase();

  if (!fid) return NextResponse.json({ error: "fid wajib" }, { status: 400 });
  if (!tokenAddress || !/^0x[0-9a-f]{40}$/.test(tokenAddress)) {
    return NextResponse.json({ error: "tokenAddress tidak valid" }, { status: 400 });
  }

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  try {
    // Get sniper wallet address from private key
    const settings = await getSniperSettings(fid);
    if (!settings?.privateKeyEncrypted) {
      return NextResponse.json({ error: "Private key belum diset" }, { status: 400 });
    }

    const rawKey = isEncrypted(settings.privateKeyEncrypted)
      ? await decrypt(settings.privateKeyEncrypted)
      : settings.privateKeyEncrypted;
    const pk = rawKey.startsWith("0x") ? rawKey as `0x${string}` : `0x${rawKey}` as `0x${string}`;
    const account = privateKeyToAccount(pk);
    const sniperWallet = account.address;

    // Read on-chain balance directly — same as any crypto wallet
    const [balanceRaw, decimals] = await Promise.all([
      getOnChainBalance(tokenAddress, sniperWallet),
      getDecimals(tokenAddress),
    ]);

    // Safe BigInt → float
    // CRITICAL: must use BigInt(10n ** BigInt(decimals)), NOT BigInt(10 ** decimals)
    // because 10 ** 18 in JS Number loses precision (float64 limit) → wrong divisor
    const divisor = 10n ** BigInt(decimals);
    const wholePart = balanceRaw / divisor;
    const fracPart  = balanceRaw % divisor;
    const balanceFloat = Number(wholePart) + Number(fracPart) / Number(divisor);

    return NextResponse.json({
      sniperWallet,
      tokenAddress,
      balanceRaw: balanceRaw.toString(),
      balance: balanceFloat,
      decimals,
      hasBalance: balanceRaw > BigInt(0),
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Unknown" }, { status: 500 });
  }
}
