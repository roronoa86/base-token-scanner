/**
 * GET /api/clanker/test-poll
 * Test manual: jalankan cron scan token Clanker sekali, tanpa eksekusi buy.
 * Return: jumlah token ditemukan, berapa yang lolos filter, info liquidity.
 */
import { NextResponse } from "next/server";
import {
  getAllActiveClankerSnipers,
  hasAlreadySniped,
  countTodaySnipes,
} from "@/db/actions/clanker-actions";

const CLANKER_API = "https://www.clanker.world/api/tokens";

interface ClankerToken {
  id: number;
  contract_address: string;
  name: string;
  symbol: string;
  deployed_at: string;
  pair?: string;
  pool_address?: string;
  chain_id?: number;
}

async function fetchRecentClankerTokens(): Promise<ClankerToken[]> {
  try {
    // Page 1 — ambil 20 token terbaru + cursor untuk page 2
    const res1 = await fetch(
      `${CLANKER_API}?sortBy=deployed-at&limit=20&chainId=8453`,
      { next: { revalidate: 0 } },
    );
    if (!res1.ok) return [];
    const d1 = await res1.json();
    const page1Tokens: ClankerToken[] = Array.isArray(d1) ? d1 : (d1.data ?? []);
    const cursor: string = d1.cursor ?? "";

    // Page 2 — pakai cursor dari page 1 (bukan ?page=2 yang return duplikat)
    const tokens: ClankerToken[] = [...page1Tokens];
    if (cursor) {
      const res2 = await fetch(
        `${CLANKER_API}?sortBy=deployed-at&limit=20&chainId=8453&cursor=${encodeURIComponent(cursor)}`,
        { next: { revalidate: 0 } },
      );
      if (res2.ok) {
        const d2 = await res2.json();
        tokens.push(...(Array.isArray(d2) ? d2 : (d2.data ?? [])));
      }
    }

    return tokens;
  } catch {
    return [];
  }
}

/**
 * Fetch volume.h1 dari GeckoTerminal — update lebih cepat dari DexScreener untuk token baru.
 */
async function fetchVolumeH1(tokenAddress: string): Promise<{ volumeH1: number; buysM5: number; buysH1: number; pairExists: boolean }> {
  try {
    const res = await fetch(
      `https://api.geckoterminal.com/api/v2/networks/base/tokens/${tokenAddress}/pools?page=1`,
      { headers: { Accept: "application/json" }, next: { revalidate: 0 } },
    );
    if (!res.ok) return { volumeH1: 0, buysM5: 0, buysH1: 0, pairExists: false };
    const data = await res.json();
    const pools = data.data ?? [];
    if (!pools.length) return { volumeH1: 0, buysM5: 0, buysH1: 0, pairExists: false };

    const best = pools.reduce((a: typeof pools[0], b: typeof pools[0]) =>
      parseFloat(b.attributes?.volume_usd?.h1 ?? "0") > parseFloat(a.attributes?.volume_usd?.h1 ?? "0") ? b : a
    );
    const attr = best.attributes ?? {};
    return {
      volumeH1: parseFloat(attr.volume_usd?.h1 ?? "0"),
      buysM5: attr.transactions?.m5?.buys ?? 0,
      buysH1: attr.transactions?.h1?.buys ?? 0,
      pairExists: true,
    };
  } catch {
    return { volumeH1: 0, buysM5: 0, buysH1: 0, pairExists: false };
  }
}

export async function GET() {
  try {
    // 1. Ambil token dari Clanker
    const tokens = await fetchRecentClankerTokens();
    if (!tokens.length) {
      return NextResponse.json({
        ok: false,
        message: "Clanker API tidak mengembalikan token. Mungkin API down.",
        tokensFetched: 0,
      });
    }

    // 2. Ambil semua sniper aktif (untuk context filter)
    const activeSnipers = await getAllActiveClankerSnipers();

    const tokenSample = tokens.slice(0, 5).map((t) => ({
      symbol: t.symbol,
      name: t.name,
      address: t.contract_address,
      deployedAt: t.deployed_at,
      ageMin: Math.round((Date.now() - new Date(t.deployed_at).getTime()) / 60_000),
    }));

    // 3. Cek filter per sniper (tanpa buy)
    const perSniper: object[] = [];
    for (const sniper of activeSnipers) {
      const fid = sniper.fid;
      const minLiq = sniper.minLiquidityUsd;
      const maxAgeMs = (sniper.maxTokenAgeMin ?? 15) * 60 * 1000;
      const maxBuys = sniper.maxBuysPerDay;
      const todayCount = await countTodaySnipes(fid);

      // Filter usia
      const recentTokens = tokens.filter(
        (t) => Date.now() - new Date(t.deployed_at).getTime() <= maxAgeMs,
      );

      // Cek duplikat
      const notSniped: ClankerToken[] = [];
      for (const t of recentTokens) {
        const addr = t.contract_address?.toLowerCase();
        if (!addr || !/^0x[0-9a-f]{40}$/.test(addr)) continue;
        const already = await hasAlreadySniped(fid, addr);
        if (!already) notSniped.push(t);
      }

      // Cek sample 5 token — parallel semua GeckoTerminal calls sekaligus
      const sampleTokens = notSniped.slice(0, 5);
      const sampleAddrs = sampleTokens.map((t) => t.contract_address?.toLowerCase() ?? "");

      const activities = await Promise.all(
        sampleAddrs.map((addr) => addr ? fetchVolumeH1(addr) : Promise.resolve({ volumeH1: 0, buysM5: 0, buysH1: 0, pairExists: false }))
      );

      const liquidityResults: object[] = sampleTokens.map((t, i) => {
        const addr = sampleAddrs[i];
        const act = activities[i];
        const volumeH1 = act.volumeH1;
        const passes = minLiq === 0 || volumeH1 >= minLiq;
        return {
          symbol: t.symbol,
          address: addr,
          ageMin: Math.round((Date.now() - new Date(t.deployed_at).getTime()) / 60_000),
          volumeH1: parseFloat(volumeH1.toFixed(2)),
          buysM5: act.buysM5,
          buysH1: act.buysH1,
          wouldPass: passes,
          reason: minLiq === 0 ? "filter_off" : passes ? `ok (vol $${volumeH1.toFixed(2)} >= $${minLiq})` : `vol_too_low ($${volumeH1.toFixed(2)} < $${minLiq})`,
        };
      });

      perSniper.push({
        fid,
        dailyLimit: `${todayCount}/${maxBuys}`,
        maxTokenAgeMin: sniper.maxTokenAgeMin ?? 15,
        minLiquidityUsd: minLiq,
        recentTokensInWindow: recentTokens.length,
        notYetSniped: notSniped.length,
        liquiditySample: liquidityResults,
      });
    }

    return NextResponse.json({
      ok: true,
      message: `Scan OK — ${tokens.length} token diambil dari Clanker`,
      tokensFetched: tokens.length,
      activeSnipers: activeSnipers.length,
      tokenSample,
      perSniper,
    });
  } catch (err) {
    return NextResponse.json({
      ok: false,
      message: err instanceof Error ? err.message : "Error tidak diketahui",
      tokensFetched: 0,
    }, { status: 500 });
  }
}
