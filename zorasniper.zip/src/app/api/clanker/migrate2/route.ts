/**
 * POST /api/clanker/migrate2
 * Tambah kolom max_token_age_min ke tabel clanker_sniper_settings
 * Jalankan SEKALI setelah deploy, lalu hapus file ini.
 */
import { NextResponse } from "next/server";
import { db } from "@/neynar-db-sdk/db";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    // Tambah kolom baru kalau belum ada
    await db.execute(sql`
      ALTER TABLE clanker_sniper_settings
      ADD COLUMN IF NOT EXISTS max_token_age_min integer NOT NULL DEFAULT 15
    `);

    return NextResponse.json({ success: true, message: "Kolom max_token_age_min berhasil ditambah" });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Unknown" }, { status: 500 });
  }
}
