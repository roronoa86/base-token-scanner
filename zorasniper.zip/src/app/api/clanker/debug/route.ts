/**
 * GET /api/clanker/debug
 * Cek langsung: apakah Clanker API bisa diakses + berapa token yang ada
 */
import { NextResponse } from "next/server";
import { getAllActiveClankerSnipers } from "@/db/actions/clanker-actions";

export async function GET() {
  const results: Record<string, unknown> = {};

  // 1. Cek active snipers di DB
  try {
    const snipers = await getAllActiveClankerSnipers();
    results.active_snipers = snipers.map(s => ({
      fid: s.fid,
      isEnabled: s.isEnabled,
      buyAmountEth: s.buyAmountEth,
      minLiquidityUsd: s.minLiquidityUsd,
      maxTokenAgeMin: s.maxTokenAgeMin,
      maxBuysPerDay: s.maxBuysPerDay,
    }));
  } catch (e) {
    results.active_snipers_error = e instanceof Error ? e.message : "unknown";
  }

  // 2. Cek Clanker API
  try {
    const res = await fetch(
      "https://www.clanker.world/api/tokens?sortBy=deployed-at&limit=10&chainId=8453",
      { next: { revalidate: 0 } },
    );
    results.clanker_api_status = res.status;
    if (res.ok) {
      const raw = await res.json();
      const tokens = Array.isArray(raw) ? raw : (raw.data ?? raw.tokens ?? []);
      const now = Date.now();
      results.clanker_total = tokens.length;
      results.clanker_tokens = tokens.slice(0, 5).map((t: {
        symbol?: string;
        contract_address?: string;
        deployed_at?: string;
        pair?: { liquidity_usd?: number };
      }) => ({
        symbol: t.symbol,
        address: t.contract_address,
        age_min: t.deployed_at ? Math.round((now - new Date(t.deployed_at).getTime()) / 60000) : null,
        liquidity_usd: t.pair?.liquidity_usd ?? 0,
      }));
    } else {
      results.clanker_api_body = await res.text().catch(() => "unreadable");
    }
  } catch (e) {
    results.clanker_api_error = e instanceof Error ? e.message : "unknown";
  }

  // 3. Cek DexScreener (fallback liquidity)
  try {
    const res = await fetch(
      "https://api.dexscreener.com/latest/dex/tokens/0x4ed4e862860bed51a9570b96d89af5e1b0efefed",
      { next: { revalidate: 0 } },
    );
    results.dexscreener_status = res.status;
  } catch (e) {
    results.dexscreener_error = e instanceof Error ? e.message : "unknown";
  }

  return NextResponse.json(results, { status: 200 });
}
