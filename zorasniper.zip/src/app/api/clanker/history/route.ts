import { NextRequest, NextResponse } from "next/server";
import { getClankerSnipeHistory } from "@/db/actions/clanker-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";

export async function GET(request: NextRequest) {
  const fid = parseInt(request.nextUrl.searchParams.get("fid") ?? "0");
  if (!fid) return NextResponse.json({ error: "fid wajib" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  const history = await getClankerSnipeHistory(fid, 50);
  return NextResponse.json({ history });
}
