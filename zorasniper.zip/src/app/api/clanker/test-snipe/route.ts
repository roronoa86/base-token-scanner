/**
 * POST /api/clanker/test-snipe
 * Test manual: beli 1 token Clanker menggunakan settings aktif user.
 * Sama persis dengan flow cron, tapi dipanggil manual.
 */
import { NextResponse } from "next/server";
import { privateKeyToAccount } from "viem/accounts";
import { parseUnits } from "viem";
import { decrypt, isEncrypted } from "@/lib/crypto";
import { getSniperSettings } from "@/db/actions/sniper-actions";
import {
  getClankerSettings,
  hasAlreadySniped,
  createSnipeLog,
  updateSnipeLog,
} from "@/db/actions/clanker-actions";
import { getBuyQuote, signAndSend, waitReceipt, fetchEthUsdRate, parseTokensReceived } from "@/lib/swap-engine";
import { privateConfig } from "@/config/private-config";
import { publicConfig } from "@/config/public-config";

export async function POST(request: Request) {
  const logs: string[] = [];

  try {
    const body = await request.json();
    const { fid, tokenAddress, tokenName, tokenSymbol } = body;

    if (!fid || !tokenAddress) {
      return NextResponse.json({ error: "fid dan tokenAddress wajib" }, { status: 400 });
    }

    const addr = tokenAddress.toLowerCase();
    logs.push(`Token: ${addr}`);

    // 1. Load clanker settings user
    const clankerSettings = await getClankerSettings(fid);
    if (!clankerSettings) {
      return NextResponse.json({ error: "Clanker settings tidak ditemukan untuk FID ini", logs }, { status: 404 });
    }
    logs.push(`Settings: buyAmt=${clankerSettings.buyAmountEth} ETH, slippage=${clankerSettings.slippageBps}bps`);

    // 2. Cek anti-duplikat
    const already = await hasAlreadySniped(fid, addr);
    if (already) {
      logs.push("SKIP: token ini sudah pernah di-snipe sebelumnya (anti-duplikat)");
      return NextResponse.json({ skipped: true, reason: "already_sniped", logs });
    }

    // 3. Load wallet dari sniper settings utama
    const sniperSettings = await getSniperSettings(fid);
    if (!sniperSettings?.privateKeyEncrypted || !sniperSettings.walletAddress) {
      logs.push("ERROR: wallet belum di-setup di tab Sniper");
      return NextResponse.json({ error: "Wallet belum di-setup. Tambahkan private key di tab Sniper dulu.", logs }, { status: 400 });
    }

    const rawKey = isEncrypted(sniperSettings.privateKeyEncrypted)
      ? await decrypt(sniperSettings.privateKeyEncrypted)
      : sniperSettings.privateKeyEncrypted;
    const pk = rawKey.startsWith("0x") ? (rawKey as `0x${string}`) : (`0x${rawKey}` as `0x${string}`);
    const account = privateKeyToAccount(pk);
    logs.push(`Wallet: ${account.address}`);

    // 4. Cek volume dari GeckoTerminal (update lebih cepat dari DexScreener untuk token baru)
    let liquidityUsd = 0;
    let buysM5 = 0;
    let buysH1 = 0;
    try {
      const gtRes = await fetch(
        `https://api.geckoterminal.com/api/v2/networks/base/tokens/${addr}/pools?page=1`,
        { headers: { Accept: "application/json" }, next: { revalidate: 0 } },
      );
      if (gtRes.ok) {
        const gtData = await gtRes.json();
        const pools = gtData.data ?? [];
        if (pools.length) {
          const best = pools.reduce((a: typeof pools[0], b: typeof pools[0]) =>
            parseFloat(b.attributes?.volume_usd?.h1 ?? "0") > parseFloat(a.attributes?.volume_usd?.h1 ?? "0") ? b : a
          );
          const attr = best.attributes ?? {};
          liquidityUsd = Math.round(parseFloat(attr.volume_usd?.h1 ?? "0"));
          buysM5 = attr.transactions?.m5?.buys ?? 0;
          buysH1 = attr.transactions?.h1?.buys ?? 0;
        }
      }
    } catch { /* silent */ }
    logs.push(`GeckoTerminal — Vol h1: $${liquidityUsd} | Buys m5: ${buysM5} | Buys h1: ${buysH1}`);

    // 5. Log snipe attempt
    const snipeLog = await createSnipeLog({
      fid,
      tokenAddress: addr,
      tokenName: tokenName ?? addr,
      tokenSymbol: tokenSymbol ?? "?",
      volumeUsdAtSnipe: Math.round(liquidityUsd),
      buyAmountEth: clankerSettings.buyAmountEth.toString(),
    });
    logs.push(`Snipe log created: ${snipeLog.id}`);

    // 6. Get quote
    const buyAmountWei = parseUnits(clankerSettings.buyAmountEth.toString(), 18);
    logs.push(`Getting quote for ${clankerSettings.buyAmountEth} ETH...`);

    const quote = await getBuyQuote({
      tokenAddress: addr,
      buyAmountWei,
      slippageBps: clankerSettings.slippageBps,
      senderAddress: account.address,
    });

    if (!quote) {
      const errMsg = "Semua aggregator gagal — token mungkin belum ada pool aktif atau liquidity terlalu rendah";
      await updateSnipeLog(snipeLog.id, { status: "failed", errorMessage: errMsg });
      logs.push(`ERROR: ${errMsg}`);
      return NextResponse.json({ success: false, error: errMsg, logs }, { status: 400 });
    }
    logs.push(`Quote OK via ${quote.route}: target=${quote.target}`);

    // 7. Send TX
    const txHash = await signAndSend({
      account,
      to: quote.target,
      data: quote.data,
      value: quote.value,
    });
    logs.push(`TX sent: ${txHash}`);

    // 8. Wait receipt
    const receipt = await waitReceipt(txHash, 45000);
    const tokensReceived = receipt ? parseTokensReceived(receipt, addr, account.address) : null;
    const ethUsdRate = await fetchEthUsdRate();
    logs.push(`TX confirmed: ${receipt ? "yes" : "pending"}`);

    // 9. Update log
    await updateSnipeLog(snipeLog.id, { status: "success", txHash });

    // 10. Kirim notif
    try {
      await fetch("https://api.neynar.com/v2/farcaster/frame/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": privateConfig.neynarApiKey },
        body: JSON.stringify({
          target_fids: [fid],
          notification: {
            title: `🔫 Test snipe berhasil: $${tokenSymbol ?? "?"}`,
            body: `Beli ${clankerSettings.buyAmountEth} ETH · Cek riwayat di tab Clanker`,
            target_url: publicConfig.homeUrl,
            uuid: txHash,
          },
        }),
      });
      logs.push("Notif terkirim");
    } catch { logs.push("Notif gagal (tidak kritis)"); }

    return NextResponse.json({
      success: true,
      txHash,
      route: quote.route,
      buyAmountEth: clankerSettings.buyAmountEth,
      liquidityUsd: Math.round(liquidityUsd),
      tokensReceived: tokensReceived ?? null,
      ethUsdRate,
      basescanUrl: `https://basescan.org/tx/${txHash}`,
      logs,
    });

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logs.push(`FATAL ERROR: ${msg}`);
    return NextResponse.json({ success: false, error: msg, logs }, { status: 500 });
  }
}
