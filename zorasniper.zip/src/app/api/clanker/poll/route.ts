/**
 * GET /api/clanker/poll
 * Cron: scan token Clanker baru, auto-snipe jika liquidity >= threshold user.
 *
 * Flow:
 *   1. Ambil semua user yang punya clanker sniper aktif
 *   2. Fetch token terbaru dari Clanker API (sort=createdAt, desc)
 *   3. Filter: skip jika sudah pernah di-snipe (anti-duplicate)
 *   4. Cek volume h1 via GeckoTerminal, skip jika < minLiquidityUsd
 *   5. Cek maxBuysPerDay — skip jika sudah mentok batas hari ini
 *   6. Buy via swap engine (Paraswap → Kyber → LI.FI → Zora)
 *   7. Log ke clanker_snipe_log
 */
import { NextResponse } from "next/server";
import { timingSafeEqual } from "crypto";
import { privateKeyToAccount } from "viem/accounts";
import { parseUnits } from "viem";
import { decrypt, isEncrypted } from "@/lib/crypto";
import { getSniperSettings } from "@/db/actions/sniper-actions";
import {
  getAllActiveClankerSnipers,
  hasAlreadySniped,
  createSnipeLog,
  updateSnipeLog,
  countTodaySnipes,
  upsertWatchList,
  getActiveWatchList,
  purgeExpiredWatchList,
} from "@/db/actions/clanker-actions";
import { getBuyQuote, signAndSend, waitReceipt, fetchEthUsdRate, parseTokensReceived } from "@/lib/swap-engine";
import { privateConfig } from "@/config/private-config";
import { publicConfig } from "@/config/public-config";

async function sendSnipeNotification(fid: number, tokenSymbol: string, buyAmountEth: string, txHash: string) {
  try {
    await fetch("https://api.neynar.com/v2/farcaster/frame/notifications", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": privateConfig.neynarApiKey,
      },
      body: JSON.stringify({
        target_fids: [fid],
        notification: {
          title: `🔫 Snipe berhasil: $${tokenSymbol}`,
          body: `Beli ${buyAmountEth} ETH · Cek riwayat di tab Clanker`,
          target_url: publicConfig.homeUrl,
          uuid: txHash, // idempotency key
        },
      }),
    });
  } catch (e) {
    console.error("[clanker-poll] notif error:", e instanceof Error ? e.message : e);
  }
}

// Endpoint resmi dari docs: https://www.clanker.world/api/tokens
const CLANKER_API = "https://www.clanker.world/api/tokens";

interface ClankerToken {
  id: number;
  contract_address: string;
  name: string;
  symbol: string;
  img_url?: string;
  deployed_at: string;
  pair?: string; // "WETH" atau string lain — bukan object
  pool_address?: string;
  type?: string;
  chain_id?: number;
  related?: {
    market?: {
      marketCap?: number;
      volume24h?: number;
      liquidity?: number;
    };
  };
}

async function fetchRecentClankerTokens(): Promise<ClankerToken[]> {
  try {
    // Page 1 — ambil 20 token terbaru + cursor untuk page 2
    const res1 = await fetch(
      `${CLANKER_API}?sortBy=deployed-at&limit=20&chainId=8453`,
      { next: { revalidate: 0 } },
    );
    if (!res1.ok) {
      console.warn("[clanker-poll] API page1 error:", res1.status);
      return [];
    }
    const d1 = await res1.json();
    const page1Tokens: ClankerToken[] = Array.isArray(d1) ? d1 : (d1.data ?? []);
    const cursor: string = d1.cursor ?? "";

    // Page 2 — pakai cursor dari page 1 (bukan ?page=2 yang return duplikat)
    const tokens: ClankerToken[] = [...page1Tokens];
    if (cursor) {
      const res2 = await fetch(
        `${CLANKER_API}?sortBy=deployed-at&limit=20&chainId=8453&cursor=${encodeURIComponent(cursor)}`,
        { next: { revalidate: 0 } },
      );
      if (res2.ok) {
        const d2 = await res2.json();
        tokens.push(...(Array.isArray(d2) ? d2 : (d2.data ?? [])));
      }
    }

    return tokens;
  } catch (e) {
    console.error("[clanker-poll] fetch error:", e instanceof Error ? e.message : e);
    return [];
  }
}

/**
 * Fetch trading activity dari GeckoTerminal — lebih cepat update dari DexScreener.
 *
 * Kenapa GeckoTerminal?
 * - transactions.m5.buys muncul lebih cepat (token 7 menit sudah ke-index)
 * - volume_usd.m5 lebih cepat dari DexScreener
 * - reserve_in_usd tidak akurat untuk Clanker (sama seperti DexScreener — include liquidity palsu)
 *
 * Filter yang dipakai:
 * - minLiquidityUsd user = min volume_usd.h1 (USD) — volume nyata dari transaksi
 * - Kalau minLiquidityUsd = 0 → skip filter, snipe semua
 *
 * Endpoint: GET /api/v2/networks/base/tokens/{address}/pools
 */
interface DexActivity {
  volumeH1: number;
  buysM5: number;
  buysH1: number;
  pairExists: boolean;
}

async function fetchDexActivity(tokenAddress: string): Promise<DexActivity> {
  try {
    const res = await fetch(
      `https://api.geckoterminal.com/api/v2/networks/base/tokens/${tokenAddress}/pools?page=1`,
      { headers: { Accept: "application/json" }, next: { revalidate: 0 } },
    );
    if (!res.ok) return { volumeH1: 0, buysM5: 0, buysH1: 0, pairExists: false };
    const data = await res.json();

    const pools = data.data ?? [];
    if (!pools.length) return { volumeH1: 0, buysM5: 0, buysH1: 0, pairExists: false };

    // Ambil pool dengan volume h1 terbesar
    const best = pools.reduce((a: typeof pools[0], b: typeof pools[0]) =>
      parseFloat(b.attributes?.volume_usd?.h1 ?? "0") > parseFloat(a.attributes?.volume_usd?.h1 ?? "0") ? b : a
    );
    const attr = best.attributes ?? {};

    return {
      volumeH1: parseFloat(attr.volume_usd?.h1 ?? "0"),
      buysM5: attr.transactions?.m5?.buys ?? 0,
      buysH1: attr.transactions?.h1?.buys ?? 0,
      pairExists: true,
    };
  } catch {
    return { volumeH1: 0, buysM5: 0, buysH1: 0, pairExists: false };
  }
}

export async function GET(request: Request) {
  // Auth: cron secret
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = request.headers.get("authorization") ?? "";
    const expected = `Bearer ${secret}`;
    try {
      const ok = timingSafeEqual(Buffer.from(auth), Buffer.from(expected));
      if (!ok) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    } catch {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  try {
    const activeSnipers = await getAllActiveClankerSnipers();
    if (!activeSnipers.length) return NextResponse.json({ checked: 0, sniped: 0 });

    // ── FASE 1: Ambil token baru dari Clanker API → masukkan ke watch list ──
    // expiresAt = deployedAt + maxTokenAge terpanjang dari semua active sniper
    const maxAgeMin = Math.max(...activeSnipers.map((s) => s.maxTokenAgeMin ?? 60));
    const newTokens = await fetchRecentClankerTokens();

    if (newTokens.length) {
      await upsertWatchList(
        newTokens
          .filter((t) => t.contract_address && /^0x[0-9a-fA-F]{40}$/.test(t.contract_address))
          .map((t) => {
            const deployedAt = new Date(t.deployed_at);
            const expiresAt = new Date(deployedAt.getTime() + maxAgeMin * 60 * 1000);
            return {
              tokenAddress: t.contract_address.toLowerCase(),
              tokenName: t.name,
              tokenSymbol: t.symbol,
              clankerTokenId: t.id,
              deployedAt,
              expiresAt,
            };
          })
      );
    }

    // ── FASE 2: Ambil SEMUA token aktif dari watch list (termasuk yang lama) ──
    const [watchListTokens] = await Promise.all([
      getActiveWatchList(),
      purgeExpiredWatchList(), // hapus expired sambil jalan
    ]);

    if (!watchListTokens.length) {
      return NextResponse.json({ fetched: newTokens.length, watching: 0, sniped: 0 });
    }

    console.log("[clanker-poll] watching:", watchListTokens.length, "tokens | snipers:", activeSnipers.length);

    let totalSniped = 0;
    const results: object[] = [];

    for (const sniper of activeSnipers) {
      const fid = sniper.fid;
      const minLiq = sniper.minLiquidityUsd;
      const maxBuys = sniper.maxBuysPerDay;
      const buyAmt = sniper.buyAmountEth.toString();
      const slippageBps = sniper.slippageBps ?? 500;
      const maxAgeMs = (sniper.maxTokenAgeMin ?? 15) * 60 * 1000;

      // Cek batas harian
      const todayCount = await countTodaySnipes(fid);
      if (todayCount >= maxBuys) {
        results.push({ fid, status: "daily_limit_reached", todayCount, maxBuys });
        continue;
      }

      // Load wallet
      const sniperSettings = await getSniperSettings(fid);
      if (!sniperSettings?.privateKeyEncrypted || !sniperSettings.walletAddress) {
        results.push({ fid, status: "no_wallet" });
        continue;
      }
      const rawKey = isEncrypted(sniperSettings.privateKeyEncrypted)
        ? await decrypt(sniperSettings.privateKeyEncrypted)
        : sniperSettings.privateKeyEncrypted;
      const pk = rawKey.startsWith("0x") ? (rawKey as `0x${string}`) : (`0x${rawKey}` as `0x${string}`);
      const account = privateKeyToAccount(pk);

      // Filter watch list sesuai usia sniper ini
      const candidateTokens = watchListTokens.filter((t) => {
        const ageMs = Date.now() - new Date(t.deployedAt).getTime();
        return ageMs <= maxAgeMs;
      });

      if (!candidateTokens.length) {
        results.push({ fid, status: "no_tokens_in_window", maxTokenAgeMin: sniper.maxTokenAgeMin ?? 15 });
        continue;
      }

      // ── PARALLEL: anti-duplikat semua kandidat sekaligus ──
      const dupChecks = await Promise.all(
        candidateTokens.map((t) => hasAlreadySniped(fid, t.tokenAddress))
      );
      const freshTokens = candidateTokens.filter((_, i) => !dupChecks[i]);

      if (!freshTokens.length) {
        results.push({ fid, status: "all_already_sniped", candidates: candidateTokens.length });
        continue;
      }

      // ── PARALLEL: GeckoTerminal semua fresh token sekaligus ──
      const activityMap = new Map<string, DexActivity>();
      if (minLiq > 0) {
        const activities = await Promise.all(
          freshTokens.map((t) => fetchDexActivity(t.tokenAddress))
        );
        freshTokens.forEach((t, i) => activityMap.set(t.tokenAddress, activities[i]));
      }

      const ethUsdRate = await fetchEthUsdRate();

      // ── SEQUENTIAL: buy ──
      for (const token of freshTokens) {
        const currentCount = await countTodaySnipes(fid);
        if (currentCount >= maxBuys) {
          results.push({ fid, status: "daily_limit_reached_mid_loop" });
          break;
        }

        const tokenAddress = token.tokenAddress;
        const activity = activityMap.get(tokenAddress);
        const volumeH1 = activity?.volumeH1 ?? 0;
        const buysM5 = activity?.buysM5 ?? 0;
        const buysH1 = activity?.buysH1 ?? 0;

        if (minLiq > 0 && volumeH1 < minLiq) {
          results.push({ fid, token: token.tokenSymbol, status: "volume_too_low", volumeH1, buysM5, buysH1, minLiq });
          continue;
        }

        const snipeLog = await createSnipeLog({
          fid,
          tokenAddress,
          tokenName: token.tokenName ?? undefined,
          tokenSymbol: token.tokenSymbol ?? undefined,
          clankerTokenId: token.clankerTokenId ?? undefined,
          volumeUsdAtSnipe: Math.round(volumeH1),
          buyAmountEth: buyAmt,
        });

        try {
          const buyAmountWei = parseUnits(buyAmt, 18);
          const quote = await getBuyQuote({ tokenAddress, buyAmountWei, slippageBps, senderAddress: account.address });

          if (!quote) {
            const errMsg = "Semua aggregator gagal — token mungkin belum ada pool aktif";
            await updateSnipeLog(snipeLog.id, { status: "failed", errorMessage: errMsg });
            results.push({ fid, token: token.tokenSymbol, status: "no_quote" });
            continue;
          }

          const txHash = await signAndSend({ account, to: quote.target, data: quote.data, value: quote.value });
          console.log("[clanker-poll] TX sent:", txHash, "token:", token.tokenSymbol, "route:", quote.route);

          const receipt = await waitReceipt(txHash, 45000);
          const tokensReceived = receipt ? parseTokensReceived(receipt, tokenAddress, account.address) : null;

          await updateSnipeLog(snipeLog.id, { status: "success", txHash });
          await sendSnipeNotification(fid, token.tokenSymbol ?? "?", buyAmt, txHash);

          totalSniped++;
          results.push({
            fid, token: token.tokenSymbol, tokenAddress,
            status: "sniped", txHash, route: quote.route,
            volumeH1: Math.round(volumeH1), buysM5, buysH1,
            tokensReceived: tokensReceived ?? null, ethUsdRate,
          });
        } catch (e) {
          const msg = e instanceof Error ? e.message.slice(0, 200) : "Buy failed";
          await updateSnipeLog(snipeLog.id, { status: "failed", errorMessage: msg });
          results.push({ fid, token: token.tokenSymbol, status: "buy_failed", error: msg });
        }
      }
    }

    return NextResponse.json({ fetched: newTokens.length, watching: watchListTokens.length, sniped: totalSniped, results });
  } catch (err) {
    console.error("[clanker-poll] error:", err);
    return NextResponse.json({ error: err instanceof Error ? err.message : "Unknown" }, { status: 500 });
  }
}
