import { NextRequest, NextResponse } from "next/server";
import { getClankerSettings, upsertClankerSettings } from "@/db/actions/clanker-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";

export async function GET(request: NextRequest) {
  const fid = parseInt(request.nextUrl.searchParams.get("fid") ?? "0");
  if (!fid) return NextResponse.json({ error: "fid wajib" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  const settings = await getClankerSettings(fid);
  // Return defaults jika belum ada row (user baru)
  return NextResponse.json(settings ?? {
    isEnabled: false,
    buyAmountEth: "0.001",
    slippageBps: 500,
    maxBuysPerDay: 5,
    minLiquidityUsd: 1000,
    maxTokenAgeMin: 15,
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { fid, ...rest } = body;
    if (!fid || typeof fid !== "number") return NextResponse.json({ error: "fid wajib" }, { status: 400 });

    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    const result = await upsertClankerSettings(fid, rest);
    if (result.error) return NextResponse.json({ error: result.error }, { status: 400 });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
