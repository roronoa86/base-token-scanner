import { NextRequest, NextResponse } from "next/server";
import { getPumpfunSnipeHistory, clearPumpfunSnipeHistory } from "@/db/actions/pumpfun-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";

export async function GET(request: NextRequest) {
  const fid = parseInt(request.nextUrl.searchParams.get("fid") ?? "0");
  if (!fid) return NextResponse.json({ error: "fid wajib" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  const history = await getPumpfunSnipeHistory(fid, 100);
  return NextResponse.json({ history });
}

export async function DELETE(request: NextRequest) {
  const fid = parseInt(request.nextUrl.searchParams.get("fid") ?? "0");
  if (!fid) return NextResponse.json({ error: "fid wajib" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  await clearPumpfunSnipeHistory(fid);
  return NextResponse.json({ success: true });
}
