/**
 * GET /api/pumpfun/test-poll
 * Simulasi scan Pump.fun — ambil token, cek filter. Tidak ada buy.
 */
import { NextResponse } from "next/server";
import {
  getAllActivePumpfunSnipers,
  hasAlreadySnipedPumpfun,
  countTodayPumpfunSnipes,
} from "@/db/actions/pumpfun-actions";

const PUMPFUN_API = "https://frontend-api-v3.pump.fun/coins";

interface PumpfunToken {
  mint: string;
  name: string;
  symbol: string;
  image_uri?: string;
  created_timestamp: number;
  usd_market_cap?: number;
  complete?: boolean;
}

async function fetchRecentPumpfunTokens(): Promise<PumpfunToken[]> {
  try {
    const res = await fetch(
      `${PUMPFUN_API}?sort=created_timestamp&order=DESC&limit=40&includeNsfw=false`,
      { headers: { Accept: "application/json" }, next: { revalidate: 0 } },
    );
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}


export async function GET() {
  try {
    const tokens = await fetchRecentPumpfunTokens();
    if (!tokens.length) {
      return NextResponse.json({
        ok: false,
        message: "Pump.fun API tidak mengembalikan token. Mungkin API down.",
        tokensFetched: 0,
      });
    }

    const activeSnipers = await getAllActivePumpfunSnipers();

    const tokenSample = tokens.slice(0, 5).map((t) => ({
      symbol: t.symbol,
      name: t.name,
      mint: t.mint,
      createdAt: new Date(t.created_timestamp).toISOString(),
      ageMin: Math.round((Date.now() - t.created_timestamp) / 60_000),
      graduated: t.complete ?? false,
      marketCapUsd: t.usd_market_cap ?? 0,
    }));

    const perSniper: object[] = [];
    for (const sniper of activeSnipers) {
      const fid = sniper.fid;
      const minVol = sniper.minVolumeUsd;
      const maxAgeMs = (sniper.maxTokenAgeMin ?? 15) * 60 * 1000;
      const maxBuys = sniper.maxBuysPerDay;
      const todayCount = await countTodayPumpfunSnipes(fid);

      // Filter usia
      const recentTokens = tokens.filter(
        (t) => Date.now() - t.created_timestamp <= maxAgeMs
      );

      // Cek duplikat
      const notSniped: PumpfunToken[] = [];
      for (const t of recentTokens) {
        if (!t.mint) continue;
        const already = await hasAlreadySnipedPumpfun(fid, t.mint);
        if (!already) notSniped.push(t);
      }

      // Sample 5 token — pakai market cap dari Pump.fun API (tidak perlu DexScreener)
      const sampleTokens = notSniped.slice(0, 5);

      const volumeSample: object[] = sampleTokens.map((t) => {
        const mcap = Math.round(t.usd_market_cap ?? 0);
        const passes = minVol === 0 || mcap >= minVol;
        return {
          symbol: t.symbol,
          mint: t.mint,
          ageMin: Math.round((Date.now() - t.created_timestamp) / 60_000),
          marketCapUsd: mcap,
          wouldPass: passes,
          reason: minVol === 0
            ? "filter_off"
            : passes
              ? `ok (mcap $${mcap.toLocaleString()} >= $${minVol})`
              : `mcap_too_low ($${mcap.toLocaleString()} < $${minVol})`,
        };
      });

      perSniper.push({
        fid,
        dailyLimit: `${todayCount}/${maxBuys}`,
        maxTokenAgeMin: sniper.maxTokenAgeMin ?? 15,
        minVolumeUsd: minVol,
        recentTokensInWindow: recentTokens.length,
        notYetSniped: notSniped.length,
        hasWallet: !!sniper.solanaWalletAddress,
        volumeSample,
      });
    }

    return NextResponse.json({
      ok: true,
      message: `Scan OK — ${tokens.length} token diambil dari Pump.fun`,
      tokensFetched: tokens.length,
      activeSnipers: activeSnipers.length,
      tokenSample,
      perSniper,
    });
  } catch (err) {
    return NextResponse.json({
      ok: false,
      message: err instanceof Error ? err.message : "Error tidak diketahui",
      tokensFetched: 0,
    }, { status: 500 });
  }
}
