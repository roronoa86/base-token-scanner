/**
 * GET /api/pumpfun/poll
 * Cron: scan token Pump.fun baru di Solana, auto-snipe jika market cap >= threshold.
 *
 * Filter utama: market cap dari Pump.fun API (akurat untuk token bonding curve).
 * DexScreener TIDAK dipakai karena token baru belum punya pair → selalu 0.
 *
 * Flow:
 *   1. Fetch 40 token terbaru dari Pump.fun API (incl. market cap)
 *   2. Upsert ke watch list DB (update market cap tiap run)
 *   3. Per sniper: filter usia → cek duplikat → filter market cap → buy
 */
import { NextResponse } from "next/server";
import { timingSafeEqual } from "crypto";
import {
  getAllActivePumpfunSnipers,
  hasAlreadySnipedPumpfun,
  countTodayPumpfunSnipes,
  createPumpfunSnipeLog,
  updatePumpfunSnipeLog,
  upsertPumpfunWatchList,
  getActivePumpfunWatchList,
  purgeExpiredPumpfunWatchList,
} from "@/db/actions/pumpfun-actions";
import { buyPumpfunToken } from "@/lib/solana-buy";

const PUMPFUN_API = "https://frontend-api-v3.pump.fun/coins";

interface PumpfunToken {
  mint: string;
  name: string;
  symbol: string;
  image_uri?: string;
  created_timestamp: number; // Unix ms
  usd_market_cap?: number;   // market cap USD — tersedia langsung dari API
  complete?: boolean;        // true = sudah graduate ke Raydium
}

async function fetchRecentPumpfunTokens(): Promise<PumpfunToken[]> {
  try {
    const res = await fetch(
      `${PUMPFUN_API}?sort=created_timestamp&order=DESC&limit=40&includeNsfw=false`,
      { headers: { Accept: "application/json" }, next: { revalidate: 0 } },
    );
    if (!res.ok) {
      console.warn("[pumpfun-poll] API error:", res.status);
      return [];
    }
    const data = await res.json();
    return Array.isArray(data) ? data : [];
  } catch (e) {
    console.error("[pumpfun-poll] fetch error:", e instanceof Error ? e.message : e);
    return [];
  }
}

/** Fetch market cap fresh untuk satu token — pakai sebelum buy untuk pastikan data akurat */
async function fetchFreshMarketCap(mintAddress: string): Promise<number | null> {
  try {
    const res = await fetch(
      `${PUMPFUN_API}/${mintAddress}`,
      { headers: { Accept: "application/json" }, next: { revalidate: 0 } },
    );
    if (!res.ok) return null;
    const data = await res.json();
    return typeof data?.usd_market_cap === "number" ? Math.round(data.usd_market_cap) : null;
  } catch {
    return null;
  }
}

export async function GET(request: Request) {
  // Auth: cron secret
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = request.headers.get("authorization") ?? "";
    const expected = `Bearer ${secret}`;
    try {
      const ok = timingSafeEqual(Buffer.from(auth), Buffer.from(expected));
      if (!ok) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    } catch {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  try {
    const activeSnipers = await getAllActivePumpfunSnipers();
    if (!activeSnipers.length) return NextResponse.json({ checked: 0, sniped: 0 });

    // ── FASE 1: Fetch token baru → masuk watch list ──
    const maxAgeMin = Math.max(...activeSnipers.map((s) => s.maxTokenAgeMin ?? 60));
    const newTokens = await fetchRecentPumpfunTokens();

    if (newTokens.length) {
      await upsertPumpfunWatchList(
        newTokens
          .filter((t) => t.mint && t.created_timestamp)
          .map((t) => {
            const createdTimestamp = new Date(t.created_timestamp);
            const expiresAt = new Date(createdTimestamp.getTime() + maxAgeMin * 60 * 1000);
            return {
              mintAddress: t.mint,
              tokenName: t.name,
              tokenSymbol: t.symbol,
              imageUri: t.image_uri,
              // Simpan market cap dari Pump.fun API — ini data real bonding curve
              marketCapUsd: t.usd_market_cap ? Math.round(t.usd_market_cap) : undefined,
              createdTimestamp,
              expiresAt,
            };
          })
      );
    }

    // ── FASE 2: Ambil SEMUA token aktif dari watch list ──
    const [watchListTokens] = await Promise.all([
      getActivePumpfunWatchList(),
      purgeExpiredPumpfunWatchList(),
    ]);

    if (!watchListTokens.length) {
      return NextResponse.json({ fetched: newTokens.length, watching: 0, sniped: 0 });
    }

    console.log("[pumpfun-poll] watching:", watchListTokens.length, "tokens | snipers:", activeSnipers.length);

    let totalSniped = 0;
    const results: object[] = [];

    for (const sniper of activeSnipers) {
      const fid = sniper.fid;
      const minVol = Number(sniper.minVolumeUsd ?? 0);
      const maxBuys = Number(sniper.maxBuysPerDay ?? 5);
      // Parse buyAmountSol dengan benar — Postgres numeric bisa return string dengan trailing zeros
      const buyAmtRaw = parseFloat(sniper.buyAmountSol.toString());
      if (isNaN(buyAmtRaw) || buyAmtRaw <= 0 || buyAmtRaw > 10) {
        results.push({ fid, status: "invalid_buy_amount", value: sniper.buyAmountSol });
        continue;
      }
      const buyAmt = buyAmtRaw.toString(); // "0.0015" bukan "0.00150000000"
      const maxAgeMs = (Number(sniper.maxTokenAgeMin) || 15) * 60 * 1000;

      console.log(`[pumpfun-poll] fid=${fid} | buyAmt=${buyAmt} SOL | minVol=$${minVol} | maxAge=${maxAgeMs/60000}m | maxBuys=${maxBuys}`);

      // Cek batas harian
      const todayCount = await countTodayPumpfunSnipes(fid);
      if (todayCount >= maxBuys) {
        results.push({ fid, status: "daily_limit_reached", todayCount, maxBuys });
        continue;
      }

      // Cek wallet Solana sudah di-setup — kalau belum, skip tanpa buat log
      if (!sniper.solanaPrivateKey || !sniper.solanaWalletAddress) {
        results.push({ fid, status: "no_solana_wallet" });
        continue;
      }

      // Filter usia
      const candidateTokens = watchListTokens.filter((t) => {
        const ageMs = Date.now() - new Date(t.createdTimestamp).getTime();
        return ageMs <= maxAgeMs;
      });

      if (!candidateTokens.length) {
        results.push({ fid, status: "no_tokens_in_window", maxTokenAgeMin: sniper.maxTokenAgeMin ?? 15 });
        continue;
      }

      // ── PARALLEL: anti-duplikat ──
      const dupChecks = await Promise.all(
        candidateTokens.map((t) => hasAlreadySnipedPumpfun(fid, t.mintAddress))
      );
      const freshTokens = candidateTokens.filter((_, i) => !dupChecks[i]);

      if (!freshTokens.length) {
        results.push({ fid, status: "all_already_sniped", candidates: candidateTokens.length });
        continue;
      }

      // ── SEQUENTIAL: filter market cap + buy ──
      // Pakai market cap dari Pump.fun API (tersimpan di watch list).
      // DexScreener TIDAK dipakai — token baru di bonding curve belum punya pair.
      for (const token of freshTokens) {
        const currentCount = await countTodayPumpfunSnipes(fid);
        if (currentCount >= maxBuys) {
          results.push({ fid, status: "daily_limit_reached_mid_loop" });
          break;
        }

        const mintAddress = token.mintAddress;

        // Fetch market cap fresh dari Pump.fun API — jangan pakai data stale dari DB
        const freshMcap = await fetchFreshMarketCap(mintAddress);
        const marketCap = freshMcap ?? token.marketCapUsd ?? 0;

        // Filter market cap — minVol=0 berarti semua lolos
        const passes = minVol === 0 || marketCap >= minVol;
        console.log(`[pumpfun-poll] ${token.tokenSymbol} | mcap=$${marketCap}${freshMcap !== null ? "(fresh)" : "(cached)"} | minVol=$${minVol} → ${passes ? "PASS" : "SKIP"}`);

        if (!passes) {
          results.push({ fid, token: token.tokenSymbol, status: "mcap_too_low", marketCap, minVol });
          continue;
        }

        // Buat snipe log
        const snipeLog = await createPumpfunSnipeLog({
          fid,
          mintAddress,
          tokenName: token.tokenName ?? undefined,
          tokenSymbol: token.tokenSymbol ?? undefined,
          volumeUsdAtSnipe: marketCap, // simpan market cap sebagai referensi
          buyAmountSol: buyAmt,
        });

        // ── EKSEKUSI BUY ──
        console.log(`[pumpfun-poll] 🛒 ${token.tokenSymbol ?? mintAddress} | ${buyAmt} SOL | mcap=$${marketCap}`);

        const buyResult = await buyPumpfunToken(
          sniper.solanaPrivateKey!,
          mintAddress,
          buyAmt,
          sniper.slippageBps ?? 1000,
        );

        if (buyResult.success) {
          await updatePumpfunSnipeLog(snipeLog.id, {
            status: "success",
            txSignature: buyResult.txSignature,
          });
          totalSniped++;
          results.push({ fid, token: token.tokenSymbol, mintAddress, status: "success", txSignature: buyResult.txSignature, marketCap });
          console.log(`[pumpfun-poll] ✅ ${buyResult.txSignature}`);
        } else {
          await updatePumpfunSnipeLog(snipeLog.id, {
            status: "failed",
            errorMessage: buyResult.error,
          });
          results.push({ fid, token: token.tokenSymbol, mintAddress, status: "failed", error: buyResult.error, marketCap });
          console.warn(`[pumpfun-poll] ❌ ${buyResult.error}`);
        }
      }
    }

    return NextResponse.json({ fetched: newTokens.length, watching: watchListTokens.length, sniped: totalSniped, results });
  } catch (err) {
    console.error("[pumpfun-poll] error:", err);
    return NextResponse.json({ error: err instanceof Error ? err.message : "Unknown" }, { status: 500 });
  }
}
