/**
 * POST /api/pumpfun/wallet
 * Terima Solana private key, derive alamat wallet, enkripsi, simpan ke DB.
 *
 * Format yang didukung:
 * 1. Base58 keypair (~88 char) → 64 byte [seed32 + pubkey32]  ← Phantom/OKX
 * 2. Base58 seed only (~44 char) → 32 byte seed
 * 3. JSON array "[1,2,...,64]" → 64 integer                   ← Solana CLI
 * 4. Hex string 128 char → 64 byte, atau 64 char → 32 byte
 *
 * Pakai bs58 library (sudah installed) — bukan implementasi manual.
 */
import { NextRequest, NextResponse } from "next/server";
import { Keypair } from "@solana/web3.js";
import bs58 from "bs58";
import { encrypt } from "@/lib/crypto";
import { upsertPumpfunSettings } from "@/db/actions/pumpfun-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";

/**
 * Parse berbagai format private key ke raw bytes.
 */
function parseKeyBytes(raw: string): Uint8Array {
  const trimmed = raw.trim();

  // JSON array: [1,2,...,64]
  if (trimmed.startsWith("[")) {
    const arr = JSON.parse(trimmed) as unknown[];
    if (
      !Array.isArray(arr) ||
      arr.some((v) => typeof v !== "number" || v < 0 || v > 255)
    ) {
      throw new Error("Array tidak valid — harus array angka 0–255");
    }
    if (arr.length !== 32 && arr.length !== 64) {
      throw new Error(`Array harus 32 atau 64 elemen, dapat ${arr.length}`);
    }
    return new Uint8Array(arr as number[]);
  }

  // Hex: 128 char = 64 byte, 64 char = 32 byte
  if (/^[0-9a-fA-F]+$/.test(trimmed)) {
    if (trimmed.length === 128 || trimmed.length === 64) {
      const len = trimmed.length / 2;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = parseInt(trimmed.slice(i * 2, i * 2 + 2), 16);
      }
      return bytes;
    }
  }

  // Base58 — pakai bs58 library (akurat, tidak ada bug BigInt padding)
  return bs58.decode(trimmed);
}

/**
 * Buat Keypair dari raw bytes + return wallet address (base58 pubkey).
 * Simpan sebagai base58(64-byte keypair) ke DB.
 */
function keypairFromBytes(bytes: Uint8Array): { keypair: Keypair; address: string; normalizedKey: string } {
  let keypair: Keypair;

  if (bytes.length === 64) {
    keypair = Keypair.fromSecretKey(bytes);
  } else if (bytes.length === 32) {
    keypair = Keypair.fromSeed(bytes);
  } else {
    throw new Error(
      `Panjang key tidak valid: ${bytes.length} byte. ` +
      `Harus 64 byte (keypair lengkap) atau 32 byte (seed). ` +
      `Pastikan kamu copy keseluruhan private key dari wallet.`
    );
  }

  const address      = keypair.publicKey.toBase58();
  const normalizedKey = bs58.encode(keypair.secretKey); // selalu 64 byte
  return { keypair, address, normalizedKey };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { fid, privateKey } = body;

    if (!fid || typeof fid !== "number") {
      return NextResponse.json({ error: "fid wajib" }, { status: 400 });
    }
    if (!privateKey || typeof privateKey !== "string" || privateKey.trim().length < 20) {
      return NextResponse.json({ error: "Private key tidak valid" }, { status: 400 });
    }

    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    let address: string;
    let normalizedKey: string;

    try {
      const bytes  = parseKeyBytes(privateKey);
      const result = keypairFromBytes(bytes);
      address      = result.address;
      normalizedKey = result.normalizedKey;
    } catch (e) {
      return NextResponse.json(
        { error: e instanceof Error ? e.message : "Format private key tidak valid" },
        { status: 400 },
      );
    }

    // Enkripsi sebelum simpan ke DB
    const encryptedKey = await encrypt(normalizedKey);

    const result = await upsertPumpfunSettings(fid, {
      solanaPrivateKey:    encryptedKey,
      solanaWalletAddress: address,
    });

    if (result?.error) {
      return NextResponse.json({ error: result.error }, { status: 400 });
    }

    return NextResponse.json({ success: true, walletAddress: address });
  } catch {
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const fid = parseInt(searchParams.get("fid") ?? "0");

    if (!fid) return NextResponse.json({ error: "fid wajib" }, { status: 400 });

    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    await upsertPumpfunSettings(fid, {
      solanaPrivateKey:    "",
      solanaWalletAddress: "",
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
