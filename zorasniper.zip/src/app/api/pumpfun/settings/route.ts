import { NextRequest, NextResponse } from "next/server";
import { getPumpfunSettings, upsertPumpfunSettings } from "@/db/actions/pumpfun-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";

export async function GET(request: NextRequest) {
  const fid = parseInt(request.nextUrl.searchParams.get("fid") ?? "0");
  if (!fid) return NextResponse.json({ error: "fid wajib" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  const settings = await getPumpfunSettings(fid);
  return NextResponse.json(settings ?? {
    isEnabled: false,
    buyAmountSol: "0.01",
    slippageBps: 1000,
    maxBuysPerDay: 5,
    minVolumeUsd: 1000,
    maxTokenAgeMin: 15,
    solanaWalletAddress: null,
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { fid, ...rest } = body;
    if (!fid || typeof fid !== "number") return NextResponse.json({ error: "fid wajib" }, { status: 400 });

    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    const result = await upsertPumpfunSettings(fid, rest);
    if (result?.error) return NextResponse.json({ error: result.error }, { status: 400 });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
