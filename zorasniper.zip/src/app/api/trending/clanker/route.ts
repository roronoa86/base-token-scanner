import { NextResponse } from "next/server";
import {
  getCoinsTopVolume24h,
  getCoinsNew,
} from "@zoralabs/coins-sdk";

// ─── Types ────────────────────────────────────────────────────────────────────

type TrendingFilter = "24h" | "2d" | "vol24h";

interface ZoraCoin {
  address: string;
  name: string;
  symbol: string;
  volume24h: string;
  marketCap: string;
  marketCapDelta24h: string;
  createdAt?: string;
  tokenPrice?: {
    priceInUsdc?: string;
    currencyAddress: string;
    priceInPoolToken: string;
  };
  mediaContent?: {
    previewImage?: {
      small?: string;
      medium?: string;
    };
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmtAge(createdAt: string): string {
  const diffMs  = Date.now() - new Date(createdAt).getTime();
  const diffMin = Math.floor(diffMs / 60_000);
  const diffH   = Math.floor(diffMs / 3_600_000);
  const diffD   = Math.floor(diffMs / 86_400_000);
  if (diffMin < 60) return `${diffMin}m`;
  if (diffH < 24)   return `${diffH}h`;
  if (diffD < 30)   return `${diffD}d`;
  return `${Math.floor(diffD / 30)}mo`;
}

function mapCoin(node: ZoraCoin) {
  const priceUsd  = parseFloat(node.tokenPrice?.priceInUsdc ?? "0");
  const marketCap = parseFloat(node.marketCap ?? "0");
  const vol24h    = parseFloat(node.volume24h ?? "0");
  const deltaAbs  = parseFloat(node.marketCapDelta24h ?? "0");
  // marketCapDelta24h is absolute USD delta (not a percentage).
  // Convert to % change: delta / (mc - delta) * 100
  let priceChange24h = 0;
  if (!isNaN(deltaAbs) && marketCap > 0) {
    const prevMc = marketCap - deltaAbs;
    priceChange24h = prevMc > 0 ? (deltaAbs / prevMc) * 100 : 0;
  }

  const imgUrl =
    (node as { mediaContent?: { previewImage?: { small?: string; medium?: string } } })
      .mediaContent?.previewImage?.small ??
    (node as { mediaContent?: { previewImage?: { small?: string; medium?: string } } })
      .mediaContent?.previewImage?.medium ??
    null;

  return {
    id:               0,
    name:             node.name,
    symbol:           node.symbol,
    contract_address: node.address,
    img_url:          imgUrl,
    cast_hash:        null,
    created_at:       node.createdAt ?? new Date().toISOString(),
    age:              node.createdAt ? fmtAge(node.createdAt) : "?",
    priceUsd,
    marketCap,
    volume24h:        vol24h,
    volume6h:         0,
    priceChange24h,
    priceChange1h:    0,
    liquidity:        0,
  };
}

// ─── Fetchers ─────────────────────────────────────────────────────────────────

async function fetchVol24h() {
  const res = await getCoinsTopVolume24h({ count: 50 });
  const edges = res.data?.exploreList?.edges ?? [];
  return edges
    .map((e) => mapCoin(e.node as unknown as ZoraCoin))
    .sort((a, b) => b.volume24h - a.volume24h);
}

async function fetchNew(maxAgeMs: number) {
  // getCoinsNew returns newest first — we filter by age client side
  // fetch 100 to ensure we get enough after filtering
  const res = await getCoinsNew({ count: 100 });
  const edges = res.data?.exploreList?.edges ?? [];
  const now = Date.now();
  return edges
    .map((e) => mapCoin(e.node as unknown as ZoraCoin))
    .filter((t) => now - new Date(t.created_at).getTime() <= maxAgeMs)
    .sort((a, b) => b.volume24h - a.volume24h);
}

// ─── In-memory cache (5 min TTL) ─────────────────────────────────────────────

const CACHE_TTL_MS = 5 * 60 * 1000;
type CachedToken = ReturnType<typeof mapCoin>;
const cache = new Map<string, { data: CachedToken[]; ts: number }>();

async function withCache(key: string, fetcher: () => Promise<CachedToken[]>) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.ts < CACHE_TTL_MS) return hit.data;
  const data = await fetcher();
  cache.set(key, { data, ts: Date.now() });
  return data;
}

// ─── Route Handler ────────────────────────────────────────────────────────────

export async function GET(request: Request) {
  const url    = new URL(request.url);
  const filter = (url.searchParams.get("filter") ?? "vol24h") as TrendingFilter;

  try {
    const tokens = await withCache(filter, () => {
      if (filter === "vol24h") return fetchVol24h();
      if (filter === "24h")   return fetchNew(86_400_000);
      return fetchNew(172_800_000); // 2d
    });
    return NextResponse.json({ tokens: tokens.slice(0, 30) });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Unknown error" },
      { status: 500 },
    );
  }
}
