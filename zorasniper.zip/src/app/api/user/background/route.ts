import { NextRequest, NextResponse } from "next/server";
import { db } from "@/neynar-db-sdk/db";
import { kv } from "@/db/schema";
import { eq } from "drizzle-orm";

export const PRESET_BACKGROUNDS = [
  { id: "1779667332438.png", label: "Nebula" },
  { id: "1779525414670.jpg", label: "Dark City" },
  { id: "1779612476364.jpg", label: "Neon Grid" },
] as const;

function bgKey(fid: number)   { return `user_bg:${fid}`; }
function dataKey(fid: number) { return `user_bg_data:${fid}`; }

// GET /api/user/background?fid=X
// Returns { bgId, dataUrl? }  — dataUrl only present if bgId === "custom"
export async function GET(request: NextRequest) {
  const fid = Number(request.nextUrl.searchParams.get("fid"));
  if (!fid) return NextResponse.json({ error: "fid required" }, { status: 400 });

  try {
    const rows = await db
      .select()
      .from(kv)
      .where(eq(kv.key, bgKey(fid)))
      .limit(1);

    const bgId = (rows[0]?.value as string) ?? PRESET_BACKGROUNDS[0].id;

    if (bgId === "custom") {
      const dataRows = await db.select().from(kv).where(eq(kv.key, dataKey(fid))).limit(1);
      const dataUrl = (dataRows[0]?.value as string) ?? null;
      return NextResponse.json({ bgId: "custom", dataUrl });
    }

    return NextResponse.json({ bgId });
  } catch {
    return NextResponse.json({ bgId: PRESET_BACKGROUNDS[0].id });
  }
}

// POST /api/user/background  { fid, bgId }  — set preset
export async function POST(request: NextRequest) {
  const { fid, bgId } = await request.json();
  if (!fid || !bgId) return NextResponse.json({ error: "fid and bgId required" }, { status: 400 });

  const valid = PRESET_BACKGROUNDS.some((b) => b.id === bgId);
  if (!valid) return NextResponse.json({ error: "Invalid background" }, { status: 400 });

  try {
    await db
      .insert(kv)
      .values({ key: bgKey(fid), value: bgId })
      .onConflictDoUpdate({ target: kv.key, set: { value: bgId } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
