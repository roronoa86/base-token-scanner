import { NextRequest, NextResponse } from "next/server";
import { db } from "@/neynar-db-sdk/db";
import { kv } from "@/db/schema";
import { eq } from "drizzle-orm";

// Max 3MB upload
const MAX_BYTES = 3 * 1024 * 1024;
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];

function dataKey(fid: number) {
  return `user_bg_data:${fid}`;
}
function metaKey(fid: number) {
  return `user_bg_meta:${fid}`;
}

// GET /api/user/background/upload?fid=X  — returns the stored custom image as data URL
export async function GET(request: NextRequest) {
  const fid = Number(request.nextUrl.searchParams.get("fid"));
  if (!fid) return NextResponse.json({ error: "fid required" }, { status: 400 });

  try {
    const row = await db.select().from(kv).where(eq(kv.key, dataKey(fid))).limit(1);
    const dataUrl = row[0]?.value as string | undefined;
    return NextResponse.json({ dataUrl: dataUrl ?? null });
  } catch {
    return NextResponse.json({ dataUrl: null });
  }
}

// POST /api/user/background/upload  multipart/form-data { fid, file }
export async function POST(request: NextRequest) {
  try {
    const form = await request.formData();
    const fid = Number(form.get("fid"));
    const file = form.get("file") as File | null;

    if (!fid || !file) {
      return NextResponse.json({ error: "fid and file required" }, { status: 400 });
    }

    if (!ALLOWED_TYPES.includes(file.type)) {
      return NextResponse.json({ error: "Format tidak didukung. Gunakan JPG, PNG, WebP, atau GIF." }, { status: 400 });
    }

    const buffer = await file.arrayBuffer();
    if (buffer.byteLength > MAX_BYTES) {
      return NextResponse.json({ error: "Ukuran file maksimal 3MB" }, { status: 400 });
    }

    const base64 = Buffer.from(buffer).toString("base64");
    const dataUrl = `data:${file.type};base64,${base64}`;

    // Store data URL and mark bg as "custom"
    await Promise.all([
      db.insert(kv).values({ key: dataKey(fid), value: dataUrl })
        .onConflictDoUpdate({ target: kv.key, set: { value: dataUrl } }),
      db.insert(kv).values({ key: metaKey(fid), value: file.name })
        .onConflictDoUpdate({ target: kv.key, set: { value: file.name } }),
      // Set bgId to "custom" so the main bg fetch knows to use data URL
      db.insert(kv).values({ key: `user_bg:${fid}`, value: "custom" })
        .onConflictDoUpdate({ target: kv.key, set: { value: "custom" } }),
    ]);

    return NextResponse.json({ ok: true, dataUrl });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

// DELETE /api/user/background/upload?fid=X  — remove custom image
export async function DELETE(request: NextRequest) {
  const fid = Number(request.nextUrl.searchParams.get("fid"));
  if (!fid) return NextResponse.json({ error: "fid required" }, { status: 400 });

  try {
    await Promise.all([
      db.delete(kv).where(eq(kv.key, dataKey(fid))),
      db.delete(kv).where(eq(kv.key, metaKey(fid))),
    ]);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
