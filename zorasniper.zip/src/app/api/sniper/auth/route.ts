/**
 * Auth endpoint — deprecated, diganti oleh /api/auth/send-otp dan /api/auth/verify-otp
 * Endpoint ini dipertahankan agar tidak break existing references
 */
import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json(
    { error: "Endpoint ini tidak digunakan lagi. Gunakan /api/auth/send-otp dan /api/auth/verify-otp" },
    { status: 410 }
  );
}
