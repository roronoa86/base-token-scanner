import { NextRequest, NextResponse } from "next/server";
import { getWatchedWallets, addWatchedWallet, removeWatchedWallet, updateWalletSettings } from "@/db/actions/sniper-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";

export async function GET(request: NextRequest) {
  const fidStr = request.nextUrl.searchParams.get("fid");
  const fid = parseInt(fidStr ?? "0");
  if (!fid || fid <= 0) return NextResponse.json({ error: "Invalid FID" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  const wallets = await getWatchedWallets(fid);
  return NextResponse.json(wallets);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { fid, walletAddress, label } = body;

    if (!fid || typeof fid !== "number" || fid <= 0) {
      return NextResponse.json({ error: "Invalid FID" }, { status: 400 });
    }

    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    if (!walletAddress || typeof walletAddress !== "string") {
      return NextResponse.json({ error: "Wallet address diperlukan" }, { status: 400 });
    }

    const result = await addWatchedWallet(fid, walletAddress, label);
    if (result.error) return NextResponse.json({ error: result.error }, { status: 400 });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { fid, walletId, label, buyAmountEth, maxBuysPerDay, slippageBps } = body;

    if (!fid || typeof fid !== "number" || fid <= 0) {
      return NextResponse.json({ error: "Invalid FID" }, { status: 400 });
    }

    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    if (!walletId || typeof walletId !== "string") {
      return NextResponse.json({ error: "Wallet ID diperlukan" }, { status: 400 });
    }

    const result = await updateWalletSettings(fid, walletId, { label, buyAmountEth, maxBuysPerDay, slippageBps });
    if (result.error) return NextResponse.json({ error: result.error }, { status: 400 });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json();
    const { fid, walletId } = body;

    if (!fid || typeof fid !== "number" || fid <= 0) {
      return NextResponse.json({ error: "Invalid FID" }, { status: 400 });
    }

    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    if (!walletId || typeof walletId !== "string") {
      return NextResponse.json({ error: "Wallet ID diperlukan" }, { status: 400 });
    }

    await removeWatchedWallet(fid, walletId);
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
