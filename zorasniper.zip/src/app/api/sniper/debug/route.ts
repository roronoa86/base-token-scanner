import { NextResponse } from "next/server";
import {
  getAllActiveWatchedWallets,
  getUnprocessedDeployments,
} from "@/db/actions/sniper-actions";
import { db } from "@/neynar-db-sdk/db";
import { sniperSettings, watchedWallets, snipeHistory } from "@/db/schema";
import { eq } from "drizzle-orm";
import { kvGet, kvSet } from "@/neynar-db-sdk";
import { requireAuthForFid } from "@/lib/auth-middleware";
import { NextRequest } from "next/server";

export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const fidStr = url.searchParams.get("fid");
  const fid = parseInt(fidStr ?? "0");

  if (!fid || fid <= 0) {
    return NextResponse.json({ error: "Tambahkan ?fid=<FID_KAMU>" }, { status: 400 });
  }

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  // 1. Settings status
  const settings = await db
    .select()
    .from(sniperSettings)
    .where(eq(sniperSettings.fid, fid))
    .limit(1);

  const setting = settings[0];
  const settingsStatus = {
    found: !!setting,
    isEnabled: setting?.isEnabled ?? false,
    hasPrivateKey: !!(setting?.privateKeyEncrypted),
    walletAddress: setting?.walletAddress ?? null,
    buyAmountEth: setting?.buyAmountEth ?? null,
    slippageBps: setting?.slippageBps ?? null,
    maxBuysPerDay: setting?.maxBuysPerDay ?? null,
  };

  // 2. Watched wallets
  const wallets = await db
    .select()
    .from(watchedWallets)
    .where(eq(watchedWallets.fid, fid));

  // 3. All active watched wallets (global, for polling)
  const allActive = await getAllActiveWatchedWallets();

  // 4. Last block scanned
  const lastBlock = await kvGet("sniper:last_block");

  // 5. Unprocessed deployments
  const unprocessed = await getUnprocessedDeployments();

  // 6. Recent snipe history
  const history = await db
    .select()
    .from(snipeHistory)
    .where(eq(snipeHistory.fid, fid))
    .limit(5);

  // 7. Cron secret configured?
  const hasCronSecret = !!process.env.CRON_SECRET;

  // 8. Base RPC configured?
  const hasBaseRpc = !!process.env.BASE_RPC_URL;

  // 9. Daily buy count — per wallet, tampilkan total semua wallet
  const today = new Date().toISOString().slice(0, 10);
  const activeWallets = wallets.filter(w => w.isActive);
  let dailyCount = 0;
  const dailyPerWallet: Record<string, number> = {};
  for (const w of activeWallets) {
    const key = `sniper:daily:${fid}:${w.walletAddress}:${today}`;
    const cnt = parseInt((await kvGet(key)) ?? "0");
    dailyPerWallet[w.walletAddress] = cnt;
    dailyCount += cnt;
  }

  const diagnosis: string[] = [];

  if (!settingsStatus.found) {
    diagnosis.push("❌ SETTINGS BELUM DIBUAT — buka tab Settings dan klik Simpan");
  }
  if (settingsStatus.found && !settingsStatus.isEnabled) {
    diagnosis.push("❌ SNIPER TIDAK AKTIF — aktifkan toggle di Dashboard");
  }
  if (!settingsStatus.hasPrivateKey) {
    diagnosis.push("❌ PRIVATE KEY BELUM DIISI — isi di tab Settings");
  }
  if (wallets.filter(w => w.isActive).length === 0) {
    diagnosis.push("❌ WATCHLIST KOSONG — tambahkan wallet target di tab Watchlist");
  }
  if (!lastBlock) {
    diagnosis.push("❌ CRON BELUM PERNAH JALAN — belum ada polling sama sekali");
  }
  if (!hasCronSecret) {
    diagnosis.push("⚠️ CRON_SECRET tidak diset — endpoint poll terbuka (aman untuk testing)");
  }
  if (!hasBaseRpc) {
    diagnosis.push("⚠️ BASE_RPC_URL tidak diset — menggunakan public RPC (mungkin lambat)");
  }
  // Cek apakah semua wallet sudah habis limitnya
  const allWalletsAtLimit = activeWallets.length > 0 && activeWallets.every(w =>
    (dailyPerWallet[w.walletAddress] ?? 0) >= (w.maxBuysPerDay ?? settingsStatus.maxBuysPerDay ?? 10)
  );
  if (allWalletsAtLimit) {
    diagnosis.push(`⚠️ SEMUA WALLET LIMIT HARIAN TERCAPAI — total ${dailyCount} buy hari ini. Reset via POST ?fid=${fid} {"action":"reset_daily"}`);
  }
  if (diagnosis.length === 0 || (diagnosis.length === 1 && diagnosis[0].startsWith("⚠️ CRON_SECRET"))) {
    diagnosis.push("✅ Semua konfigurasi OK");
  }

  return NextResponse.json({
    diagnosis,
    dailyBuyCount: {
      totalToday: dailyCount,
      perWallet: dailyPerWallet,
      maxPerWallet: settingsStatus.maxBuysPerDay,
    },
    settings: settingsStatus,
    watchlist: {
      total: wallets.length,
      active: wallets.filter(w => w.isActive).map(w => ({
        address: w.walletAddress,
        label: w.label,
      })),
    },
    polling: {
      lastBlockScanned: lastBlock ?? "BELUM PERNAH",
      allActiveWatchedWallets: allActive,
      unprocessedDeployments: unprocessed.length,
    },
    recentHistory: history.map(h => ({
      status: h.status,
      token: h.tokenName ?? h.tokenSymbol ?? h.tokenAddress.slice(0, 10),
      triggeredBy: h.triggeredByWallet.slice(0, 10) + "...",
      createdAt: h.createdAt,
      error: h.errorMessage,
    })),
    env: {
      hasCronSecret,
      hasBaseRpc,
      cronPollUrl: `${url.origin}/api/sniper/poll`,
    },
  }, { status: 200 });
}

// POST /api/sniper/debug?fid=XXX — reset daily counter atau last block
export async function POST(request: NextRequest) {
  const url = new URL(request.url);
  const fidStr = url.searchParams.get("fid");
  const fid = parseInt(fidStr ?? "0");

  if (!fid || fid <= 0) {
    return NextResponse.json({ error: "Tambahkan ?fid=<FID_KAMU>" }, { status: 400 });
  }

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  const body = await request.json().catch(() => ({}));
  const action = body.action as string;

  if (action === "reset_daily") {
    // Reset counter untuk semua wallet aktif milik FID ini
    const today = new Date().toISOString().slice(0, 10);
    const { watchedWallets: ww } = await import("@/db/schema");
    const { eq: eqOp, and: andOp } = await import("drizzle-orm");
    const userWallets = await db.select({ walletAddress: ww.walletAddress })
      .from(ww)
      .where(andOp(eqOp(ww.fid, fid), eqOp(ww.isActive, true)));
    for (const w of userWallets) {
      await kvSet(`sniper:daily:${fid}:${w.walletAddress}:${today}`, "0");
    }
    // Reset key lama (format sebelum update) untuk kompatibilitas
    await kvSet(`sniper:daily:${fid}:${today}`, "0");
    return NextResponse.json({
      success: true,
      message: `Counter harian direset untuk ${userWallets.length} wallet FID ${fid}`,
    });
  }

  if (action === "cleanup_bad_tokens") {
    // Mark semua deployment dengan known-bad token addresses sebagai processed
    // Ini membersihkan data lama sebelum fix decode CoinCreated event
    const BAD_ADDRESSES = [
      "0x498581ff718922c3f8e6a244956af099b2652b2b",
    ];
    const { detectedDeployments: dd } = await import("@/db/schema");
    const { inArray: inArrayOp } = await import("drizzle-orm");
    const updated = await db
      .update(dd)
      .set({ processed: true })
      .where(inArrayOp(dd.tokenAddress, BAD_ADDRESSES))
      .returning({ id: dd.id });
    return NextResponse.json({
      success: true,
      message: `Ditandai processed: ${updated.length} deployment dengan token address tidak valid`,
      cleaned: updated.length,
    });
  }

  if (action === "reset_last_block") {
    const { createPublicClient, http } = await import("viem");
    const { base } = await import("viem/chains");
    const client = createPublicClient({
      chain: base,
      transport: http(process.env.BASE_RPC_URL || "https://mainnet.base.org"),
    });
    const currentBlock = await client.getBlockNumber();
    const resetTo = currentBlock - BigInt(20);
    await kvSet("sniper:last_block", resetTo.toString());
    return NextResponse.json({
      success: true,
      message: `Last block direset ke ${resetTo} (20 blok ke belakang dari ${currentBlock})`,
    });
  }

  return NextResponse.json({
    error: "action tidak dikenal",
    available: ["reset_daily", "reset_last_block", "cleanup_bad_tokens"],
  }, { status: 400 });
}
