/**
 * TEST ENDPOINT — inject deployment palsu dan jalankan snipe
 * Hanya untuk debug, hapus setelah confirmed working
 */
import { NextResponse } from "next/server";
import {
  saveDetectedDeployment,
  getWatchersForWallet,
  getSniperSettings,
  createSnipeRecord,
  updateSnipeRecord,
  markDeploymentProcessed,
} from "@/db/actions/sniper-actions";
import { kvGet, kvSet } from "@/neynar-db-sdk";
import { createPublicClient, http, createWalletClient, parseUnits } from "viem";
import { base } from "viem/chains";
import { privateKeyToAccount } from "viem/accounts";
import { decrypt, isEncrypted } from "@/lib/crypto";

const MAX_SINGLE_BUY_ETH = BigInt("500000000000000000");
const ZORA_QUOTE_API = "https://api-sdk.zora.engineering";

// Zora Quote API — get calldata untuk buy
async function getZoraQuote(params: {
  tokenAddress: string;
  buyerAddress: string;
  amountInWei: bigint;
  slippageBps: number;
}): Promise<{ target: string; data: string; value: string } | null> {
  const slippage = params.slippageBps / 10000; // bps → 0.0-1.0
  const body = {
    chainId: base.id,
    tokenIn: { type: "eth" },
    tokenOut: { type: "erc20", address: params.tokenAddress.toLowerCase() },
    amountIn: params.amountInWei.toString(),
    slippage,
    sender: params.buyerAddress.toLowerCase(),
    recipient: params.buyerAddress.toLowerCase(),
  };

  const res = await fetch(`${ZORA_QUOTE_API}/quote`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Zora quote API error ${res.status}: ${text.slice(0, 200)}`);
  }

  const data = await res.json();
  if (!data.call) {
    throw new Error(`No call in quote response: ${JSON.stringify(data).slice(0, 200)}`);
  }
  return data.call as { target: string; data: string; value: string };
}

export async function POST(request: Request) {
  const body = await request.json();
  const { deployerWallet, tokenAddress, tokenName, tokenSymbol } = body;

  if (!deployerWallet || !tokenAddress) {
    return NextResponse.json({ error: "deployerWallet dan tokenAddress wajib diisi" }, { status: 400 });
  }

  // 1. Inject deployment
  const deployment = await saveDetectedDeployment({
    deployerWallet: deployerWallet.toLowerCase(),
    tokenAddress: tokenAddress.toLowerCase(),
    tokenName: tokenName ?? "Test Token",
    tokenSymbol: tokenSymbol ?? "TEST",
    txHash: `0xtest_${Date.now()}`,
    blockNumber: 99999999,
  });

  if (!deployment) {
    return NextResponse.json({ error: "Gagal inject deployment" }, { status: 500 });
  }

  // 2. Cari watchers
  const watchers = await getWatchersForWallet(deployerWallet.toLowerCase());
  const logs: string[] = [`Deployment injected: ${tokenAddress}`, `Watchers found: ${watchers.length}`];

  for (const watcher of watchers) {
    const settings = await getSniperSettings(watcher.fid);
    logs.push(`FID ${watcher.fid} settings: isEnabled=${settings?.isEnabled}, hasKey=${!!settings?.privateKeyEncrypted}`);

    if (!settings?.isEnabled) { logs.push("SKIP: sniper tidak aktif"); continue; }
    if (!settings.privateKeyEncrypted) { logs.push("SKIP: tidak ada private key"); continue; }

    const dailyKey = `sniper:daily:${watcher.fid}:${new Date().toISOString().slice(0, 10)}`;
    const dailyCount = parseInt((await kvGet(dailyKey)) ?? "0");
    logs.push(`Daily count: ${dailyCount}/${settings.maxBuysPerDay}`);
    if (dailyCount >= settings.maxBuysPerDay) { logs.push("SKIP: limit harian tercapai"); continue; }

    const buyAmountWei = parseUnits(settings.buyAmountEth, 18);
    logs.push(`Buy amount: ${settings.buyAmountEth} ETH = ${buyAmountWei} wei`);

    if (buyAmountWei > MAX_SINGLE_BUY_ETH) { logs.push("SKIP: melebihi cap 0.5 ETH"); continue; }

    // Cek saldo
    const publicClient = createPublicClient({ chain: base, transport: http(process.env.BASE_RPC_URL || "https://mainnet.base.org") });

    const rawKey = isEncrypted(settings.privateKeyEncrypted)
      ? await decrypt(settings.privateKeyEncrypted)
      : settings.privateKeyEncrypted;
    const pk = rawKey.startsWith("0x")
      ? rawKey as `0x${string}`
      : `0x${rawKey}` as `0x${string}`;
    const account = privateKeyToAccount(pk);

    const balance = await publicClient.getBalance({ address: account.address });
    logs.push(`Wallet: ${account.address}, balance: ${Number(balance) / 1e18} ETH`);

    const gasReserve = BigInt("50000000000000"); // 0.00005 ETH untuk gas (Base sangat murah)
    if (balance < buyAmountWei + gasReserve) {
      logs.push(`SKIP: saldo tidak cukup (butuh ${Number(buyAmountWei + gasReserve)/1e18} ETH, punya ${Number(balance)/1e18} ETH)`);
      continue;
    }

    // Buat snipe record
    const snipeRecord = await createSnipeRecord({
      fid: watcher.fid,
      triggeredByWallet: deployerWallet.toLowerCase(),
      tokenAddress: tokenAddress.toLowerCase(),
      tokenName: tokenName ?? "Test Token",
      tokenSymbol: tokenSymbol ?? "TEST",
      buyAmountEth: settings.buyAmountEth,
    });

    logs.push(`Snipe record created: ${snipeRecord?.id}`);

    // Execute buy via Zora Quote API
    try {
      logs.push(`Getting Zora quote for token ${tokenAddress}...`);

      const quote = await getZoraQuote({
        tokenAddress: tokenAddress.toLowerCase(),
        buyerAddress: account.address.toLowerCase(),
        amountInWei: buyAmountWei,
        slippageBps: settings.slippageBps,
      });

      if (!quote) throw new Error("Quote kosong");
      logs.push(`Quote OK: target=${quote.target}, value=${quote.value}`);

      const walletClient = createWalletClient({
        account,
        chain: base,
        transport: http(process.env.BASE_RPC_URL || "https://mainnet.base.org"),
      });

      const hash = await walletClient.sendTransaction({
        to: quote.target as `0x${string}`,
        data: quote.data as `0x${string}`,
        value: BigInt(quote.value),
        chain: base,
        account,
      });

      logs.push(`TX SENT: ${hash}`);
      await updateSnipeRecord(snipeRecord!.id, { status: "success", txHash: hash });
      await kvSet(dailyKey, (dailyCount + 1).toString());

    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      logs.push(`BUY FAILED: ${msg}`);
      if (snipeRecord) {
        await updateSnipeRecord(snipeRecord.id, { status: "failed", errorMessage: msg.slice(0, 200) });
      }
    }
  }

  await markDeploymentProcessed(deployment.id);

  return NextResponse.json({ logs });
}
