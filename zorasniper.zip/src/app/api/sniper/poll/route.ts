import { NextResponse } from "next/server";
import { timingSafeEqual } from "crypto";
import { createPublicClient, createWalletClient, http, parseUnits } from "viem";
import { base } from "viem/chains";
import { privateKeyToAccount } from "viem/accounts";
import { decrypt, isEncrypted } from "@/lib/crypto";
import {
  getAllActiveWatchedWallets,
  saveDetectedDeployment,
  getWatchersForWallet,
  getSniperSettings,
  createSnipeRecord,
  updateSnipeRecord,
  // queue processing still available for any missed deployments
  getUnprocessedDeployments,
  markDeploymentProcessed,
  hasAlreadyBought,
} from "@/db/actions/sniper-actions";
import { kvGet, kvSet } from "@/neynar-db-sdk";

const ZORA_FACTORY = "0x777777751622c0d3258f214F9DF38E35BF45baF3" as const;
const ZORA_QUOTE_API = "https://api-sdk.zora.engineering";
const MAX_SINGLE_BUY_ETH = BigInt("500000000000000000"); // 0.5 ETH cap

// Topic hashes untuk coin creation events dari Zora factory
const CREATION_TOPICS = new Set([
  "0x2de436107c2096e039c98bbcc3c5a2560583738ce15c234557eecb4d3221aa81",
  "0x74b670d628e152daa36ca95dda7cb0002d6ea7a37b55afe4593db7abd1515781",
]);

// Denylist: alamat yang BUKAN coin address valid (pool, router, dsb)
// Jika word[4] dari event data kebetulan menunjuk ke salah satu ini, skip
const KNOWN_NON_COIN_ADDRESSES = new Set([
  "0x498581ff718922c3f8e6a244956af099b2652b2b", // Zora shared liquidity pool
  "0x777777751622c0d3258f214f9df38e35bf45baf3", // Zora factory (lowercase)
  "0x0000000000000000000000000000000000000000", // zero address
]);

function verifyCronSecret(request: Request): boolean {
  const expected = process.env.CRON_SECRET;
  if (!expected) return true;
  // Vercel auto-injects "Authorization: Bearer <CRON_SECRET>" for cron jobs
  // Also accept x-cron-secret for manual/dev calls
  const authHeader = request.headers.get("authorization");
  const provided = authHeader?.startsWith("Bearer ")
    ? authHeader.slice(7)
    : request.headers.get("x-cron-secret");
  if (!provided) return false;
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export async function GET(request: Request) {
  if (!verifyCronSecret(request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // ?loops=4 → poll 4x dengan jeda 15 detik dalam 1 request
  // Efektif: cron tiap menit + loops=4 = poll tiap ~15 detik
  // ?slot=A atau ?slot=B → pakai lastBlock key berbeda agar 2 cron tidak konflik
  const url = new URL(request.url);
  const loops = Math.min(parseInt(url.searchParams.get("loops") ?? "1"), 6);
  const slot = url.searchParams.get("slot") ?? "default";

  const allResults: object[] = [];
  for (let i = 0; i < loops; i++) {
    if (i > 0) {
      // Tunggu 15 detik sebelum loop berikutnya
      await new Promise((r) => setTimeout(r, 15000));
    }
    const result = await runPollCycle(slot);
    allResults.push(result);
    // Kalau ada error fatal, berhenti
    if ("error" in result) break;
  }

  return NextResponse.json(loops === 1 ? allResults[0] : { loops: allResults });
}

async function runPollCycle(slot = "default"): Promise<object> {
  try {
    const rpcUrl = process.env.BASE_RPC_URL || "https://mainnet.base.org";
    const client = createPublicClient({ chain: base, transport: http("https://mainnet.base.org") });

    // Setiap slot punya lastBlock key sendiri agar 2+ cron tidak konflik
    const lastBlockKey = slot === "default" ? "sniper:last_block" : `sniper:last_block:${slot}`;
    const lastBlockStr = await kvGet(lastBlockKey);
    const currentBlock = await client.getBlockNumber();
    const fromBlock = lastBlockStr
      ? BigInt(lastBlockStr)
      : currentBlock - BigInt(5);

    if (fromBlock >= currentBlock) {
      return { message: "No new blocks", currentBlock: currentBlock.toString() };
    }

    // Scan up to 500 blok per cycle
    const toBlock = currentBlock - fromBlock > BigInt(500)
      ? fromBlock + BigInt(500)
      : currentBlock;

    // Ambil semua watched wallets sekaligus
    const watchedAddresses = await getAllActiveWatchedWallets();
    if (watchedAddresses.length === 0) {
      await kvSet(lastBlockKey, toBlock.toString());
      return { message: "No watched wallets", blocksScanned: 0, deploymentsDetected: 0, snipesExecuted: 0 };
    }

    const watchedSet = new Set(watchedAddresses.map(a => a.toLowerCase()));

    // Fetch factory logs untuk range ini
    const rawLogs = await client.getLogs({ address: ZORA_FACTORY, fromBlock, toBlock });

    // Filter hanya creation events dari watched wallets — deduplicate by txHash
    const seenTx = new Set<string>();
    const toSnipe: Array<{ creator: string; txHash: string; blockNumber: number; coinAddress: string }> = [];

    for (const log of rawLogs) {
      const topic0 = log.topics[0]?.toLowerCase() ?? "";
      if (!CREATION_TOPICS.has(topic0)) continue;

      const txHash = log.transactionHash;
      if (!txHash || seenTx.has(txHash)) continue;

      const creatorRaw = log.topics[1];
      if (!creatorRaw) continue;
      const creator = ("0x" + creatorRaw.slice(-40)).toLowerCase();

      if (!watchedSet.has(creator)) continue;

      // Ekstrak coin address langsung dari event data (chunk ke-5, offset 0x80 = byte 128)
      const data = (log as { data?: string }).data ?? "";
      const raw = data.startsWith("0x") ? data.slice(2) : data;
      const coinWord = raw.slice(4 * 64, 5 * 64);
      if (!coinWord || coinWord.length < 64) continue;
      const coinAddress = ("0x" + coinWord.slice(-40)).toLowerCase();

      if (KNOWN_NON_COIN_ADDRESSES.has(coinAddress)) continue;
      if (!/^0x[0-9a-f]{40}$/.test(coinAddress)) continue;

      seenTx.add(txHash);
      toSnipe.push({ creator, txHash, blockNumber: Number(log.blockNumber ?? 0), coinAddress });
    }

    // Update last block ASAP biar poll berikutnya tidak re-scan range yang sama
    await kvSet(lastBlockKey, toBlock.toString());

    let sniped = 0;
    let detected = 0;

    // Process setiap deployment yang ditemukan — inline, tanpa queue delay
    for (const { creator, txHash, blockNumber, coinAddress } of toSnipe) {
      const tokenAddress = coinAddress;

      const [deployment, watchers] = await Promise.all([
        saveDetectedDeployment({ deployerWallet: creator, tokenAddress, txHash, blockNumber }),
        getWatchersForWallet(creator),
      ]);
      if (!deployment) continue;
      detected++;

      for (const watcher of watchers) {
        const today = new Date().toISOString().slice(0, 10);
        const dailyKey = `sniper:daily:${watcher.fid}:${watcher.walletAddress}:${today}`;
        const [settings, alreadyBought, dailyCountStr] = await Promise.all([
          getSniperSettings(watcher.fid),
          hasAlreadyBought(watcher.fid, tokenAddress),
          kvGet(dailyKey),
        ]);

        if (!settings?.isEnabled) continue;
        if (!settings.privateKeyEncrypted || !settings.walletAddress) continue;
        if (alreadyBought) continue;

        // Per-wallet override > global fallback
        const effectiveBuyAmountEth = watcher.walletBuyAmountEth ?? settings.buyAmountEth;
        const effectiveMaxBuysPerDay = watcher.walletMaxBuysPerDay ?? settings.maxBuysPerDay;
        const effectiveSlippageBps = watcher.walletSlippageBps ?? settings.slippageBps;

        const dailyCount = parseInt(dailyCountStr ?? "0");
        if (dailyCount >= effectiveMaxBuysPerDay) continue;

        const buyAmountWei = parseUnits(effectiveBuyAmountEth, 18);
        if (buyAmountWei > MAX_SINGLE_BUY_ETH) continue;

        const snipeRecord = await createSnipeRecord({
          fid: watcher.fid,
          triggeredByWallet: creator,
          tokenAddress,
          buyAmountEth: effectiveBuyAmountEth,
        });
        if (!snipeRecord) continue;

        try {
          const txResult = await executeBuy({
            privateKey: settings.privateKeyEncrypted,
            tokenAddress,
            buyAmountWei,
            slippageBps: effectiveSlippageBps,
            rpcUrl,
          });
          await updateSnipeRecord(snipeRecord.id, { status: "success", txHash: txResult });
          await kvSet(dailyKey, (dailyCount + 1).toString());
          sniped++;
        } catch (err) {
          const msg = err instanceof Error ? err.message.slice(0, 200) : "Unknown error";
          await updateSnipeRecord(snipeRecord.id, { status: "failed", errorMessage: msg });
        }
      }

      // Mark processed setelah semua watcher diproses
      await markDeploymentProcessed(deployment.id);
    }

    // Juga proses sisa queue lama (kalau ada yang tertinggal dari poll sebelumnya)
    const leftover = await getUnprocessedDeployments();
    for (const dep of leftover) {
      // Skip known bad addresses dari data lama (sebelum fix decode)
      if (KNOWN_NON_COIN_ADDRESSES.has(dep.tokenAddress.toLowerCase())) {
        await markDeploymentProcessed(dep.id);
        continue;
      }

      const watchers = await getWatchersForWallet(dep.deployerWallet);
      for (const watcher of watchers) {
        const settings = await getSniperSettings(watcher.fid);
        if (!settings?.isEnabled || !settings.privateKeyEncrypted) continue;

        // Cegah double-buy dari leftover queue
        if (await hasAlreadyBought(watcher.fid, dep.tokenAddress)) continue;

        const effectiveBuyAmountEth = watcher.walletBuyAmountEth ?? settings.buyAmountEth;
        const effectiveMaxBuysPerDay = watcher.walletMaxBuysPerDay ?? settings.maxBuysPerDay;
        const effectiveSlippageBps = watcher.walletSlippageBps ?? settings.slippageBps;

        const today = new Date().toISOString().slice(0, 10);
        const dailyKey = `sniper:daily:${watcher.fid}:${watcher.walletAddress}:${today}`;
        const dailyCount = parseInt((await kvGet(dailyKey)) ?? "0");
        if (dailyCount >= effectiveMaxBuysPerDay) continue;

        const buyAmountWei = parseUnits(effectiveBuyAmountEth, 18);
        if (buyAmountWei > MAX_SINGLE_BUY_ETH) continue;

        const snipeRecord = await createSnipeRecord({
          fid: watcher.fid,
          triggeredByWallet: dep.deployerWallet,
          tokenAddress: dep.tokenAddress,
          tokenName: dep.tokenName ?? undefined,
          tokenSymbol: dep.tokenSymbol ?? undefined,
          buyAmountEth: effectiveBuyAmountEth,
        });
        if (!snipeRecord) continue;

        try {
          const txResult = await executeBuy({
            privateKey: settings.privateKeyEncrypted,
            tokenAddress: dep.tokenAddress,
            buyAmountWei,
            slippageBps: effectiveSlippageBps,
            rpcUrl,
          });
          await updateSnipeRecord(snipeRecord.id, { status: "success", txHash: txResult });
          await kvSet(dailyKey, (dailyCount + 1).toString());
          sniped++;
        } catch (err) {
          const msg = err instanceof Error ? err.message.slice(0, 200) : "Unknown error";
          await updateSnipeRecord(snipeRecord.id, { status: "failed", errorMessage: msg });
        }
      }
      await markDeploymentProcessed(dep.id);
    }

    return {
      success: true,
      blocksScanned: Number(toBlock - fromBlock),
      deploymentsDetected: detected,
      snipesExecuted: sniped,
      fromBlock: fromBlock.toString(),
      toBlock: toBlock.toString(),
    };
  } catch (error) {
    console.error("Sniper poll error:", error);
    return { error: "Poll failed", detail: error instanceof Error ? error.message : "Unknown" };
  }
}

// ─── Buy Executor ─────────────────────────────────────────────────────────────

async function executeBuy(params: {
  privateKey: string;
  tokenAddress: string;
  buyAmountWei: bigint;
  slippageBps: number;
  rpcUrl: string;
}): Promise<string> {
  const rawKey = isEncrypted(params.privateKey)
    ? await decrypt(params.privateKey)
    : params.privateKey;

  const pk = rawKey.startsWith("0x")
    ? (rawKey as `0x${string}`)
    : (`0x${rawKey}` as `0x${string}`);

  const account = privateKeyToAccount(pk);

  const publicClient = createPublicClient({
    chain: base,
    transport: http(params.rpcUrl),
  });

  // Zora Quote API — handle semua jenis coin (V3/V4, ETH pair / USDC pair)
  // Retry 3x: pool Zora butuh beberapa blok setelah deploy sebelum siap di-quote
  // (race condition: deploy TX confirmed tapi liquidity belum fully initialized)
  const slippage = params.slippageBps / 10000;
  const quoteBody = JSON.stringify({
    chainId: base.id,
    tokenIn: { type: "eth" },
    tokenOut: { type: "erc20", address: params.tokenAddress.toLowerCase() },
    amountIn: params.buyAmountWei.toString(),
    slippage,
    sender: account.address.toLowerCase(),
    recipient: account.address.toLowerCase(),
  });

  let quoteData: { call?: { target: string; data: string; value: string } } | null = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    const quoteRes = await fetch(`${ZORA_QUOTE_API}/quote`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: quoteBody,
    });

    if (!quoteRes.ok) {
      const text = await quoteRes.text();
      const isPoolNotReady = text.includes("Cannot read properties of null") || text.includes("UNKNOWN");
      if (isPoolNotReady && attempt < 3) {
        console.log(`[sniper] Zora quote attempt ${attempt}/3 gagal (pool belum ready), retry dalam 5s...`);
        await new Promise(r => setTimeout(r, 5000));
        continue;
      }
      throw new Error(`Zora quote error ${quoteRes.status}: ${text.slice(0, 200)}`);
    }

    const data = await quoteRes.json();
    if (!data.call) {
      if (attempt < 3) {
        console.log(`[sniper] Zora quote attempt ${attempt}/3: no call, retry...`);
        await new Promise(r => setTimeout(r, 5000));
        continue;
      }
      throw new Error(`No call in quote: ${JSON.stringify(data).slice(0, 200)}`);
    }

    quoteData = data;
    break;
  }

  if (!quoteData?.call) {
    throw new Error("Zora quote gagal setelah 3 percobaan — pool belum siap atau token tidak valid");
  }

  const call = quoteData.call as { target: string; data: string; value: string };

  // Simulate dulu — kalau revert langsung throw sebelum kirim TX
  await publicClient.call({
    to: call.target as `0x${string}`,
    data: call.data as `0x${string}`,
    value: BigInt(call.value),
    account: account.address,
  });

  const walletClient = createWalletClient({
    account,
    chain: base,
    transport: http(params.rpcUrl),
  });

  // Gas: pakai estimasi network, clamp ke max 2 gwei
  // 0.1 gwei terlalu rendah saat Base congestion → TX stuck
  const feeData = await publicClient.estimateFeesPerGas();
  const MAX_GAS_WEI = BigInt("2000000000"); // 2 gwei cap
  const maxFeePerGas = feeData.maxFeePerGas && feeData.maxFeePerGas < MAX_GAS_WEI
    ? feeData.maxFeePerGas
    : MAX_GAS_WEI;
  const maxPriorityFeePerGas = feeData.maxPriorityFeePerGas && feeData.maxPriorityFeePerGas < MAX_GAS_WEI
    ? feeData.maxPriorityFeePerGas
    : BigInt("100000000"); // 0.1 gwei priority

  return walletClient.sendTransaction({
    to: call.target as `0x${string}`,
    data: call.data as `0x${string}`,
    value: BigInt(call.value),
    chain: base,
    account,
    maxFeePerGas,
    maxPriorityFeePerGas,
  });
}
