/**
 * Migration endpoint — enkripsi / re-enkripsi semua private key di database
 * GET /api/sniper/migrate-keys        — jalankan migrasi / verifikasi
 * DELETE /api/sniper/migrate-keys     — hapus semua key yang tidak bisa di-decrypt
 * Idempotent: aman dipanggil berulang kali
 *
 * PROTECTED: hanya owner app (NEXT_PUBLIC_USER_FID) yang boleh akses via CRON_SECRET
 */
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/neynar-db-sdk/db";
import { sniperSettings } from "@/db/schema";
import { eq, isNotNull } from "drizzle-orm";
import { encrypt, decrypt, isEncrypted } from "@/lib/crypto";
import { verifyCronSecret } from "@/lib/auth-middleware";

function isOwner(request: NextRequest): boolean {
  // Boleh akses jika: ada CRON_SECRET yang valid, atau CRON_SECRET belum diset (dev mode)
  return verifyCronSecret(request);
}

export async function GET(request: NextRequest) {
  if (!isOwner(request)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  const allSettings = await db.select().from(sniperSettings);
  let migrated = 0;
  let alreadyGood = 0;
  let noKey = 0;
  let failed = 0;

  for (const s of allSettings) {
    if (!s.privateKeyEncrypted) { noKey++; continue; }

    if (!isEncrypted(s.privateKeyEncrypted)) {
      // Plain text → enkripsi
      const encrypted = await encrypt(s.privateKeyEncrypted);
      await db.update(sniperSettings).set({ privateKeyEncrypted: encrypted }).where(eq(sniperSettings.id, s.id));
      migrated++;
      continue;
    }

    // Sudah encrypted — verifikasi bisa di-decrypt
    try {
      await decrypt(s.privateKeyEncrypted);
      alreadyGood++;
    } catch {
      failed++;
    }
  }

  return NextResponse.json({
    success: failed === 0,
    migrated,
    verified: alreadyGood,
    noKey,
    failed,
    message: failed > 0
      ? `${failed} key tidak bisa di-decrypt dengan ENCRYPTION_KEY saat ini. Gunakan DELETE /api/sniper/migrate-keys untuk hapus dan input ulang.`
      : `Semua key OK — ${migrated} baru dienkripsi, ${alreadyGood} sudah terverifikasi`,
  });
}

// DELETE — hapus private key yang tidak bisa di-decrypt (perlu input ulang)
export async function DELETE(request: NextRequest) {
  if (!isOwner(request)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  const allSettings = await db.select().from(sniperSettings).where(isNotNull(sniperSettings.privateKeyEncrypted));
  let cleared = 0;

  for (const s of allSettings) {
    if (!s.privateKeyEncrypted) continue;
    if (!isEncrypted(s.privateKeyEncrypted)) continue; // biarkan plain text (akan di-encrypt oleh GET)

    try {
      await decrypt(s.privateKeyEncrypted);
      // Decrypt OK, skip
    } catch {
      // Decrypt gagal → hapus
      await db.update(sniperSettings)
        .set({ privateKeyEncrypted: null, walletAddress: null })
        .where(eq(sniperSettings.id, s.id));
      cleared++;
    }
  }

  return NextResponse.json({
    success: true,
    cleared,
    message: cleared > 0
      ? `${cleared} private key dihapus. Silakan input ulang private key di tab Settings.`
      : "Tidak ada key yang perlu dihapus",
  });
}
