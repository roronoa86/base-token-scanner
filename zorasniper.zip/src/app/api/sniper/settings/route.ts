import { NextRequest, NextResponse } from "next/server";
import { getSniperSettings, upsertSniperSettings } from "@/db/actions/sniper-actions";
import { encrypt } from "@/lib/crypto";
import { requireAuthForFid } from "@/lib/auth-middleware";

export async function GET(request: NextRequest) {
  const fidStr = request.nextUrl.searchParams.get("fid");
  const fid = parseInt(fidStr ?? "0");
  if (!fid || fid <= 0) return NextResponse.json({ error: "Invalid FID" }, { status: 400 });

  // Auth: verifikasi token cocok dengan FID yang diminta
  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  const settings = await getSniperSettings(fid);
  if (settings) {
    const { privateKeyEncrypted: _, ...safeSettings } = settings;
    return NextResponse.json({ ...safeSettings, hasPrivateKey: !!settings.privateKeyEncrypted });
  }
  return NextResponse.json(null);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { fid, privateKey, walletAddress, ...rest } = body;

    if (!fid || typeof fid !== "number" || fid <= 0) {
      return NextResponse.json({ error: "Invalid FID" }, { status: 400 });
    }

    // Auth: verifikasi token cocok dengan FID
    const auth = await requireAuthForFid(request, fid);
    if (!auth.ok) return auth.response;

    let privateKeyEncrypted: string | undefined;
    let resolvedWalletAddress: string | undefined = walletAddress;

    if (privateKey) {
      const { privateKeyToAccount } = await import("viem/accounts");
      try {
        const pk = privateKey.startsWith("0x")
          ? (privateKey as `0x${string}`)
          : (`0x${privateKey}` as `0x${string}`);
        const account = privateKeyToAccount(pk);
        resolvedWalletAddress = account.address;
        privateKeyEncrypted = await encrypt(pk);
      } catch {
        return NextResponse.json({ error: "Private key tidak valid" }, { status: 400 });
      }
    }

    const result = await upsertSniperSettings(fid, {
      ...rest,
      ...(privateKeyEncrypted && { privateKeyEncrypted }),
      ...(resolvedWalletAddress && { walletAddress: resolvedWalletAddress }),
    });

    if (result.error) return NextResponse.json({ error: result.error }, { status: 400 });

    return NextResponse.json({ success: true, walletAddress: resolvedWalletAddress });
  } catch (error) {
    console.error("Settings update error:", error);
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
