import { NextRequest, NextResponse } from "next/server";
import { getSnipeHistory, getSnipeStats } from "@/db/actions/sniper-actions";
import { requireAuthForFid } from "@/lib/auth-middleware";

export async function GET(request: NextRequest) {
  const fid = parseInt(request.nextUrl.searchParams.get("fid") ?? "0");
  if (!fid || fid <= 0) return NextResponse.json({ error: "Invalid FID" }, { status: 400 });

  const auth = await requireAuthForFid(request, fid);
  if (!auth.ok) return auth.response;

  const [history, stats] = await Promise.all([
    getSnipeHistory(fid, 50),
    getSnipeStats(fid),
  ]);

  return NextResponse.json({ history, stats });
}
