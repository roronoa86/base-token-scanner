"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

const WEB_FID_KEY  = "zora_sniper_fid";
const WEB_USER_KEY = "zora_sniper_user";

export default function AuthCallbackPage() {
  const router = useRouter();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [message, setMessage] = useState("Memverifikasi login...");
  const [debugText, setDebugText] = useState("");

  useEffect(() => {
    // Neynar kirim data via postMessage ke opener (desktop popup)
    // ATAU via query string setelah redirect (mobile/tab)
    const search = window.location.search;
    const hash   = window.location.hash.replace(/^#\??/, "");
    const fromSearch = new URLSearchParams(search);
    const fromHash   = new URLSearchParams(hash);

    const fid        = fromSearch.get("fid")              ?? fromHash.get("fid");
    const signerUuid = fromSearch.get("signer_uuid")      ?? fromHash.get("signer_uuid");
    const isAuth     = fromSearch.get("is_authenticated") ?? fromHash.get("is_authenticated");
    const userParam  = fromSearch.get("user")             ?? fromHash.get("user");

    const fullUrl = window.location.href;
    setDebugText(fullUrl);

    // Kalau kita punya fid langsung dari URL params (redirect flow)
    if (fid && isAuth !== "false") {
      let username = `FID ${fid}`;
      if (userParam) {
        try {
          const u = JSON.parse(decodeURIComponent(userParam));
          username = u.username ?? u.display_name ?? username;
        } catch { /* fallback */ }
      }

      localStorage.setItem(WEB_FID_KEY, fid);
      localStorage.setItem(WEB_USER_KEY, username);
      if (signerUuid) localStorage.setItem("zora_sniper_signer", signerUuid);

      // Kalau ini popup — kirim ke parent dan tutup
      if (window.opener && !window.opener.closed) {
        window.opener.postMessage(
          { is_authenticated: true, fid: parseInt(fid), username },
          window.location.origin
        );
        window.close();
        return;
      }

      // Kalau tab biasa — redirect ke home
      setStatus("success");
      setMessage(`Berhasil! Selamat datang, @${username}`);
      setTimeout(() => router.replace("/"), 1000);
      return;
    }

    // Tidak ada fid — tampilkan debug
    if (isAuth === "false") {
      setStatus("error");
      setMessage("Login dibatalkan.");
    } else {
      setStatus("error");
      setMessage("Parameter login tidak ditemukan.");
    }
  }, [router]);

  return (
    <div
      className="flex h-dvh flex-col items-center justify-center p-6 relative"
      style={{
        backgroundImage: "url('/1779525414670.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center top",
      }}
    >
      <div className="absolute inset-0 bg-[#00050f]/55" />
      <div className="relative z-10 flex flex-col items-center gap-4 text-center max-w-sm w-full">
        <div className={`text-5xl ${status === "loading" ? "animate-pulse" : ""}`}>
          {status === "loading" ? "🎯" : status === "success" ? "✅" : "❌"}
        </div>
        <div
          className="rounded-2xl px-6 py-4 w-full"
          style={{
            background: "linear-gradient(160deg, rgba(10,30,80,0.72) 0%, rgba(4,14,48,0.68) 100%)",
            backdropFilter: "blur(18px)",
            border: "1px solid rgba(80,130,255,0.32)",
          }}
        >
          <p className="text-white font-black text-base">{message}</p>
          {status === "loading" && (
            <p className="text-[#6b9fff] text-xs font-semibold mt-1">Mohon tunggu...</p>
          )}
          {status === "error" && debugText && (
            <p className="text-yellow-400/70 text-[10px] mt-3 break-all font-mono text-left">{debugText}</p>
          )}
          {status === "error" && (
            <button
              onClick={() => router.replace("/")}
              className="mt-3 text-xs font-bold text-[#6b9fff] underline"
            >
              Kembali ke app →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
