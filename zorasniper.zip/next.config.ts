import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  cleanDistDir: false,
  turbopack: {
    root: import.meta.dirname,
  },
  experimental: {
    turbopackFileSystemCacheForDev: false,
  },
  // Expose VERCEL_PROJECT_PRODUCTION_URL to client-side code
  env: {
    NEXT_PUBLIC_VERCEL_PRODUCTION_URL:
      process.env.VERCEL_PROJECT_PRODUCTION_URL,
    // Alchemy Base Mainnet RPC (HTTPS + WSS)
    BASE_RPC_URL: "https://base-mainnet.g.alchemy.com/v2/ZDN_6SV5XelxMRm--dFE3",
    BASE_WSS_URL: "wss://base-mainnet.g.alchemy.com/v2/ZDN_6SV5XelxMRm--dFE3",
    // Encryption key untuk private key di database (AES-256-GCM)
    // JANGAN GANTI setelah ada data — private key lama tidak bisa di-decrypt
    ENCRYPTION_KEY: "2f7f944913e5bfcdd4d429e8df7034d27ba6236624804db11f340961f9d4b0b3",
    // JWT secret untuk web session
    JWT_SECRET: "2f7f944913e5bfcdd4d429e8df7034d27ba6236624804db11f340961f9d4b0b3-jwt",
  },
  allowedDevOrigins: [
    "*.ngrok.app",
    "*.neynar.com",
    "*.neynar.app",
    "*.studio.neynar.com",
    "*.dev-studio.neynar.com",
    "*.nip.io",
  ],
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "i.imgur.com",
      },
      {
        protocol: "https",
        hostname: "neynar-public.s3.us-east-1.amazonaws.com",
      },
      {
        protocol: "https",
        hostname: "cdn.neynar.com",
      },
    ],
  },
  devIndicators: false,
  reactCompiler: true,
};

export default nextConfig;
