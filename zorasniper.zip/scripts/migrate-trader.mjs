// Run: node scripts/migrate-trader.mjs
import postgres from "postgres";

const url = process.env.DATABASE_URL;
if (!url) { console.log("No DATABASE_URL"); process.exit(0); }

const sql = postgres(url, { max: 1 });

try {
  // ── trader_positions ──────────────────────────────────────────────────────
  await sql`DROP TABLE IF EXISTS trader_positions CASCADE`;
  await sql`
    CREATE TABLE trader_positions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      fid INTEGER NOT NULL,
      token_address TEXT NOT NULL,
      token_name TEXT,
      token_symbol TEXT,
      token_price_usd TEXT,
      token_image_url TEXT,
      buy_amount_eth NUMERIC(18,8) NOT NULL,
      buy_trigger_price_usd NUMERIC(20,8),
      sell_target_price_usd NUMERIC(20,8),
      take_profit_pct NUMERIC(8,2),
      stop_loss_pct NUMERIC(8,2),
      buy_tx_hash TEXT,
      buy_price_usd NUMERIC(20,8),
      buy_price_eth NUMERIC(30,18),
      tokens_received NUMERIC(36,0),
      status TEXT NOT NULL DEFAULT 'pending_buy',
      sell_tx_hash TEXT,
      sell_price_usd NUMERIC(20,8),
      sell_amount_eth NUMERIC(18,8),
      pnl_eth NUMERIC(18,8),
      pnl_pct NUMERIC(8,2),
      close_reason TEXT,
      error_message TEXT,
      created_at TIMESTAMP DEFAULT NOW() NOT NULL,
      updated_at TIMESTAMP DEFAULT NOW() NOT NULL,
      closed_at TIMESTAMP
    )
  `;
  console.log("✅ trader_positions table recreated");

  // ── clanker_sniper_settings ───────────────────────────────────────────────
  // Drop and recreate with correct schema (slippage_bps, max_buys_per_day, min_liquidity_usd)
  await sql`DROP TABLE IF EXISTS clanker_sniper_settings CASCADE`;
  await sql`
    CREATE TABLE clanker_sniper_settings (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      fid INTEGER NOT NULL UNIQUE,
      is_enabled BOOLEAN NOT NULL DEFAULT false,
      buy_amount_eth NUMERIC(18,8) NOT NULL DEFAULT 0.001,
      slippage_bps INTEGER NOT NULL DEFAULT 500,
      max_buys_per_day INTEGER NOT NULL DEFAULT 5,
      min_liquidity_usd INTEGER NOT NULL DEFAULT 1000,
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `;
  console.log("✅ clanker_sniper_settings table recreated");

  // ── clanker_snipe_log ─────────────────────────────────────────────────────
  await sql`DROP TABLE IF EXISTS clanker_snipe_log CASCADE`;
  await sql`
    CREATE TABLE clanker_snipe_log (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      fid INTEGER NOT NULL,
      token_address TEXT NOT NULL,
      token_name TEXT,
      token_symbol TEXT,
      clanker_token_id INTEGER,
      volume_usd_at_snipe INTEGER,
      buy_amount_eth NUMERIC(18,8) NOT NULL,
      tx_hash TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      error_message TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    )
  `;
  console.log("✅ clanker_snipe_log table recreated");

} catch (e) {
  console.error("Migration error:", e.message);
} finally {
  await sql.end();
}
