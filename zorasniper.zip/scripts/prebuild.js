#!/usr/bin/env node
/**
 * Prebuild script: pre-creates a placeholder .next/routes-manifest.json
 * before `next build` runs.
 *
 * Next.js 16.2.0 + Turbopack: when Turbopack doesn't produce .nft.json trace
 * files, Next.js falls back to manual server-file tracing. That tracing step
 * runs *before* the finalization phase writes routes-manifest.json, so it
 * crashes with ENOENT. Placing a valid placeholder here lets the tracing step
 * succeed; the finalization phase then overwrites it with the real content.
 */

const fs = require("fs");
const path = require("path");

const nextDir = path.join(__dirname, "..", ".next");
const manifestPath = path.join(nextDir, "routes-manifest.json");

fs.mkdirSync(nextDir, { recursive: true });

const placeholder = {
  version: 3,
  pages404: true,
  appType: "app",
  caseSensitive: false,
  basePath: "",
  redirects: [],
  headers: [],
  onMatchHeaders: [],
  rewrites: {
    beforeFiles: [],
    afterFiles: [],
    fallback: [],
  },
};

fs.writeFileSync(manifestPath, JSON.stringify(placeholder));
console.log("[prebuild] Wrote placeholder .next/routes-manifest.json");
